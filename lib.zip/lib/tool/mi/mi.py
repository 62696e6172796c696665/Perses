#!/usr/bin/env python
"""
follow MI protocal: v1.1
https://nvmexpress.org/wp-content/uploads/NVM-Express-Management-Interface-1.1-Ratified.pdf

"""
import os
import time


class MI:
    def __init__(self):
        self._bus_id = None

    @property
    def bus_id(self):
        if not self._bus_id:
            self._bus_id = self._get_target_i2c_bus()
        return self._bus_id

    def _lookup_i2c_bus_id(self):
        cmd = "i2cdetect -l"
        return os.popen(cmd)

    def _get_target_i2c_bus(self):
        i2c_bus = self._lookup_i2c_bus_id()
        for line in i2c_bus.readlines():
            if "smbus" in line:
                #print("\n%s" % line)
                return line.split("\t")[0].split("-")[-1]
        return None

    def _i2cget(self, start, length=1):
        i2c_data = list()
        for index in range(start, start + length):
            byte_value = self._i2cget_byte(index)
            i2c_data.append(byte_value)
        if None not in i2c_data:
            return i2c_data
        return self._i2cget(start, length)

    def _i2cget_byte(self, offset):
        if not self.bus_id:
            raise RuntimeError("cannot find smbus on your system")
        cmd = "i2cget -y {} 0x6a {}".format(self.bus_id, hex(offset))
        byte_data = os.popen(cmd).readline().split("\n")[0]
        if byte_data:
            return byte_data.split("0x")[1]
        time.sleep(2)
        return self._i2cget_byte(offset)
