#!/usr/bin/env python
# -*- coding: UTF-8 -*-
import subprocess
import logging
LOG = logging.getLogger()

class UpdaterLinux:

    def __init__(self, dev='/dev/nvme0'):
        self.dev = dev

    @staticmethod
    def __execute_command(command):
        with subprocess.Popen(command, shell=True, stdout=subprocess.PIPE) as process:
            ret = process.wait()
            stdout, stderr = process.communicate()
        if stderr is not None:
            LOG.info(stderr.decode())
        str_out = stdout.decode() if stdout is not None else ""
        return bool(ret == 0), str_out

    def fw_download(self, ndw, bin_file, offset=0):
        cmd = "nvme fw-download {} --fw={} --xfer={} --offset={}".format(
            self.dev, bin_file, ndw, offset)
        return self.__execute_command(cmd)

    def fw_active(self, action, slot):
        cmd = "nvme fw-activate {} --slot={} --action={}".format(self.dev, int(slot), int(action))
        return self.__execute_command(cmd)

    def fw_reset(self):
        cmd = "nvme reset {}".format(self.dev)
        return self.__execute_command(cmd)

    def upgrade_fw(self, fw_path, device_index=0, slot=2):
        self.dev = '/dev/nvme{}'.format(str(device_index))
        ret, out_put = self.fw_download(ndw=1000, bin_file=fw_path)
        if ret is True:
            ret, out_put = self.fw_active(action=1, slot=slot)
        if ret is True:
            ret, out_put = self.fw_reset()
        return ret, out_put
