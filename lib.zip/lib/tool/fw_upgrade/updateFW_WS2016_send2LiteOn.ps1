﻿param($a)
$sleeptime = 5
$LimitInSec = 20
### loop count
$MaxIter = 1
Write-Host("FW download path,$a")
$WarningCnt = 0
$WarningCnt_Iter_A = @()  ## keep track warning at what iteration#
$ErrorCnt = 0
$ErrorCnt_Iter_A = @() ## keep track warning at what iteration#

### FW Versions: N & N-1  need modify
$FW_LONKB960_N = $a
$FW_LONKB960_Nm1 = $a

$FW_N_A = @($FW_LONKB960_N)
$FW_Nm1_A = @($FW_LONKB960_Nm1)

### Model name  need modify
$PhyDiskInfo = @("LITEON AD2-KW960")

$pd = $NULL
$MyFW = $NULL
$MyStat = $NULL

filter timestamp
{
    "$( Get-Date -Format HH:mm:ss.fff ): $_"
}

foreach ($Iter in 1..$MaxIter)
{
    Write-Host ("******* iteration: $Iter of $MaxIter -- WarningCnt:$WarningCnt; ErrorCnt:$ErrorCnt" | timestamp)

    if ($WarningCnt)
    {
        Write-Host ("Number of Warnings: $WarningCnt (FW_Update time took longer than $LimitInSec seconds) " | timestamp)
        Write-Host ("   IterationList for Warning:")
        foreach ($i in $WarningCnt_Iter_A)
        {
            Write-Host ("      Found Warning at Iteration: $i" | timestamp)
        }
    }
    if ($ErrorCnt)
    {
        Write-Host ("Number of Errors: $ErrorCnt" | timestamp)
        Write-Host ("   IterationList for Error:" | timestamp)
        foreach ($i in $ErrorCnt_Iter_A)
        {
            Write-Host ("      !!! Found Error at Iteration: $i" | timestamp)
            set-psdebug step
        }
    }


    for ($DriveIdx = 0; $DriveIdx -lt $PhyDiskInfo.Length; $DriveIdx++)
    {
        if ($Iter%2)
        {
            $MyFW = $FW_N_A[$DriveIdx]
        }
        else
        {
            $MyFW = $FW_Nm1_A[$DriveIdx]
        }

        $pd = $NULL
        $MyDriveFWInfo = $NULL

        $pd = Get-PhysicalDisk -FriendlyName $PhyDiskInfo[$DriveIdx]
        $MyDriveFWInfo = $pd | Get-StorageFirmwareInformation
        $MyDriveFWInfo
        if ($MyDriveFWInfo.SupportsUpdate)
        {
            $MyCurDrive = $PhyDiskInfo[$DriveIdx]
            Write-Host ("   Updating FW $MyFW for $MyCurDrive" | timestamp)
            ### NumberOfSlots[0] = slot number
            for ($i = 1; $i -lt $MyDriveFWInfo.NumberOfSlots[0]; $i++)
            {
                if ($MyDriveFWInfo.IsSlotWritable[$i])
                {
                    $FWSlot = $MyDriveFWInfo.SlotNumber[$i]
                    Write-Host ("      FWSlotIdx:$i -- FW_SLOT:$FWSlot" | timestamp)

                    ## Download & Activate FW
                    ##
                    Write-Host ("      ... Starting DOWNLOAD & ACTIVATE FWSlot:$FWSlot" | timestamp)

                    $timeUpdateFW = Measure-Command{ $pd | Update-StorageFirmware -ImagePath $MyFW -SlotNumber $FWSlot }

                    Write-Host ("      ... download time: $timeUpdateFW.TotalSeconds" | timestamp)

                    $pd = $NULL
                    $myStat = $NULL

                    $pd = Get-PhysicalDisk -FriendlyName $MyCurDrive
                    $MyStat = $pd | Get-StorageFirmwareInformation


                    if ($MyStat.ActiveSlotNumber -ne $FWSlot)
                    {
                        Write-Host ("FAILED!!! FW update Failed, the Updated FW Slot DOESNOT Active" | timestamp)
                        write-Host ("          => Drive:$MyCurDrive and FWSLot:$FWSlot" | timestamp)
                        $ErrorCnt++
                        $ErrorCnt_Iter_A += $Iter
                        $MyStat
                        <#
                pause
				pause
				pause
				#>
                    }
                    else
                    {
                        $Time_Download_Activate_FW_inSec = $timeUpdateFW.TotalSeconds
                        if ($Time_Download_Activate_FW_inSec -gt $LimitInSec)
                        {
                            Write-Host ("WARNING!!! Time to download & update FW is longer than $LimitInSec seconds (actual time: $Time_Download_Activate_FW_inSec seconds)" | timestamp)
                            write-Host ("           => Drive:$MyCurDrive and FWSLot:$FWSlot" | timestamp)
                            $WarningCnt++
                            $WarningCnt_Iter_A += $Iter

                        }
                        else
                        {
                            Write-Host ("      ===> Time to download & update FW: $Time_Download_Activate_FW_inSec seconds `r`n" | timestamp)
                        }
                    }

                    Write-Host ("     ... sleep here $sleeptime seconds, before starting next iteration" | timestamp)
                    sleep $sleeptime
                }

            }
        }
        else
        {
            $MyDriveFWInfo
            $MyCurDrive = $PhyDiskInfo[$DriveIdx]
            Write-Host ("WARNING!!!=== $MyCurDrive (PhyDiskInfo[$DriveIdx] Doesn't have capability to update FW via WS2016 cmdlet ===!!!`r`n" | timestamp)
            $WarningCnt++
            $WarningCnt_Iter_A += $Iter
        }
        Write-Host ("`r`n======= END OF UPDATE FW for $MyCurDrive =======`r`n `r`n" | timestamp)
    }

}
if ($WarningCnt)
{
    Write-Host ("Number of Warnings: $WarningCnt (FW_Update time took longer than $LimitInSec seconds) " | timestamp)
    Write-Host ("IterationList for Warning:" | timestamp)
    foreach ($i in $WarningCnt_Iter_A)
    {
        Write-Host ("Found Warning at Iteration: $i" | timestamp)
    }
}
if ($ErrorCnt)
{
    Write-Host ("Number of Errors: $ErrorCnt" | timestamp)
    Write-Host ("IterationList for Error:" | timestamp)
    foreach ($i in $ErrorCnt_Iter_A)
    {
        Write-Host ("!!! Found Error at Iteration: $i" | timestamp)
    }

}

return $ErrorCnt
