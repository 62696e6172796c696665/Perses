#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os
import subprocess
import logging

from func_timeout import func_set_timeout, FunctionTimedOut
LOG = logging.getLogger()

class UpdaterWindows:

    def __init__(self):
        pass

    @func_set_timeout(60)
    def _execute_command(self, args):
        with subprocess.Popen(args, stdout=subprocess.PIPE) as process:
            code = process.wait()
            ret = process.stdout.read()
        LOG.info(ret.decode('utf-8', errors='ignore'))
        if code not in [0, 1]:
            raise Exception("execute_command failed, return code is :%s" % code)

    def download(self, fw_bin_file):
        if os.path.exists(fw_bin_file):
            try:
                args = ["powershell", "set-ExecutionPolicy", "RemoteSigned"]
                self._execute_command(args)
                ps_path = os.path.join(os.path.dirname(__file__), "updateFW_WS2016_send2LiteOn.ps1")
                args = [r"powershell", ps_path, fw_bin_file]
                self._execute_command(args)
            except FunctionTimedOut as exc:
                raise Exception("Firmware download is timeout (>60s)") from exc
        else:
            raise Exception("FW bin path not exist :%s" % fw_bin_file)
