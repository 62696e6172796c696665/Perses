#!/usr/bin/env python
# pylint: disable=too-many-statements
# pylint: disable=too-many-nested-blocks
"""
VDBENCH Operation

@author: yyang
"""
import logging
import os
import platform
import re
import sys
import stat
import shutil
import tempfile
from collections import OrderedDict
from multiprocessing import Process

import psutil

from lib.driver.utils.system import execute, mktmpfs

LOG = logging.getLogger()
DUMP = logging.getLogger('dump')
STATE_755 = stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH


class Vdbench:
    def __init__(self, lun, ver="504", mode="raw", clean=True, ramsize=80, single_wd=True, single_rd=True):
        self._is_clean = clean
        self._ramdisk = '/ramdisk'
        self._single_wd = single_wd
        self._single_rd = single_rd
        self._mode = mode
        self._proc = None
        self._args = None
        self._parm = None
        self._journal = None
        self._workload = tempfile.mktemp()
        self._lun = lun if isinstance(lun, list) else [lun]

        self._root = os.environ.get('PYTHONPATH', os.getcwd())
        assert os.path.exists(self._root), f"VDBENCH: Root path '{self._root}' is not exists!"

        self._vdbench = os.path.join(self._root, "tools", f'vdbench{ver}', "vdbench")
        assert os.path.exists(self._vdbench), f"VDBENCH: File '{self._vdbench}' is not exists!"

        if platform.system() == "Linux":
            # Workround: Vdbench start slow
            if not os.path.exists("/var/run/netns/netns"):
                execute(cmd="ip netns add netns")
            execute(cmd="ip netns exec netns ip link set dev lo up")

            if not os.access(self._vdbench, os.X_OK):
                os.chmod(self._vdbench, STATE_755)

            if self.is_netboot():
                assert 1 <= ramsize <= 80, f"VDBENCH: Ramdisk size '{ramsize}' must in [1, 80]"
                mktmpfs(self._ramdisk, ramsize * psutil.virtual_memory().total // 100)
            else:
                self._ramdisk = '/home/ramdisk'

            self._journal = os.path.join(self._ramdisk, os.path.basename(self._lun[0]))
            os.makedirs(self._journal, exist_ok=True)

        self.init()

    def __del__(self):
        # if platform.system() == "Linux" and os.path.exists("/var/run/netns/netns"):
        #     status, _ = execute(cmd="ip netns delete netns", cmdline=True, console=True, interrupt=True)
        #     assert status == 0, "delete netns: Status failed! Status: {:#x}".format(status)

        if self._proc:
            self.terminate()

        if self._is_clean:
            if os.path.exists(self._workload):
                LOG.info(f'VDBENCH: Remove {self._workload}')
                os.remove(self._workload)

            if isinstance(self._journal, str) and os.path.exists(self._journal):
                LOG.info(f'VDBENCH: Rmtree {self._journal}')
                shutil.rmtree(self._journal, ignore_errors=True)

    @property
    def journal(self):
        return self._journal

    @property
    def ramdisk(self):
        return self._ramdisk

    @property
    def workload(self):
        return self._workload

    @staticmethod
    def _time_to_int(_time):
        _time = str(_time).strip().lower()
        if _time.endswith('m'):
            return int(re.findall(r"([\d.]+)", _time)[0]) * 60
        if _time.endswith('h'):
            return int(re.findall(r"([\d.]+)", _time)[0]) * 3600
        if _time.endswith('d'):
            return int(re.findall(r"([\d.]+)", _time)[0]) * 3600 * 24
        if _time.endswith('w'):
            return int(re.findall(r"([\d.]+)", _time)[0]) * 3600 * 24 * 7
        return int(_time)

    @staticmethod
    def is_netboot():
        status, output = execute('df -h', cmdline=False, console=False)
        if status:
            return True
        return bool('172.29.190.3:/' in output)

    def _parse_args(self, jobfile):
        args = list()

        if jobfile:
            with open(jobfile, encoding='utf-8') as file:
                for line in file.readlines():
                    line = line.strip()
                    if line.startswith("sd") and "journal=" not in line and self._journal:
                        line += ",journal={}".format(self._journal)
                    args.append(line)
        else:
            for group in self._args:
                parms = [self._args[group]] if not isinstance(self._args[group], list) else self._args[group]

                for parm in parms:
                    items = list()
                    for key, val in parm.items():
                        items.append(f"{key}={val}")
                    args.append(','.join(items))

        return '\n'.join(args)

    def init(self):
        self._parm = OrderedDict()
        self._parm['gen'] = ['data_errors', 'compratio', 'validate', 'journal']
        if self._mode in ("raw", "inject"):
            self._parm['hd'] = ['hd', 'jvms']
            self._parm['sd'] = ['sd', 'lun', 'align', 'offset', 'size', 'range', 'threads', 'journal', 'openflags']
            self._parm['wd'] = ['wd', 'xfersize', 'rdpct', 'seekpct']
            self._parm['rd'] = ['rd', 'iorate', 'interval', 'elapsed', 'maxdata', 'warmup', 'pause', 'forcompratio',
                                'forrdpct', 'forseekpct', 'forthreads', 'forxfersize']
        else:
            self._parm['fsd'] = ['anchor', 'depth', 'width', 'files', 'size']
            self._parm['fwd'] = ['operation', 'xfersize', 'fileio', 'fileselect', 'threads']
            self._parm['frd'] = ['fwdrate', 'format', 'interval']

        self._args = OrderedDict()
        if self._mode in ("raw", "inject"):
            self._args['gen'] = OrderedDict()
            self._args['gen']['messagescan'] = 'no'
            if self._mode == "raw":
                self._args['gen']['data_errors'] = 1
            else:
                self._args['gen']['data_errors'] = 0xffffffff

            self._args['hd'] = OrderedDict()
            self._args['hd']['hd'] = 'default'

            self._args['sd'] = list()
            self._args['wd'] = list()
            self._args['rd'] = list()
            for i, lun in enumerate(self._lun):
                self._args['sd'].append(OrderedDict())
                self._args['sd'][i]['sd'] = f'sd{i+1}'
                self._args['sd'][i]['lun'] = lun
                self._args['sd'][i]['threads'] = 1
                if platform.system() == "Linux":
                    self._args['sd'][i]['openflags'] = 'o_direct'
                if self._journal:
                    self._args['sd'][i]['journal'] = self._journal

                if self._single_wd:
                    if i == 0:
                        self._args['wd'].append(OrderedDict())
                        self._args['wd'][i]['wd'] = f'wd{i+1}'
                        self._args['wd'][i]['sd'] = 'sd*'
                        self._args['wd'][i]['xfersize'] = '4k'
                        self._args['wd'][i]['rdpct'] = 0
                        self._args['wd'][i]['seekpct'] = 50
                else:
                    self._args['wd'].append(OrderedDict())
                    self._args['wd'][i]['wd'] = f'wd{i+1}'
                    self._args['wd'][i]['sd'] = f'sd{i+1}'
                    self._args['wd'][i]['xfersize'] = '4k'
                    self._args['wd'][i]['rdpct'] = 0
                    self._args['wd'][i]['seekpct'] = 50

                if self._single_rd:
                    if i == 0:
                        self._args['rd'].append(OrderedDict())
                        self._args['rd'][i]['rd'] = f'rd{i+1}'
                        self._args['rd'][i]['wd'] = 'wd*'
                        self._args['rd'][i]['iorate'] = 'max'
                else:
                    self._args['rd'].append(OrderedDict())
                    self._args['rd'][i]['rd'] = f'rd{i+1}'
                    self._args['rd'][i]['wd'] = f'wd{i+1}'
                    self._args['rd'][i]['iorate'] = 'max'
        else:
            self._args['gen'] = OrderedDict()
            self._args['gen']['data_errors'] = 1

            self._args['fsd'] = list()
            self._args['fwd'] = list()
            self._args['frd'] = list()
            for i, lun in enumerate(self._lun):
                self._args['fsd'].append(OrderedDict())
                self._args['fsd'][i]['fsd'] = f'fsd{i+1}'
                self._args['fsd'][i]['anchor'] = lun
                self._args['fsd'][i]['depth'] = 1
                self._args['fsd'][i]['width'] = 1
                self._args['fsd'][i]['file'] = 1
                self._args['fsd'][i]['size'] = '4k'
                if self._journal:
                    self._args['fsd'][i]['journal'] = self._journal

                if self._single_wd:
                    if i == 0:
                        self._args['fwd'].append(OrderedDict())
                        self._args['fwd'][i]['fwd'] = f'fwd{i+1}'
                        self._args['fwd'][i]['fsd'] = 'fsd*'
                        self._args['fwd'][i]['operation'] = 'read'
                        self._args['fwd'][i]['xfersize'] = '4k'
                        self._args['fwd'][i]['fileio'] = 'sequential'
                        self._args['fwd'][i]['fileselect'] = 'sequential'
                        self._args['fwd'][i]['threads'] = 1
                else:
                    self._args['fwd'].append(OrderedDict())
                    self._args['fwd'][i]['fwd'] = f'fwd{i+1}'
                    self._args['fwd'][i]['fsd'] = f'fsd{i+1}'
                    self._args['fwd'][i]['operation'] = 'read'
                    self._args['fwd'][i]['xfersize'] = '4k'
                    self._args['fwd'][i]['fileio'] = 'sequential'
                    self._args['fwd'][i]['fileselect'] = 'sequential'
                    self._args['fwd'][i]['threads'] = 1

                if self._single_rd:
                    if i == 0:
                        self._args['frd'].append(OrderedDict())
                        self._args['frd'][i]['rd'] = f'rd{i+1}'
                        self._args['frd'][i]['fwd'] = 'fwd*'
                        self._args['frd'][i]['fwdrate'] = 'max'
                        self._args['frd'][i]['format'] = 'yes'
                else:
                    self._args['frd'].append(OrderedDict())
                    self._args['frd'][i]['rd'] = f'rd{i+1}'
                    self._args['frd'][i]['fwd'] = f'fwd{i+1}'
                    self._args['frd'][i]['fwdrate'] = 'max'
                    self._args['frd'][i]['format'] = 'yes'

    def del_parm(self, key, index=None):
        for group in self._args:
            if key in self._args[group]:
                if isinstance(self._args[group], list):
                    if index is None:
                        for i in range(len(self._args[group])):
                            del self._args[group][i][key]
                    else:
                        del self._args[group][index][key]
                else:
                    del self._args[group][key]
                break

    def set_parm(self, key, val=None, index=None):
        for group in self._args:
            if key in self._parm[group]:
                if val is not None:
                    if isinstance(self._args[group], list):
                        if index is None:
                            for i in range(len(self._args[group])):
                                self._args[group][i][key] = val
                        else:
                            self._args[group][index][key] = val
                    else:
                        self._args[group][key] = val
                return
        assert False, "VDBENCH: Parameter '{}' is unknown!".format(key)

    def import_dict(self, **kwargs):
        for key, val in kwargs.items():
            self.set_parm(key, val)

    def start_with_file(self, filename, verify=False):
        option = None if verify is False else '-v'
        return self.start(option, jobfile=filename)

    def start(self, option=None, jobfile=None, cmdline=True, console=True, interrupt=True):
        """
        Start vdbench workload
        :param option:      It can be None, string or list.
                            If it is a list, will connect as a string with blank.
        :param jobfile:     Workload parameter file
        :param cmdline:     Echo cmdline when it is True
        :param console:     Echo output when it is True
        :param interrupt:   Enable assert when vdbench return error code
        :return:    Status: Zero is succeed, non-zero is failed
                    output: Output of stdout and stderr
        """
        for dev in self._lun:
            assert os.path.exists(dev), f"VDBENCH: Lun '{dev}' is not exists!"

        if platform.system() == "Linux":
            cmd = ["ip netns exec netns", self._vdbench]
        else:
            cmd = [self._vdbench]

        if option:
            if isinstance(option, list):
                cmd.extend(option)
            else:
                cmd.append(option)

        args = self._parse_args(jobfile)
        with open(self._workload, 'w', encoding='utf-8') as file:
            file.write(args)

        if cmdline:
            DUMP.info(args)

        cmd.extend(['-f', self._workload])
        if self._journal:
            cmd.extend(['-o', self._journal])

        return execute(cmd, cmdline=cmdline, console=console, interrupt=interrupt)

    def _start(self, *args, **kwargs):
        status, output = self.start(*args, **kwargs)

        if status and args[3] is False:
            DUMP.info(output)
            LOG.error("VDBENCH: Process failed! Status: 0x%x", status)

        sys.exit(status)

    def run(self, option=None, jobfile=None, cmdline=False, console=False):
        self._proc = Process(target=self._start, args=(option, jobfile, cmdline, console, False))
        self._proc.start()

    def join(self, timeout=None):
        assert self._proc, "VDBENCH: Process is not start!"
        self._proc.join(timeout)

    def is_alive(self):
        if self._proc:
            return self._proc.is_alive()
        return 0

    def exitcode(self):
        assert self._proc, "VDBENCH: Process is not start!"
        return self._proc.exitcode

    def terminate(self):
        if self.is_alive():
            try:
                LOG.info("VDBENCH: Process terminate!")
                parent = psutil.Process(self._proc.pid)
                for proc in parent.children(recursive=True) + [parent]:
                    proc.terminate()
            except Exception as exp:
                LOG.error(exp)
                return 1
        return 0
