#!/usr/bin/env python
# pylint: disable=arguments-differ
import logging
import os
import time

from lib.driver.nvme import NVMe
from lib.driver.nvme.nvme import CNEX
from lib.tool.fio.fio import Fio
from lib.tool.powercycle.power_cycle import PowerCycle
from lib.tool.vdbench import Vdbench

LOG = logging.getLogger()


class PowerCycleAtomic(PowerCycle):

    def __init__(self, device="nvme0n1"):
        LOG.info('Enter in PowerCycleAtomic,__init__: %s', time.strftime("%Y-%m-%d %H:%M:%S"))

        super().__init__(device=device)

    @staticmethod
    def get_loop():
        LOG.info('Enter in PowerCycleAtomic,get_loop: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        return os.environ.get('loop', 1)

    @staticmethod
    def is_before_reboot():
        LOG.info('Enter in PowerCycleAtomic, is_before_reboot: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        if "before_reboot" in os.environ:
            value = os.environ["before_reboot"]
            before_reboot = bool(value == "true")
        else:
            before_reboot = False
        return before_reboot

    def power_off(self, delay=3):
        LOG.info('Enter in PowerCycleAtomic, power_off: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        super().power_off()
        time.sleep(delay)

    def power_on(self, delay=3):
        LOG.info('Enter in PowerCycleAtomic, power_on: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        super().power_on()
        time.sleep(delay)

    @staticmethod
    def execute_pfail(delay=3):
        LOG.info('Enter in PowerCycleAtomic, execute_pfail: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        reg_pfail = 0x4213c
        CNEX().rdma_write(reg_pfail, 0)
        time.sleep(delay)

    def execute_crash(self):
        self.power_off()
        self.power_on()

    def pfail_when_power_down(self, delay=1):
        LOG.info('RemoveAllDrive: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        self.remove_all_drive()
        time.sleep(delay)

        LOG.info('Enter in PowerCycleAtomic, execute_pfail: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        reg_pfail = 0x4213c
        CNEX().rdma_write(reg_pfail, 0)
        time.sleep(5)

    @staticmethod
    def run_fio(fio_case):
        LOG.info('Enter in PowerCycleAtomic, run_fio: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        return Fio().run_fio_file_auto_detection_dev(fio_case)

    def run_vd(self, test_args):
        LOG.info('Enter in PowerCycleAtomic, run_vd: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        dev_name = '/dev/%s' % self.device
        vd_test = Vdbench(dev_name)
        for key, val in test_args.items():
            vd_test.set_parm(key, val)
        vd_test.start("-v")

    def download_fw(self):
        nvme = NVMe()
        if os.environ.get('fw_path') is not None:
            nvme.fw_download(os.environ.get('fw_path'))

    def upgrade_fw(self, active=3, slot=2):
        nvme = NVMe()
        nvme.fw_commit(active, slot)
        if active in ('1', '2'):
            nvme.reset()
