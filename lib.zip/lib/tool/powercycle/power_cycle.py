#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging
import os
import random
import re
import time

from lib.driver.utils import system
from lib.driver.nvme import NVMe
from lib.tool.cp210x import CP210X
from lib.tool.usbrelay.usbrelay import UsbRelay

LOG = logging.getLogger()


class PowerCycle:

    def __init__(self, device=None):
        self.nvme = NVMe()
        if device is None:
            self.device = self.nvme.block_dev
        else:
            self.device = device
        # self.nvme_num = int(self.device[4])
        self.unvme = self.find_unvme()

    @staticmethod
    def find_device():
        _, output = system.execute('nvme list')
        ret = re.compile("nvme(.)n(.)").findall(output)
        # print(ret[0])
        return ret[0]

    @staticmethod
    def find_unvme():
        path = os.path.join(os.getcwd(), 'tools', 'uNvmeMaster', 'uNvmeMaster')
        assert os.path.exists(path), "Can not found uNvmeMaster: {}!".format(path)
        return path

    def remove_all_drive(self, delay=5):
        LOG.info('RemoveAllDrive:  %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        for device in self.nvme.devices:
            cmd = 'echo 1 > /sys/bus/pci/devices/{s}/remove'.format(s=device["slot"])
            LOG.info("%s", cmd)
            LOG.info(os.popen(cmd).read())
            time.sleep(delay)

    def scan_ssd(self):
        LOG.info('ScanSSD:  %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        cmd = '%s -m MFG -c ScanSSD' % self.unvme
        system.execute(cmd)
        time.sleep(5)
        LOG.info("ScanSSD done")

    def scan_and_find_device(self, retry=10):
        for i in range(retry):
            LOG.info('Scan and find device, retry: %d', i)
            self.scan_ssd()
            if self.find_device():
                return
        raise AssertionError('Can not found nvme device!')

    @staticmethod
    def power_on():
        if os.environ.get('adapter', 'usbrelay') == 'usbrelay':
            UsbRelay().power_on()
        else:
            CP210X().power_on()

    @staticmethod
    def power_off():
        if os.environ.get('adapter', 'usbrelay') == 'usbrelay':
            UsbRelay().power_off()
        else:
            CP210X().power_off()

    def power_cycle(self, crash_flg=0, delay=0):
        time.sleep(delay)
        if crash_flg == 0:
            self.remove_all_drive()

        self.power_off()
        time.sleep(5)

        self.power_on()
        time.sleep(30)

        self.scan_and_find_device()

    def power_cycle_ab(self, crash_flg=0, delay=0, cnt=5):
        LOG.info("Do Power cycle[isCrash:%d] with delay[%f]", crash_flg, delay)
        time.sleep(delay)
        if crash_flg == 0:
            self.remove_all_drive()

        delta_l = [0.1, 0.3, 0.5, 0.8, 1]
        for i in range(cnt):
            LOG.info('Power cycle, loop: %d', i)

            self.power_off()
            time.sleep(random.choice(delta_l))

            self.power_on()
            time.sleep(random.choice(delta_l) + 1)

        time.sleep(30)
        self.scan_and_find_device()

    # def collect_ssd_temp(self, dic, lock):
    #     i = 0
    #     last_str = ''
    #     LOG.info('++++++++++++++++++++++++++++++++++ Start Temperature Monitor ++++++++++++++++++++++++++++++++++')
    #     with lock:
    #         flag = dic.get('flag', 0)
    #
    #     if flag == 1:
    #         while i >= 0:
    #             with lock:
    #                 flag = dic['flag']
    #             if flag == '-----power_off_EndTemperatureMonitor------' or \
    #                     flag == '------power_on_GoonTemperatureMonitor-----':
    #                 if flag != last_str:
    #                     LOG.info(flag)
    #                     last_str = flag
    #
    #             elif flag != 0:
    #                 if flag != 1 and (flag != last_str):
    #                     LOG.info(flag)
    #                     last_str = flag
    #                 checksmart = '%s -d %s -m MFG -c GetSmartInfo' % (self.unvme, self.nvme_num)
    #                 readsmartlog = os.popen(checksmart).read()
    #                 checksmartresult = str(i) + " ASIC_T:" + \
    #                                    readsmartlog.split('ASIC Temperature')[1].split('\n')[0].split(':')[
    #                                        1] + " NAND_T:" + \
    #                                    readsmartlog.split('NAND Temperature')[1].split('\n')[0].split(':')[
    #                                        1] + " DDR_T:" + \
    #                                    readsmartlog.split('DDR Temperature')[1].split('\n')[0].split(':')[
    #                                        1] + " Available Spare:" + \
    #                                    readsmartlog.split('Available Spare')[1].split('\n')[0].split(':')[
    #                                        1] + " Unsafe Shutdowns:" + \
    #                                    readsmartlog.split('Unsafe Shutdowns')[1].split('\n')[0].split(':')[
    #                                        1] + " Critical Warning:" + \
    #                                    readsmartlog.split('Critical Warning ')[1].split('\n')[0].split(':')[1]
    #                 time.sleep(5)
    #                 LOG.info(checksmartresult)
    #
    #                 i = i + 1
    #             elif flag == 0:
    #                 LOG.info('+++++++++++++++++++++++++++++ End Temperature Monitor +++++++++++++++++++++++++++++')
    #                 break
