#!/usr/bin/env python
# coding=utf-8
# pylint: disable=bad-option-value,consider-using-with,unspecified-encoding,too-many-format-args
"""
FIO operation

@author: yyang
"""
import logging
import platform
import random
import re
import os
from multiprocessing import Process
import psutil
from lib.driver.utils import buf
from lib.driver.utils.system import execute
from lib.driver.utils.ctype import Ctype
from lib.driver.nvme import Tahoe

LOG = logging.getLogger()

class Sedutil:
    def __init__(self, nvme=None, interrupt=True):
        system = platform.system()
        if system == "Linux":
            LOG.info("Linux system")
        self.nvme = Tahoe() if nvme is None else nvme
        self.dev = self.nvme.char_dev
        self.thread = None
        self.datafile = None
        self.output = None
        self.passwd = 'password'
        self.interrupt = interrupt
        self.datastore_data = buf.Malloc(10485760) #10485760
        self.datastore_data.memset(0)

    def _set_datastore_file(self):
        work_path = os.path.abspath(os.curdir)
        drive_sn = Ctype(self.nvme.identify_ctrl()).get('SN')
        self.datafile = os.path.join(work_path, f'datastore_in_{drive_sn}')
        self.output = os.path.join(work_path, f'datastore_out_{drive_sn}')

    def _delete_datastore_file(self):
        for file in [self.datafile, self.output]:
            if os.path.exists(file):
                LOG.info(f'TCG: Remove {file}')
                os.remove(file)

    @staticmethod
    def sedutil_exist():
        pass
    def update_dev(self, nvme):
        self.nvme = nvme
        self.dev = self.nvme.char_dev

    def reset_buf(self):
        self.datastore_data.memset(0)

    def active_lsp(self):
        LOG.info("Active TCG")
        cmd = r'sedutil-cli --takeOwnership {} {}'.format(self.passwd, self.dev)
        self._start(cmd, True)
        cmd = r'sedutil-cli --activateLockingSP {} {}'.format(self.passwd, self.dev)
        self._start(cmd, True)
        self._set_datastore_file()

    def revert(self):
        LOG.info("Revert TCG")
        cmd = r'sedutil-cli --reverttper {} {}'.format(self.passwd, self.dev)
        self._start(cmd, True)
        self._delete_datastore_file()

    def datastore_write(self, offset=0, length=10485760, table=1, pattern=0):
        LOG.warning("datastore_write: offset:%d, length:%d, table:%d, pattern:%d", offset, length, table, pattern)
        tmp = buf.Malloc(length)
        #tmp.fill_uint32_rnd(seed=random.randint(0, 20000))
        tmp.fill_uint32_seq(pattern)
        tmp.write(self.datafile)
        self.datastore_data.memmove(offset, tmp, 0, length)
        #tmp.dump()
        #self.datastore_data.dump()
        cmd = r'sedutil-cli --loadDataStore {} {} {} {} {} {}'.format\
            (self.passwd, table, offset, length, self.datafile, self.dev)
        return self._start(cmd, True)

    def datastore_read(self, offset=0, length=10485760, table=1, do_compare=0):
        LOG.warning("datastore_read: offset:%d, length:%d, table:%d", offset, length, table)
        cmd = r'sedutil-cli --readDataStore {} {} {} {} {}'.format\
            (self.passwd, table, offset, length, self.dev, self.output)
        ret = self._start(cmd, True)
        if do_compare:
            self.compare(ret, offset, length)

    def mbr_write(self, length=10485760):
        LOG.warning("mbr_write: length:%d", length)
        tmp = buf.Malloc(length)
        tmp.fill_uint32_rnd(seed=random.randint(0, 20000))
        tmp.write(self.datafile)
        self.datastore_data.memmove(0, tmp, 0, length)
        cmd = r'sedutil-cli --loadPBAimage {} {} {}'.format\
            (self.passwd, self.datafile, self.dev)
        return self._start(cmd, True)

    def mbr_read(self, offset=0, length=10485760, table=1, do_compare=0):
        LOG.warning("mbr_read: offset:%d, length:%d, table:%d", offset, length, table)
        cmd = r'sedutil-cli --readMBR {} {} {} {}'.format(self.passwd, offset, length, self.dev)
        ret = self._start(cmd, True)
        if do_compare:
            self.compare(ret, offset, length)

    def _start(self, cmd, cmdline=True, args=None):
        status, output = execute(cmd, cmdline, console=False, interrupt=False)
        #LOG.info(output)
        if status and self.interrupt:
            raise RuntimeError("Run Sedutil failed!")
        return output

    def compare(self, ret, offset, length):
        output = self.convert_output(ret, length)
        compare_ret = output.compare(self.datastore_data.set_sub_buffer(offset, length))
        if compare_ret:
            print(f'compare result {compare_ret}')
            LOG.info(ret)
            raise RuntimeError("Datastore compare failed!")

    def convert_output(self, output, length):
        data = buf.Malloc(length)
        #print("convert output")
        #print(output)
        #print(output.split('\n'))
        idx = 0
        #if length%4 != 0:
        #    raise RuntimeError("Not support DW unaligned compare")
        for line in output.split('\n'):
            ret = line.split(' ')
            for dw in ret:
                if re.match(r'\w\w\w\w\w\w\w\w$', dw):
                    if (idx)*4 < length:
                        #print(f"idx: {idx+j} j{j}: {ret[j+1]}")
                        if not dw:
                            print(f'Line: {line} DW:{dw}')
                        dw = int(dw, 16)
                        data.set_uint8((idx)*4+0, (dw>>24)&0xff)
                        data.set_uint8((idx)*4+1, (dw>>16)&0xff)
                        data.set_uint8((idx)*4+2, (dw>>8)&0xff)
                        data.set_uint8((idx)*4+3, (dw)&0xff)
                        idx += 1
                    else:
                        break

        #data.dump_uint32()
        #data.write('tmp.txt')
        return data
        #for i in range(0, length, 4):
        #    data.set_uint32(int(i/4), pickdw(output, ))


    def is_alive(self):
        #assert self.thread, "PROCESS: Vdbench is not start!"
        if self.thread:
            return self.thread.is_alive()
        return 0

    def run(self, cmd, cmdline=True, **kwargs):
        #self.thread = Threads(target=self._start, args=(jobfile, section, cmdline, outfile, kwargs))
        #self.thread.daemon = True
        #self.thread.start()
        self.thread = Process(target=self._start, args=(cmd, cmdline, kwargs))
        self.thread.start()

    def join(self, timeout=None):
        if self.thread:
            self.thread.join()
        else:
            raise RuntimeError("Fio thread is not set!")

    def get_result(self):
        if self.thread:
            status = self.thread.exitcode
            self.thread = None
        else:
            raise RuntimeError("FIO thread is not set!")
        return status, "No output"

    def terminate(self):
        if self.is_alive():
            LOG.warning("PROCESS: Terminate Sedutil!")

            try:
                parent = psutil.Process(self.thread.pid)
                for proc in parent.children(recursive=True) + [parent]:
                    proc.terminate()
            except Exception as err:
                LOG.error(err)
                return 1
        return 0
