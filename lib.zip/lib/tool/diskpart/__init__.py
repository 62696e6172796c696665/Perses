from lib.tool.diskpart.diskpart import format_raw, format_x, format_gpt
