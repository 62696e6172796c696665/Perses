#! /usr/bin/python
## -*- coding: utf-8 -*-
# pylint: disable=import-error
import logging
import os
import re
import subprocess
import time

import autoit

from lib.driver.utils.system import get_root_path

LOG = logging.getLogger()


class BurnIn:

    def __init__(self):
        self.name_ = "burnin"
        self.burnin_popen = None
        self.root_path = get_root_path()
        self.burn_in_path = r"C:\Program Files\BurnInTest"
        self.burn_config_path = os.path.join(self.root_path, "lib", "tool", "burnin")

    @property
    def name(self):
        return self.name_

    def get_burn_in_path(self):
        return self.burn_in_path

    def get_version(self):
        read_me_file = os.path.join(self.burn_in_path, "Readme.txt")
        with open(read_me_file, encoding='utf-8') as file:
            content = file.readline()
        #print(content)
        version_ = re.findall("\(TM\)\sV(.+)", content)
        return version_[0]

    def run_test(self, config_file):
        config_path = os.path.join(self.burn_config_path, config_file)
        tst_cmd = "cd /d \"{}\" && bit.exe  -C {} -r".format(self.burn_in_path, config_path)
        self.burnin_popen = subprocess.Popen(tst_cmd, shell=True)   # pylint: disable=consider-using-with

    def close(self):
        cmd = "taskkill  /F /T /PID {}".format(self.burnin_popen.pid)
        ret = os.system(cmd)
        LOG.info("close: %d", (ret))

    def kill(self):
        command = 'taskkill /F /T /IM bit.exe'
        os.system(command)

    def _get_state_control_txt(self):
        autoit.win_activate("[CLASS:bit]")
        handle_ = autoit.win_get_handle("[CLASS:bit]")
        h_ctrl = autoit.control_get_handle(handle_, control="[ID:14004]")
        txt = autoit.control_get_text_by_handle(handle_, h_ctrl)
        return txt.lower()

    def check_test_state_from_ui(self):
        if autoit.win_exists("[CLASS:bit]") == 1:
            txt = self._get_state_control_txt()
            errors = re.findall("([0-9]+)\s+errors", txt)
            errors_count = errors[0] if errors else 0
            ret = "fail" if "fail" in txt else "pass" if "pass" in txt else "running"
        else:
            raise RuntimeError("Burning is abnormal closed when test is running!")
        return ret, errors_count

    def wait_and_return_result(self):
        time.sleep(30)
        while True:
            try:
                state_, errors_ = self.check_test_state_from_ui()
            except autoit.AutoItError:
                state_, errors_ = "running", 0
            if state_ == "running":
                LOG.info("Burnin is: %s ,errors %s", state_, errors_)
                time.sleep(10)
            else:
                return state_, errors_


if __name__ == '__main__':
    pass
