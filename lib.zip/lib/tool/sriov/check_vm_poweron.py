#!/usr/bin/env python
"""

@athor: weifeng.guo
@data:2019/7/31 11:33
@filename: sriov

"""
import logging
# pylint: disable=superfluous-parens,missing-docstring,invalid-name,anomalous-backslash-in-string,too-many-locals,broad-except
import sys
import time

import paramiko

LOG = logging.getLogger()
SRIOV_SCRIPT_PATH = "/home/nvme/jenkins/vm/workspace/script/venus/testcase/productTest/sriov/"


class LBAPowerCycleLocalOperate:
    def __init__(self, ip='192.168.122.58', user='root', pswd='nvme'):
        self.ip = ip
        self.user = user
        self.pswd = pswd
        self.ssh = paramiko.SSHClient()

    def open_ssh(self):
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        while (True):
            try:
                self.ssh.connect(self.ip, 22, self.user, self.pswd)
            except Exception as e:
                LOG.exception(e)
                LOG.info('Connect fail--------')
                time.sleep(1)
                continue
            LOG.info('Connect pass--------')
            break

    def close_ssh(self):
        self.ssh.close()

    def run_tc(self, cmd, chk=1):
        self.open_ssh()
        (_, stdout, _) = self.ssh.exec_command(cmd)
        if ((stdout.channel.recv_exit_status() != 0) and (chk == 1)):
            LOG.info("[%s]-> exec_command %s failed!!!", sys.argv[0], cmd)
            LOG.info("%s failed![%s]", cmd, stdout.read())
        self.close_ssh()

    @staticmethod
    def gen_cmd(vf_id, ns_id):
        cmd = "cd %s;python sriov_single_port_pf+vm_std_create_1vfto1ns.py -v %d -i " \
              "%d " % (SRIOV_SCRIPT_PATH, vf_id, ns_id)
        # cmd = "cd /home/nvme/ubuntu-16.10-1;python
        # sriov_single_port_pf+vm_std_create_1vfto1ns.py -v 4"
        return cmd

# if __name__ == '__main__':
#     try:
#         cmd_pf="cd /home/nvme/automation;python run.py"
#         stat1 = os.system(cmd_pf)
#         if stat1 != 0:
#             exit(1)
#         po = LBAPowerCycleLocalOperate()
#         cmd= po.gen_cmd()
#         po.runTc(cmd)
#     except Exception as e:
# LOG.info(e.message)
