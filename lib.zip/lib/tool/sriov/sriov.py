#!/usr/bin/env python
# coding=utf-8
"""
athor: weifeng.guo
data:2019/7/31 11:33
filename: sriov
"""
import logging
# pylint: disable=superfluous-parens,missing-docstring,invalid-name,anomalous-backslash-in-string,too-many-locals,too-many-public-methods,too-many-function-args, too-many-instance-attributes, too-many-arguments, no-member
import os
import random
import re
import time

from nose.tools import assert_equal

from lib.driver.nvme import LBAOperate
from lib.driver.nvme import NVMe
from lib.driver.utils import pcie
from lib.driver.utils import system
from lib.tool.fio.fio_linux import Fio
from lib.tool.vdbench import Vdbench

LOG = logging.getLogger()

GLOBAL = {
    "range": "(0,100)",
    "threads": "128",
    "elapsed": "60",
    "interval": "1",
    "xfersize": "4k"
}
XFERSIZE = "(4k,20,16k,20,32k,20,64k,20,128k,20)"
XFERSIZE_512 = '(512,20,4k,20,32k,10,35k,20,64k,30)'


class Sriov:

    def __init__(self, retry=5):
        # self.nvme = NVME()
        self.max_total = 0xf000000
        self.nsid_list_pf = {}
        self.nsid_dic_1vf_1ns = {}
        self.nsid_dic_multi_vf_1ns = {}
        self.nsid_dic_1vf_2ns = {}
        self.nsid_dic_1vf_1ns_vm = {}
        self.nsid_dic_1vf_2ns_vm = {}
        self.nsid_dic_diff_size = {}
        self.retry_time = retry
        self.pcie = pcie.PCIe()

    def find_nvme(self):
        cmd = 'ls /dev/nvme*'
        _, output = system.execute(cmd)
        # print(output)
        dev = re.compile("nvme(.)").findall(output)
        dev = (list(map(int, dev)))
        return (list(set(dev)))

    def find_vfs(self):
        devs = self.find_nvme()
        devs.remove(0)
        return devs

    def ns_manage(self, cid, is_create, do_attach=0, nsize=0, ncap=0, vs_type=0, nmic=1, del_ns=0xffffffff):
        LOG.info("Start create namespace[cid:%d][isCreate:%d, doAttach:%d]", cid, is_create, do_attach)
        dev = NVMe(cntid=cid)
        nsid = 0
        if is_create:
            _, nsid = dev.create_ns(nsize, ncap, vs_type, nmic=nmic)
            LOG.info("create namespace[%d]", nsid)
        else:
            dev.delete_ns(del_ns)
        time.sleep(1)
        if do_attach:
            cntid = self.get_ctrl_id(cid)
            dev.attach_ns(cntid, nsid)
            LOG.info("attach namespace[cntid:%d, nsid:%d]", cntid[0], nsid)
        return nsid

    def create_ns_pf(self, max_ns, cap, ns_size, lbaf=0):
        for i in range(0, max_ns):
            vfid = i + 1
            ns_id = self.ns_manage(0, 1, 1, ns_size, cap, lbaf)
            self.nsid_list_pf[vfid] = ns_id
            time.sleep(2)

    def delete_ns_pf(self):
        self.ns_manage(0, 0)

    @staticmethod
    def controller_reset(dev):
        LOG.info("controller level reset")
        cmd1 = "nvme reset /dev/{}".format(dev)
        # cmd1 = "nvme subsystem-reset /dev/nvme0"
        stat1 = os.system(cmd1)
        if stat1 != 0:
            LOG.info("controller level reset failed")
            return

    @staticmethod
    def controller_reboot():
        cmd = "reboot"
        LOG.info(cmd)
        stat1 = os.system(cmd)
        time.sleep(15)
        if stat1 != 0:
            LOG.info("reboot failed")
            return

    def switch_sriov_drv(self, on):
        cmd = "echo {} > /sys/bus/pci/devices/{}/sriov_drivers_autoprobe".format(on, self.pcie.bdf)
        stat = os.system(cmd)
        if stat != 0:
            LOG.info("switch sriov drv fail!")
            return

    @staticmethod
    def bind_nvme(bdf):
        cmd = "echo -n '{}' > /sys/bus/pci/drivers/nvme/bind".format(bdf)
        stat = os.system(cmd)
        if stat != 0:
            LOG.info("switch sriov drv fail!")
            return

    def enable_vf(self, num_vf):
        LOG.info("1.enable %d VF", num_vf)
        cmd = "echo {} > /sys/bus/pci/devices/{}/sriov_numvfs".format(num_vf, self.pcie.bdf)
        cnt = self.retry_time
        while (cnt > 0):
            stat = os.system(cmd)
            if stat == 0:
                time.sleep(2 * num_vf)
                return
            cnt = cnt - 1
            time.sleep(1)
        raise RuntimeError('Enable SRIOV VF Fail after retry {} times'.format(self.retry_time))

    def disable_vf(self, num_vf):
        LOG.info("2.disable all VF")
        cmd = "echo 0 > /sys/bus/pci/devices/{}/sriov_numvfs".format(self.pcie.bdf)
        cnt = self.retry_time
        while (cnt > 0):
            stat = os.system(cmd)
            if stat == 0:
                time.sleep(2 * num_vf)
                return
            cnt = cnt - 1
            time.sleep(1)
        raise RuntimeError('Disable SRIOV VF Fail after retry {} times'.format(self.retry_time))

    @staticmethod
    def get_ctrl_id(cid=0):
        nvme = NVMe(cntid=cid)
        id_ctrl = nvme.identify_ctrl()
        return [id_ctrl.CNTLID]

    def delete_all_ns(self, cid=0):
        LOG.info('delete all namespace')
        dev = NVMe(cntid=0)
        dev.delete_ns(0xffffffff)
        time.sleep(2)

    def create_1vf_1ns(self, max_vf, ns_size, cap, vs_type=0):
        for i in range(0, max_vf):
            vfid = i + 1
            nsid = self.ns_manage(vfid, 1, 1, ns_size, cap, vs_type)
            self.nsid_dic_1vf_1ns[vfid] = nsid

    def delete_1vf_1ns(self):
        for key, _ in self.nsid_dic_1vf_1ns.items():
            self.ns_manage(key, 0)

    def create_multi_vf_1ns(self, max_vf, ns_size, cap, vs_type=0):
        nsid = self.ns_manage(0, 1, 1, ns_size, cap)
        time.sleep(1)

        for key in self.find_vfs():
            key = int(key)
            LOG.info('attach namespace[%d] to controller[%d]', nsid, key)
            cntid = self.get_ctrl_id(key)
            dev = NVMe(cntid=key)
            dev.attach_ns(cntid, nsid)
            time.sleep(2)

    def delete_multi_vf_1ns(self):
        for key in self.find_vfs():
            self.ns_manage(key, 0)
            LOG.info("delete ns pass")
            time.sleep(2)

    def create_1vf_2ns(self, maxvf, ns_size, cap, vs_type=0):
        nsid_list = []
        for i in range(0, maxvf):
            time.sleep(2)
            vfid = i + 1
            nsid_list.append(self.ns_manage(vfid, 1, 1, ns_size, cap, vs_type))
            nsid_list.append(self.ns_manage(vfid, 1, 1, ns_size, cap, vs_type))
            self.nsid_dic_1vf_2ns[vfid] = nsid_list
            nsid_list = []
        time.sleep(2)

    def delete_1vf_2ns(self):
        for key, _ in self.nsid_dic_1vf_2ns.items():
            self.ns_manage(key, 0)

    def create_1vf_1ns_vm(self, max_vf, ns_size, cap, vs_type=0):
        for i in range(0, max_vf):
            vfid = i
            nsid = self.ns_manage(vfid, 1, 1, ns_size, cap, vs_type)
            self.nsid_dic_1vf_1ns_vm[vfid] = int(nsid)
            time.sleep(2)

    def delete_1vf_1ns_vm(self):
        for key, _ in self.nsid_dic_1vf_1ns_vm.items():
            self.ns_manage(key, 0)
            time.sleep(2)

    def create_1vf_2ns_vm(self, maxvf, ns_size, cap, vs_type=0):
        nsid_list = []
        for i in range(0, maxvf):
            vfid = i
            nsid_list.append(self.ns_manage(vfid, 1, 1, ns_size, cap, vs_type))
            nsid_list.append(self.ns_manage(vfid, 1, 1, ns_size, cap, vs_type))
            self.nsid_dic_1vf_2ns_vm[vfid] = nsid_list
            nsid_list = []
        time.sleep(2)

    def delete_1vf_2ns_vm(self):
        for key, _ in self.nsid_dic_1vf_2ns_vm.items():
            self.ns_manage(key, 0)
            time.sleep(2)

    def create_ns_diff_size(self, max_vf, lbaf=0):
        for i in range(0, max_vf):
            time.sleep(2)
            size_sect = random.randint(max_vf, max_vf + i)
            ns_size = hex(self.max_total / size_sect)
            ns_cap = ns_size
            vfid = i + 1
            nsid = self.ns_manage(vfid, 1, 1, ns_size, ns_cap, lbaf)
            self.nsid_dic_diff_size[vfid] = nsid
            time.sleep(5)

    def delete_ns_diff_size(self):
        for key, _ in self.nsid_dic_diff_size.items():
            self.ns_manage(key, 0)

    @staticmethod
    def rw_vdbench_verify(dev=None, rdpct=0, seekpct=0):
        if dev is None:
            dev = NVMe().block_dev
        vd = Vdbench(dev)
        vd.import_dict(**GLOBAL)
        vd.set_parm('xfersize', XFERSIZE)
        vd.set_parm('rdpct', str(rdpct))
        vd.set_parm('seekpct', str(seekpct))
        status, _ = vd.start("-v", interrupt=False)
        return status

    @staticmethod
    def rw_vdbench_no_verify(dev=None, rdpct=0, seekpct=0):
        if dev is None:
            dev = NVMe().block_dev
        vdbench = Vdbench(dev)
        vdbench.import_dict(**GLOBAL)
        vdbench.set_parm('xfersize', XFERSIZE)
        vdbench.set_parm('rdpct', str(rdpct))
        vdbench.set_parm('seekpct', str(seekpct))
        LOG.info("Start run vdbench")
        status, _ = vdbench.start(interrupt=False)
        status = 0
        return status

    @staticmethod
    def rw_vdbench_512(dev=None, rdpct=0, seekpct=0):
        if dev is None:
            dev = NVMe().block_dev
        vd = Vdbench(dev)
        vd.import_dict(**GLOBAL)
        vd.set_parm('xfersize', XFERSIZE_512)
        vd.set_parm('rdpct', str(rdpct))
        vd.set_parm('seekpct', str(seekpct))
        status, _ = vd.start(interrupt=False)
        return status

    @staticmethod
    def fio_test_p(dev=None):
        if dev is None:
            dev = NVMe().block_dev
        fio_test = Fio()
        fio_test.set_parm("filename", dev)
        fio_test.set_parm('size', '1g')
        fio_test.set_parm('threads', '1')
        fio_test.set_parm('rwmixread', '100')
        fio_test.set_parm('rw', 'randrw')
        fio_test.set_parm('continue_on_error', 'all')
        fio_test.set_parm('numjobs', '32')
        fio_test.set_parm('iodepth', '8')
        fio_test.start()

    @staticmethod
    def write_lba(lba, nlb, status, cntid=0, nsid=1):
        lba_rw = LBAOperate(cntid=cntid, nsid=nsid)
        lba_rw.write_sync(lba, nlb, status=status)

    @staticmethod
    def write_uncor(lba, nlb, cntid=1, nsid=1):
        lba_rw = LBAOperate(cntid=cntid, nsid=nsid)
        lba_rw.write_unco(lba, nlb)

    @staticmethod
    def write_zeroes(lba, nlb, cntid=1, nsid=1):
        lba_rw = LBAOperate(cntid=cntid, nsid=nsid)
        lba_rw.write_zeroes(lba, nlb)

    @staticmethod
    def read_sync(lba, nlb, status=0, cntid=0, nsid=1):
        lba_rw = LBAOperate(cntid=cntid, nsid=nsid)
        lba_rw.read_sync(lba, nlb, compare=False, status=status)

    @staticmethod
    def dateset_cmd(dev, ns_id, slb, blk):
        cmd = "nvme dsm %s -n %d -s %d -b %d -d" % (dev, ns_id, slb, blk)
        LOG.info(cmd)
        status = os.system(cmd)
        LOG.info(status)
        if status != 0:
            LOG.info("dateset cmd failed")
        return status

    @staticmethod
    def format_cmd(dev_name, lbaf):
        cmd = "nvme format %s --lbaf=%d" % (dev_name, lbaf)
        LOG.info(cmd)
        status = os.system(cmd)
        if status != 0:
            LOG.info("format failed")
        return status

    def create_ns_1vf_2ns_vm_cli(self, maxvf):
        nsid_list = []
        for i in range(0, maxvf):
            time.sleep(2)
            vfid = i
            for j in range(2 * vfid, 2 * vfid + 2):
                status, nsid = self.nvme.create_ns(0)
                assert_equal(status, 0, 'Create Namespace Failed, Status: {:#x}'.format(status))
                nsid_list.append(nsid)
            self.nsid_dic_1vf_2ns_vm[vfid] = nsid_list
            nsid_list = []
        for key, value in self.nsid_dic_1vf_2ns_vm.items():
            for j in value:
                dev_name = 'nvme%s' % key
                cntid = self.get_ctrl_id(dev_name)
                cntid = int(cntid, base=16)
                status, _ = self.nvme.attach_ns(cntid, j)
                LOG.info("controller %d attach ns %d", cntid, j)
                assert_equal(status, 0, "NVMe attach_ns failed({})".format(status))
                time.sleep(1)
        time.sleep(2)

    def delete_1vf_2ns_vm_cli(self):
        for key, value in self.nsid_dic_1vf_2ns_vm.items():
            for j in value:
                dev_name = 'nvme%s' % key
                cntid = self.get_ctrl_id(dev_name)
                cntid = int(cntid, base=16)
                print("controller %d detach ns %d", cntid, j)
                status, _ = self.nvme.detach_ns(cntid, int(j))
                assert_equal(status, 0, "NVMe detach_ns failed({})".format(status))
                print("controller %d delete ns %d", cntid, j)
                status = self.nvme.delete_ns(int(j))
                assert_equal(status, 0, "NVMe delete_ns failed({})".format(status))
                time.sleep(5)
