#!/usr/bin/env python
"""

@athor: weifeng.guo
@data:2019/7/31 11:33
@filename: sriov

@athor: Liangmin Huang
@data:2020/5/27
@filename: check_vm
@Modify: optimization

"""
import logging
# pylint: disable=superfluous-parens,missing-docstring,invalid-name,anomalous-backslash-in-string,too-many-locals,broad-except
import os
import time

import checksumdir

from lib.driver.utils.ssh import SSH

SRIOV_SCRIPT_PATH = "/home/nvme/perses/"

LOG = logging.getLogger()


class LBAPowerCycleLocalOperate:
    def __init__(self, host, user='root', passwd='nvme', vmname='VM1', retry=5):
        # self.ssh = paramiko.SSHClient()
        self.hostname = host
        self.username = user
        self.password = passwd
        self.vmname = vmname
        self.timeout = 300

        assert self.hostname is not None, 'Please set host(-v host:xx)!'

        self.ssh = SSH(self.hostname, username=self.username,
                       password=self.password)
        logging.getLogger("paramiko").setLevel(logging.WARNING)
        self.remote_env_path = self.get_remote_path()
        self.remote_env_venus_path = "{}/{}".format(self.remote_env_path, "perses")
        self.local_env_venus_path = os.path.join(os.path.dirname(__file__), "..", "..", "..")
        self.retry_time = retry

    def get_remote_path(self):
        remote_path = r"/home/nvme"
        return remote_path

    def open_ssh(self):
        self.ssh.open(timeout=self.timeout)
        self.setup_target_environment()
        #
        # self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # while(True):
        #    try:
        #        self.ssh.connect(self.ip, 22, self.user, self.pswd)
        #    except Exception as e:
        #        print(e)
        #        LOG.info('Connect fail--------')
        #        time.sleep(1)
        #        continue
        #    LOG.info('Connect pass--------')
        #    break

    def close_ssh(self):
        self.ssh.close()

    def run_tc(self, cmd, chk=1):
        self.poweron_vm()
        self.open_ssh()
        ret, output = self.ssh.command(cmd, console=True)
        # (_, stdout, _) = self.ssh.exec_command(cmd)
        # print(output)
        self.close_ssh()

        if ((ret != 0) and (chk == 1)):
            # raise IOError("[%s]-> exec_command %s failed!!!" % (sys.argv[0], cmd))
            raise IOError("%s failed![%s]" % (cmd, output))
        self.power_off_vm()

    def run_test(self, testcase):
        cmd = self.gen_cmd(testcase)
        LOG.info("1. run testcase")
        LOG.info(cmd)
        self.run_tc(cmd)

    @staticmethod
    def gen_cmd(testcase):
        cmd = "cd %s;python run.py testcase -n %s " % (SRIOV_SCRIPT_PATH, testcase)
        # cmd = "cd %s; %s " % (SRIOV_SCRIPT_PATH, testcase)
        return cmd

    def do_power_cycle(self, cmd):
        if cmd not in ['start', 'shutdown']:
            raise RuntimeError('Not a valid command:{}'.format(cmd))
        full_cmd = "virsh {} {}".format(cmd, self.vmname)
        return os.system(full_cmd)

    def poweron_vm(self):
        cnt = self.retry_time
        while (cnt > 0):
            stat = self.do_power_cycle('start')
            # assert_equal(status2, 0, "virsh start fail[status:{:x}]".format(status2))
            if stat == 0:
                time.sleep(20)
                return
            cnt = cnt - 1
            time.sleep(1)
        raise RuntimeError('Power on VM fail after retry {} times'.format(self.retry_time))

    def power_off_vm(self):
        cnt = self.retry_time
        while (cnt > 0):
            stat = self.do_power_cycle('shutdown')
            # assert_equal(status2, 0, "virsh start fail[status:{:x}]".format(status2))
            if stat == 0:
                time.sleep(40)
                # self.do_power_cycle('shutdown')
                return
            cnt = cnt - 1
            time.sleep(1)
        raise RuntimeError('Power off VM fail after retry {} times'.format(self.retry_time))

    def setup_target_environment(self):
        ret = self.ssh.is_exist(self.remote_env_venus_path)
        if ret is False:
            # self.ssh.make_dir(self.remote_env_path)
            self.ssh.make_dir(self.remote_env_venus_path)
            self.ssh.sftp_put_dir(self.local_env_venus_path, self.remote_env_venus_path)
            # self.dos2unit(self.remote_env_venus_path)
            # self.chmod_files(self.remote_env_venus_path)
        else:
            compare_folder = ["configuration", "lib", "testcase", "testsuite", "tools"]
            for folder in compare_folder:
                local_path = os.path.join(self.local_env_venus_path, folder)
                remote_path = r"{}/{}".format(self.remote_env_venus_path, folder)
                local_md5 = self.get_folder_md5(local_path)
                remote_md5 = self.get_folder_md5_by_ssh(remote_path)
                if local_md5 != remote_md5:
                    temp_path = "{}/{}".format(self.remote_env_venus_path, folder)
                    LOG.info("Update folder: %s", temp_path)
                    self.ssh.command("rm -r {}".format(temp_path))
                    self.ssh.make_dir(temp_path)
                    self.ssh.sftp_put_dir(local_path, temp_path)

    def get_folder_md5(self, path):
        md5hash = checksumdir.dirhash(path, 'md5')
        return md5hash

    def get_folder_md5_by_ssh(self, path):
        md5 = None
        cmd = "checksumdir -a md5 {}".format(path)
        status, output = self.ssh.command(cmd)
        if status == 0:
            md5 = output.replace("\n", "")
        return md5
