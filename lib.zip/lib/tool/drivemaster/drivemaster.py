#! /usr/bin/python
## -*- coding: utf-8 -*-
# pylint: disable=import-error
import datetime
import logging
import os
import subprocess
import sys
import time

import autoit

LOG = logging.getLogger()


class DrivemasterCmd:

    def __init__(self):
        self.name_ = "DriveMaster "
        self.DriveMaster_popen = None
        self.DriveMaster_path = r"C:\Program Files (x86)\ULINK DM2015\v1300"
        self.out_log = "C:\\DriveMaster\\TestLog\\Test_drivemaster.log"
        self.testlog_path = "C:\\DriveMaster\\TestLog\\Test_drivemaster.log"
        LOG.info('Enter in DriveMasterCmd init. ----%s', time.strftime("%Y-%m-%d"))

    def run_test(self, srtnamedir, srtname):
        LOG.info('Enter in DriveMasterCmd run_test.   SCRIPT = %s.----%s', srtname, time.strftime("%Y-%m-%d"))
        time1_str = datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
        self.testlog_path = "C:\\DriveMaster\\TestLog\\Test_{}_{}.log".format(srtname, time1_str)
        LOG.info('Enter in DriveMasterCmd run_test.  LogName = %s', self.testlog_path)
        tst_cmd = "cd /d \"{}\" && DriveMaster  /s:{}.srt /l:{}".format(self.DriveMaster_path, srtnamedir,
                                                                        self.testlog_path)
        self.DriveMaster_popen = subprocess.Popen(tst_cmd, shell=True)  # pylint: disable=consider-using-with

    def close(self):
        cmd = "taskkill  /F /T /PID {}".format(self.DriveMaster_popen.pid)
        ret = os.system(cmd)
        LOG.info("close: %d", ret)

    def kill(self):
        command = 'taskkill /F /T /IM DriveMaster.exe'
        os.system(command)

    def check_err(self, m_offset=-3000):
        LOG.info('Enter in DriveMasterCmd check_err.----%s', time.strftime("%Y-%m-%d"))
        self.out_log = self.testlog_path
        #self.out_log = "C:\DriveMaster\TestLog\Test_PwrMgt\PwCycle_RdmCmds_2022-08-16-10-17-46.log"
        out_log_size = os.path.getsize(self.out_log)
        #out_log_size = 3000
        if out_log_size <= 3000:
            m_offset = 0 - (out_log_size - 1)
        LOG.info('log file size: %d offset :%d name: %s', out_log_size, m_offset, self.testlog_path)
        with open(self.out_log, 'rb') as logfile:
            logfile.seek(m_offset, 2)
            line = logfile.readline()
            while line:
                line = logfile.readline()
                if "FAIL".encode('utf-8') in line:
                    LOG.info(line)
                    LOG.info('DriveMaster SCRIPT TESTS FAILED shown in log %s ', self.out_log)
                    return 0
                print(line)
            LOG.info('DriveMaster SCRIPT TESTS PASS %s ', self.out_log)
            return 1

    def wait_and_return_resultq(self, option):
        LOG.info('Enter in DriveMasterCmd wait_and_return_resultq.   option = %s.----%s', option,
                 time.strftime("%Y-%m-%d"))
        need_click_window_caption_list = ["Select Power Cycle Method",
                                          "Normal Shutdown Notification before Power Cycle?",
                                          "JedecWL_Client: Data Files do not exist;", \
                                          "JedecWL Client", "JedecWL Enterprise", "Power Cycle with Data Compare",
                                          "Power Cycle Method", "Test Option", "Power Cycle with Random Commands"]
        timeoutvalue = 60
        timevalue = 0
        testingshow = 0
        j = '.'
        while True:
            if autoit.win_exists("[CLASS:DMSTCls]") == 1:
                j += '.'
                testingshow += 1
                if (testingshow % 10 == 0):
                    j = '.'
                sys.stdout.write('testing' + j + '->' + "\r")
                sys.stdout.flush()
                if (autoit.win_exists("[CLASS:#32770]") == 1):
                    class_list = autoit.win_get_class_list("[CLASS:#32770]")
                    if ((class_list) and (autoit.win_exists("Select test option") == 1)):
                        autoit.win_activate("[CLASS:#32770]")
                        autoit.send("{TAB 1}")
                        autoit.send("{Backspace}")
                        autoit.control_send("Select test option", "Edit1", "")
                        time.sleep(1)
                        autoit.control_send("Select test option", "Edit1", option)
                        time.sleep(1)
                        autoit.control_click("Select test option", "OK")
                    for caption in need_click_window_caption_list:
                        if ((autoit.win_exists(caption) == 1) and (autoit.win_exists("[CLASS:#32770]") == 1)):
                            autoit.win_activate("[CLASS:#32770]")
                            LOG.info('press enter')
                            autoit.send("{Enter}")
                else:
                    time.sleep(1)
                if not os.path.exists(self.testlog_path):
                    time.sleep(2)
                else:
                    error_check = self.check_err()
                    LOG.info('errorCheck = %d.----%s', error_check, time.strftime("%Y-%m-%d"))
                    return error_check
            else:
                time.sleep(5)
                timevalue += 5
                if timevalue > timeoutvalue:
                    LOG.info("not find  CLASS:DMSTCls")
                    return 0

    def run_test_and_wait_result(self, test_scriptdir, test_script, option):
        LOG.info('\n')
        LOG.info('DriveMasterCmd %s start test.----%s', test_script, time.strftime("%Y-%m-%d"))
        self.run_test(test_scriptdir, test_script)
        result = self.wait_and_return_resultq(option)
        return result
