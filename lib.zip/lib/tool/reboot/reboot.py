#! /usr/bin/python
## -*- coding: utf-8 -*-

import logging
import subprocess as sub
import sys
import time

LOG = logging.getLogger()


def reboot_pc(host):
    LOG.info("===========   SubTest_Step: Safe_Power_Down_Client_PC   ===========\n")
    remote_shutdown = "shutdown -r -t 00 -f -m \\\{}".format(host)
    res_off = sub.call(remote_shutdown, shell=True)
    if res_off == 0:
        LOG.info("Reboot Completed!\n")
        return True
    LOG.info("Reboot Failed!\n")
    return False


def count_down(sec):
    LOG.info("seconds count down start: %s", sec)
    while sec:
        mins, secs = divmod(sec, 60)
        count_down_value = '{:02d}:{:02d}'.format(mins, secs)
        LOG.info(count_down_value)
        time.sleep(1)
        sec -= 1


def check_machine(host, msg):
    res_ping = 1
    LOG.info(">>>>>>>>  %s  <<<<<<<<", msg)
    cmd = 'ping -n 2 %s' % host
    for i in range(10):
        time.sleep(10)
        LOG.info("# Start Ping: # %d ", (i + 1))
        with sub.Popen(cmd, shell=True, stdin=sub.PIPE, stdout=sub.PIPE, stderr=sub.PIPE) as process_:
            stdoutdata, stderrdata = process_.communicate()
        LOG.info(stderrdata)
        ping_result = stdoutdata.decode('utf-8')
        LOG.info('Ping Result: %s ', ping_result)
        with open("ping_result_log.txt", 'a', encoding='utf-8') as file_w:
            time_stamp = str(time.ctime())
            file_w.write("\n --------------  %s  --------------\n" % time_stamp)
            file_w.write(ping_result)
        if '(0% loss)' in ping_result:
            LOG.info("------> Ping Succeed\n")
            res_ping = 0
            break
        LOG.info("------> Ping Failed\n")
        res_ping = 1
    return res_ping


def reboot_pc_cycle_test(host, loops):
    for loop in range(1, loops + 1):  # Continue for original test
        LOG.info("********************************************************************")
        LOG.info("**********      Reboot_Test: Begin # %d       **********", loop)
        LOG.info("********************************************************************\n")
        #time_stamp = str(time.ctime())
        #print("time: %s \n" % time_stamp)
        reboot_pc(host)
        count_down(30)
        msg = "Check Client PC Power On State via Ping Command"
        res = check_machine(host, msg)
        if res != 0:
            LOG.info("xxxxxxxxx    PC failed to boot up after loop # %d     xxxxxxxxx", loop)
            sys.exit(1)
        else:
            LOG.info("Power On Completed!\n")
            LOG.info("++++++++  Wait for 60s during IO is running in Client PC  ++++++++\n")
            count_down(60)
            msg = "Check OS Running State via Ping Command"
            res = check_machine(host, msg)
            if res != 0:
                LOG.info("!! OS maybe corrupted! Stop continue power off test !!")
                sys.exit(1)
    LOG.info("Safe Power Cycle test completed for %d loops", loops)


# if __name__ == '__main__':
#     from optparse import OptionParser
#     OPT = OptionParser()
#     # add the private options here:
#     OPT.add_option("--host", type=str, dest="host", default="10.3.200.25", help="host name")
#     OPT.add_option("--loops", type=int, dest="loops", default="1000", help="running loops")
#     (OPTIONS, ARGS) = OPT.parse_args()
#     LOOPS1 = OPTIONS.loops
#     HOST1 = OPTIONS.host
#     reboot_pc_cycle_test(HOST1, LOOPS1)
