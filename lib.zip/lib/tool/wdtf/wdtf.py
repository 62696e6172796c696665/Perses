import os
import subprocess
from shutil import copy

from lib.driver.utils.system import ROOT_PATH


class Wdtf:

    def __init__(self):
        self.system32_path = r"C:\windows\system32"
        self.samplescripts_path = r"C:\WDTF\Samplescripts"
        self.wdft_path = os.path.join(ROOT_PATH, "tools", "WDTF_For_SSD")

    def get_wdtf_path(self):
        return self.samplescripts_path

    def copy_s3_file(self):
        copy(os.path.join(self.system32_path, "cscript.exe"), self.samplescripts_path)
        copy(os.path.join(self.wdft_path, "Common.S3.j_"), self.samplescripts_path)

    def copy_s4_file(self):
        copy(os.path.join(self.system32_path, "cscript.exe"), self.samplescripts_path)
        copy(os.path.join(self.wdft_path, "Common.S4.j_"), self.samplescripts_path)

    def del_s3_file(self):
        if os.path.exists(os.path.join(self.samplescripts_path, "Common.js")):
            os.remove(os.path.join(self.samplescripts_path, "Common.js"))
        if os.path.exists(os.path.join(self.samplescripts_path, "Sleep_Stress_With_IO.wsf.S3.wtl")):
            os.remove(os.path.join(self.samplescripts_path, "Sleep_Stress_With_IO.wsf.S3.wtl"))

    def del_s4_file(self):
        if os.path.exists(os.path.join(self.samplescripts_path, "Common.js")):
            os.remove(os.path.join(self.samplescripts_path, "Common.js"))
        if os.path.exists(os.path.join(self.samplescripts_path, "Sleep_Stress_With_IO.wsf.S4.wtl")):
            os.remove(os.path.join(self.samplescripts_path, "Sleep_Stress_With_IO.wsf.S4.wtl"))

    def run(self, type_="S3"):
        wt_name = "Sleep_Stress_With_IO.wsf.{}.wtl".format(type_)
        com_name = "Common.{}.j_".format(type_)

        os.rename(os.path.join(self.samplescripts_path, com_name), os.path.join(self.samplescripts_path, "Common.js"))
        ret = subprocess.call(
            'cd /d {} && cscript.exe Sleep_Stress_With_IO.wsf /MinutesToRun:720 /SleepPeriod:60'.format(
                self.samplescripts_path), shell=True)
        if ret == 0:
            os.rename(os.path.join(self.samplescripts_path, "Sleep_Stress_With_IO.wsf.wtl"),
                      os.path.join(self.samplescripts_path, com_name))
            ret = subprocess.call("cd /d {} && wtlcount.exe {}".format(self.samplescripts_path, wt_name), shell=True)
        return ret
