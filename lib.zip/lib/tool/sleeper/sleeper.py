# -*- coding: utf-8 -*-
# pylint: disable=import-error
import logging
import os
import re
import subprocess
import time

import autoit

LOG = logging.getLogger()


class Sleeper:

    def __init__(self):
        self.name = "sleeper"
        self.tool_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", "tools", "Sleeper")
        self.result_path = os.path.join(self.tool_path, "result")
        if os.path.exists(self.result_path) is False:
            os.mkdir(self.result_path)

    def get_version(self):
        read_me = os.path.join(self.tool_path, "ReadMe.txt")
        with open(read_me, encoding='utf-8') as file:
            contents = file.read()
        versions = re.findall("Sleeper\sv([0-9\.]+)\s\(([0-9]+)\)", contents)
        version = versions[0] if versions else (0, 0)
        return "{}({})".format(version[0], version[1])

    def _get_log_name_with_time_tag(self, string_):
        return "{}_{}.txt".format(string_, time.strftime('%Y%m%d%H%M%S', time.localtime(time.time())))

    def kill(self):
        command = 'taskkill /F /T /IM Sleeper.exe'
        os.system(command)

    def run(self, sleep_type, duration, internal, numbers, delay_1st):
        """
        run sleeper with command
        :param sleep_type:sleep type S1000(S1),S0010(S3),S0001(S4),S1111(s1,s2,s3,s4)...
        :param duration:sleep duration
        :param internal:Interval between cycle
        :param numbers:Num cycles
        :param delay_1st:Wait before 1st sleep
        :return:
        """
        log_file = self._get_log_name_with_time_tag(sleep_type)
        log_path = os.path.join(self.tool_path, "result", log_file)
        cmd = "cd /d {} && Sleeper.exe -P {} -R {} -D {} -N {} -{} -L {}". \
            format(self.tool_path, delay_1st, duration, internal, numbers, sleep_type, log_path)
        LOG.info("Sleep command: %s", cmd)
        run_popen = subprocess.Popen(cmd, shell=True)   # pylint: disable=consider-using-with
        return run_popen, log_file

    def get_state_from_ui(self):
        if autoit.win_exists("PassMark Sleeper") == 1:
            command = "IsEnabled"
            while True:
                if autoit.win_active("PassMark Sleeper") == 0:
                    autoit.win_activate("PassMark Sleeper")
                    time.sleep(1)
                else:
                    break
            try:
                handle_ = autoit.win_get_handle("PassMark Sleeper")
                ctrl_ = autoit.control_get_handle(handle_, control="[ID:1014]")
                state_ = autoit.control_command_by_handle(handle_, ctrl_, command)
            except autoit.AutoItError:
                LOG.info("did not find sleep now button")
                state_ = 2
            # print(state_)
        else:
            raise RuntimeError("Sleeper is abnormal closed when test is running!")
        return int(state_)

    def wait(self):
        time.sleep(3)
        while self.is_running():
            LOG.info("Sleeper is running")
            time.sleep(3)

    def is_running(self):
        time.sleep(3)
        return (self.get_state_from_ui() in [0, 2])

    def check_logs(self, log_):
        log_path = os.path.join(os.path.join(self.tool_path, "result", log_))
        if os.path.exists(log_path) is False:
            return None
        with open(log_path, encoding='utf-8') as file:
            contents = file.read()
        is_complete = self.is_cycle_completed(contents)
        is_erros = self.is_errors_find(contents)
        return is_complete and is_erros

    def is_cycle_completed(self, contents):
        result = bool("Last cycle completed" in contents)
        if result:
            LOG.info("Sleep Tests may not finished all cycles, please check log")
        else:
            LOG.info("Sleep Tests  finished all cycles")
        return result

    def is_errors_find(self, contents):
        result = bool("error" in contents)
        if result is False:
            LOG.info("Sleep Tests may find errors, please check logs")
        else:
            LOG.info("Sleep Tests did not find errors")
        return result


if __name__ == '__main__':
    S = Sleeper()
    print(S.get_version())
