#!/usr/bin/env python
from openpyxl.chart import Series, Reference, ScatterChart
from openpyxl.workbook import Workbook


class Excel:
    def __init__(self):
        self.workbook = Workbook()
        self.workbook.remove(self.workbook.active)
        self.worksheet = None
        self.data_min = 0

    @staticmethod
    def _trunc(num):
        bits = list(str(num))
        return int(bits[0]) * (10 ** (len(bits) - 1))

    @staticmethod
    def _load(filename, unit=1, delimiter=',', title=None):
        lines = list()
        if title:
            lines.append(title)
        with open(filename, encoding='utf-8') as handle:
            for line in handle.readlines():
                temp = [i.strip() for i in line.split(delimiter)]
                lines.append([round(float(temp[0]) / 1000),
                              round(float(temp[1]) / unit)])
        return lines

    def create_sheet(self, name, filename, unit=1, delimiter=',', title=None):
        self.worksheet = self.workbook.create_sheet(name)

        lines = self._load(filename, unit, delimiter, title)
        for i, data in enumerate(lines, start=1):
            for j, val in enumerate(data, start=1):
                self.worksheet.cell(i, j, value=val)
        self.data_min = min(list(zip(*lines[1:]))[1])

    def create_scatter_chart(self, title, anchor, x_row=None, width=24, height=16):
        x_row = x_row if x_row else self.worksheet.max_row - 1
        x_axis = Reference(self.worksheet, min_col=1, min_row=1, max_row=x_row - 1)
        data = Reference(self.worksheet, min_col=2, min_row=1, max_row=x_row - 1)
        series = Series(data, x_axis, title_from_data=True)
        chart = ScatterChart()
        chart.width = width
        chart.height = height
        chart.title = title
        chart.legend = None
        chart.x_axis.title = self.worksheet.cell(1, 1).value
        chart.x_axis.scaling.min = 0
        chart.x_axis.scaling.max = x_row
        chart.x_axis.majorUnit = x_row / 12
        chart.y_axis.title = self.worksheet.cell(1, 2).value
        chart.y_axis.scaling.min = self._trunc(self.data_min)
        chart.series.append(series)
        self.worksheet.add_chart(chart, anchor)

    def save(self, filename):
        self.workbook.save(filename)


if __name__ == "__main__":
    EXCEL = Excel()
    EXCEL.create_sheet("Read Latency", 'data.txt', unit=1000, title=["Time(s)", "Avg Latency(us)"])
    EXCEL.create_scatter_chart("Sequential Read(us)", "D2")
    EXCEL.create_sheet("Read Bandwidth", 'data2.txt', unit=1024, title=["Time(s)", "Bandwidth(MiB/s)"])
    EXCEL.create_scatter_chart("Sequential Read(MiB/s)", "D2", x_row=3600)
    EXCEL.save("read.xlsx")
