## -*- coding: utf-8 -*-
import logging
import os
import re
import subprocess
import time

LOG = logging.getLogger()


class IOL:

    def __init__(self):
        self.path = "/home/nvme/public/product_test/iol_interact-15.0c/nvme/manage"
        self.dev = "/dev/nvme0"
        self.tests = ""
        # self.log_path = log_path
        # file_name = os.path.join(self.log_path, "iol_result.txt")
        # self.log_fp = open(file_name,"wb")

    def set_path(self, path):
        self.path = path

    def get_path(self):
        return self.path

    def is_exists(self):
        if os.path.exists(self.path):
            return True
        return False

    def run_test(self, test, dev="/dev/nvme0"):
        cmd = "cd {} && ./runtest.sh --test={} --device={}".format(self.path, test, dev)
        with subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as process:
            (std_output, _) = process.communicate()
        std_output = std_output.decode()
        self.save_test_log(std_output, test)
        passed, failed, skipped, informative = self.analysis_output(std_output)
        # summer_string = "Test:{} , pass {} fail {} skip {} informative {}".format(test, passed, failed, skipped, informative)
        # FB.write("%s    %s       %s "%(format(i,"<10"),format(self.tlist[i][1],"<80"),result))
        # self.log_fp.write(summer_string)
        # LOG.info(summer_string)
        if failed > 0:
            LOG.info(std_output)
        return passed, failed, skipped, informative

    def save_test_log(self, prints, test_name):
        time_tag = time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))
        file_name = "{}_{}.txt".format(test_name, time_tag)
        file_path = os.path.join(self.path, "production_logs")
        if os.path.exists(file_path) is False:
            os.mkdir(file_path)
        with open(os.path.join(file_path, file_name), "w", encoding='utf-8') as file_handle:
            file_handle.write(prints)
            file_handle.close()

    def analysis_output(self, contents):
        passed_ = re.findall("passed\s*\:\s+([0-9]+)", contents)
        passed = passed_[0] if passed_ else 0
        failed_ = re.findall("failed\s*\:\s+([0-9]+)", contents)
        failed = failed_[0] if failed_ else 0
        skipped_ = re.findall("skipped\s*\:\s+([0-9]+)", contents)
        skipped = skipped_[0] if skipped_ else 0
        informative_ = re.findall("informative\s*\:\s+([0-9]+)", contents)
        informative = informative_[0] if informative_ else 0
        return int(passed), int(failed), int(skipped), int(informative)


if __name__ == '__main__':
    pass
