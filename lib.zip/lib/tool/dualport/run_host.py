#!/usr/bin/python
"""
@athor: wanxiao.wang
"""
import os
import logging
import checksumdir

from lib.driver.testcase import TestDualPortCase
from lib.driver.utils.ssh import SSH
from lib.driver.utils.system import execute

DP_SCRIPT_PATH = "/home/share/sqa/perses"


class LBASSHLocalOperate(TestDualPortCase):
    def __init__(self, host, user='root', passwd='nvme', retry=5):
        super().__init__()
        self.hostname = host
        self.username = user
        self.password = passwd
        self.timeout = 300

        assert self.hostname is not None, 'Please set host(-v host:xx)!'

        self.ssh = SSH(self.hostname, username=self.username,
                       password=self.password)
        logging.getLogger("paramiko").setLevel(logging.WARNING)
        self.remote_env_path = self.get_remote_path()
        self.remote_env_perses_path = "{}/{}".format(self.remote_env_path, "perses")
        self.local_env_perses_path = os.path.join(os.path.dirname(__file__), "..", "..", "..")
        self.retry_time = retry

    def get_remote_path(self):
        remote_path = r"/home/share/sqa"
        return remote_path

    def open_ssh(self):
        self.ssh.open(timeout=self.timeout)
        self.setup_target_environment()

    def close_ssh(self):
        self.ssh.close()

    def run_tc(self, cmd, chk=1):
        self.open_ssh()
        ret, output = self.ssh.command(cmd, console=True)
        self.close_ssh()

        if (ret != 0) and (chk == 1):
            raise IOError("%s failed![%s]" % (cmd, output))

    def run_fw(self, cmd, chk=1):
        self.open_ssh()
        ret, output = self.ssh.command(cmd, console=True)
        self.close_ssh()

        if (ret != 0) and (chk == 1):
            raise IOError("%s failed![%s]" % (cmd, output))

    def run_pc(self, cmd, chk=1):
        ret, output = execute(cmd)
        if (ret != 0) and (chk == 1):
            IOError("%s failed![%s]" % (cmd, output))

    def run_test(self, testcase):
        cmd = self.gen_cmd(testcase)
        self.log.info("1. run testcase")
        self.log.info(cmd)
        self.run_tc(cmd)

    def run_slot_test(self, testcase, slot):
        cmd = self.gen_slot_cmd(testcase, slot)
        self.log.info("1. run testcase")
        self.log.info(cmd)
        self.run_tc(cmd)

    def run_fw_update(self, testcase, slot, fw_path):
        cmd = self.gen_fw_path_cmd(testcase, slot, fw_path)
        self.log.info("1. run testcase")
        self.log.info(cmd)
        self.run_fw(cmd)

    def run_power(self, testcase, hostname):
        cmd = self.gen_power_cmd(testcase, hostname)
        self.log.info("1. run powercycle")
        self.log.info(cmd)
        self.run_pc(cmd)

    def run_slot_power(self, testcase, hostname, slot):
        cmd = self.gen_slot_power_cmd(testcase, hostname, slot)
        self.log.info("1. run powercycle")
        self.log.info(cmd)
        self.run_pc(cmd)


    @staticmethod
    def gen_cmd(testcase):
        cmd = "cd %s;python run.py testcase -n %s" % (DP_SCRIPT_PATH, testcase)
        return cmd

    @staticmethod
    def gen_fw_path_cmd(testcase, slot, fw_path):
        cmd = "cd %s;python run.py testcase -n %s -v slot:%s,fw_path:%s" % (DP_SCRIPT_PATH,
                                                                            testcase, slot, fw_path)
        return cmd

    @staticmethod
    def gen_power_cmd(testcase, hostname):
        cmd = "cd %s;python run.py powercycle -n %s -v adapter:usbrelay,target_ip:%s" % (DP_SCRIPT_PATH,
                                                                                         testcase, hostname)
        return cmd

    @staticmethod
    def gen_slot_power_cmd(testcase, hostname, slot):
        cmd = "cd %s;python run.py powercycle -n %s -v target_ip:%s,slot:%s" % (DP_SCRIPT_PATH,
                                                                                testcase, hostname, slot)
        return cmd

    @staticmethod
    def gen_slot_cmd(testcase, slot):
        cmd = "cd %s;python run.py testcase -n %s -v slot:%s" % (DP_SCRIPT_PATH, testcase, slot)
        return cmd

    def setup_target_environment(self):
        ret = self.ssh.is_exist(self.remote_env_perses_path)
        if ret is False:
            self.ssh.make_dir(self.remote_env_perses_path)
            self.ssh.sftp_put_dir(self.local_env_perses_path, self.remote_env_perses_path)

    def get_folder_md5(self, path):
        md5hash = checksumdir.dirhash(path, 'md5')
        return md5hash

    def get_folder_md5_by_ssh(self, path):
        md5 = None
        cmd = "checksumdir -a md5 {}".format(path)
        status, output = self.ssh.command(cmd)
        if status == 0:
            md5 = output.replace("\n", "")
        return md5
