## -*- coding: utf-8 -*-
import logging
import os
import re
import subprocess

LOG = logging.getLogger()


class Chaos:

    def __init__(self):
        self.name = "chaos"
        self.tool_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", "tools", "chaos")

    def get_version(self):
        cmd = "cd {} && chaos.exe -v".format(self.tool_path)
        with subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE) as process:
            (std_output, _) = process.communicate()
        finds = re.findall("CHAOS\s*V([0-9\.]+)", std_output.decode("utf-8"))
        version = finds[0] if finds else 0
        return version

    def run(self, log_name, passes):
        chaos_log = os.path.join(self.tool_path, log_name)
        cmd_chaos = "cd /d {} && chaos -b=X: -t=6 -d=8 -e=unique -g=4kb -s=4kb,256mb " \
                    "-m=4kb,64kb -p={} -l={}".format(self.tool_path, passes, chaos_log)
        #print(cmd_chaos)
        ret = subprocess.call(cmd_chaos, shell=True)
        return ret

    def analysis_log(self, log_file):
        log_path = os.path.join(self.tool_path, log_file)
        if os.path.exists(log_path):
            with open(log_path, encoding='utf-8') as file:
                content = file.read()
            finds = re.findall("Errors\D+(\d+)", content)
            errors_ = list(filter(lambda x: int(list(x)[0]) > 0, finds))
            if errors_:
                LOG.error("Chaos find errors in logs, please check logs")
            else:
                return True
        else:
            LOG.error("Chaos log did not find: %s", log_path)
        return False


if __name__ == '__main__':
    pass
