#!/usr/bin/env python
# coding=utf-8
# pylint: disable=bad-option-value,consider-using-with,unspecified-encoding,consider-using-f-string
"""
FIO operation

@author: yyang
"""
import logging
import os
import platform
import re
import stat
import subprocess
from collections import OrderedDict
from multiprocessing import cpu_count
from multiprocessing import Process
import psutil
from lib.driver.utils.system import execute, ROOT_PATH

STATE_755 = stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH
FIO_LINUX_PATH = ['/usr/bin/fio', os.path.join(ROOT_PATH, "tools", "fio", "fio")]
FIO_WINDOWS_PATH = r"C:\Program Files\fio\fio.exe"

LOG = logging.getLogger()
DUMP = logging.getLogger('dump')


class Fio:
    def __init__(self):
        system = platform.system()
        if system == "Linux":
            for fio in FIO_LINUX_PATH:
                if not os.path.exists(fio):
                    continue

                status, output = execute(f'{fio} --version', interrupt=False)
                if status != 0:
                    continue

                version = re.findall('fio-(\d+\.\d+)', output)
                if not version:
                    continue

                if float(version[0]) >= 3.0:
                    break
            else:
                raise RuntimeError("FIO is non-existent: '{}'".format(FIO_LINUX_PATH))

            self.fio = fio
            if not os.access(self.fio, os.X_OK):
                os.chmod(self.fio, STATE_755)

            self.__init_aio_max_nr()
            self.__init_scaling_governor()
        elif system == "Windows":
            if not os.path.exists(FIO_WINDOWS_PATH):
                raise RuntimeError("FIO is non-existent: '{}'".format(FIO_WINDOWS_PATH))
            self.fio = FIO_WINDOWS_PATH
        else:
            raise RuntimeError("Unknown OS: '{}'".format(system))

        self.thread = None
        self.args = []
        self.parm = OrderedDict()
        self.outfile = None

    @staticmethod
    def __init_scaling_governor():
        for i in range(cpu_count()):
            scaling_governor = "/sys/devices/system/cpu/cpu{}/cpufreq/scaling_governor".format(i)
            execute("echo performance > {}".format(scaling_governor),
                    cmdline=False, console=False, interrupt=False)

    @staticmethod
    def __init_aio_max_nr(default=1048576):
        cmd = "cat /proc/sys/fs/aio-max-nr"
        _, output = execute(cmd, cmdline=False, console=False, interrupt=True)
        if int(output) < default:
            cmd = "echo > /proc/sys/fs/aio-max-nr {}".format(default)
            execute(cmd, cmdline=False, console=False, interrupt=True)

    def parse_cmd(self, jobfile=None, section=None, **kwargs):
        args = [self.fio]

        self.parm.update(kwargs)
        for key, val in self.parm.items():
            if val in [None]:
                pass
            elif val is True:
                args.append("--{}".format(key))
            else:
                args.append("--{}={}".format(key, val))
                if key == "runtime":
                    args.append("--time_based")

        if jobfile:
            self.args.append(jobfile)
            if section:
                self.args.append("--section={}".format(section))

        args += self.args

        return " ".join(args)

    def set_parm(self, key, value=None):
        """
        (key, True)         --> --key
        (key, None/False)   --> ignore
        (key, string)       --> --key=string
        """
        self.parm[key] = value

    def clear_parm(self):
        self.parm.clear()

    def init_output(self, name):
        self.outfile = name
        self.set_parm("output", self.outfile)

    def import_dict(self, **kwargs):
        self.parm.update(kwargs)

    def import_list(self, *args):
        self.args += args

    def clear_args(self):
        self.args.clear()

    def start(self, jobfile=None, section=None, cmdline=True, interrupt=True, outfile=None, **kwargs):
        if self.outfile:
            self.set_parm("output", self.outfile)
        if outfile:
            self.set_parm("output", outfile)
            self.outfile = outfile

        cmd = self.parse_cmd(jobfile, section, **kwargs)

        if cmdline:
            LOG.info("# %s", cmd)

        status = subprocess.call(cmd, shell=True)
        DUMP.info("")

        output = open(self.outfile, 'r').read() if self.outfile else ""
        DUMP.info(output)

        if status and interrupt:
            raise RuntimeError("Run FIO failed!")

        return status, output

    def _start(self, jobfile=None, section=None, cmdline=True, outfile=None, args=None):
        if self.outfile:
            self.set_parm("output", self.outfile)
        if outfile:
            self.set_parm("output", outfile)
            self.outfile = outfile

        args = args if args else {}
        cmd = self.parse_cmd(jobfile, section, **args)

        status, output = execute(cmd, cmdline, console=True, interrupt=False)

        return status, output

    def is_alive(self):
        #assert self.thread, "PROCESS: Vdbench is not start!"
        if self.thread:
            return self.thread.is_alive()
        return 0

    def run(self, jobfile=None, section=None, cmdline=True, outfile=None, **kwargs):
        #self.thread = Threads(target=self._start, args=(jobfile, section, cmdline, outfile, kwargs))
        #self.thread.daemon = True
        #self.thread.start()
        self.thread = Process(target=self._start, args=(jobfile, section, cmdline, outfile, kwargs))
        self.thread.start()

    def exitcode(self):
        assert self.thread, "FIO: thread is not start!"
        return self.thread.exitcode

    def join(self, timeout=None):
        if self.thread:
            self.thread.join(timeout)
        else:
            raise RuntimeError("Fio thread is not set!")

    def get_result(self):
        if self.thread:
            status = self.thread.exitcode
            self.thread = None
        else:
            raise RuntimeError("FIO thread is not set!")

        return status, "No output"

    def get_bw(self, pat='WRITE'):
        pat = pat.upper()
        if 'WRITE' in pat:
            pat = 'WRITE'
        else:
            pat = 'READ'
        output = open(self.outfile, 'r').read() if self.outfile else ""
        #LOG.info('************************')
        LOG.info(output)
        ret = re.findall(': bw=(\d+)\D+\/s', output)
        print(ret)
        #print(ret.group(1))
        ret = [int(idx) for idx in ret]
        return sum(ret)

    def get_bw_ave(self):
        output = open(self.outfile, 'r').read() if self.outfile else ""
        LOG.info(output)
        ret_bw = re.findall(r'bw=(\d+)', output)
        ret_bw = [int(idx) for idx in ret_bw]
        return ret_bw

    def get_slat_ave(self):
        output = open(self.outfile, 'r').read() if self.outfile else ""
        ret_slat_ave = re.findall(r'avg=(\d+)', output)
        ret_slat_ave = [int(idx) for idx in ret_slat_ave]
        return ret_slat_ave[0]

    def get_clat_ave(self):
        output = open(self.outfile, 'r').read() if self.outfile else ""
        ret_clat_ave = re.findall(r'avg=(\d+)', output)
        ret_clat_ave = [int(idx) for idx in ret_clat_ave]
        return ret_clat_ave[1]

    def get_bw_six_nine(self):
        output = open(self.outfile, 'r').read() if self.outfile else ""
        ret_six_nine = re.findall(r'99.999900th=\[(\d+)\]', output)
        ret_six_nine = [int(idx) for idx in ret_six_nine]
        return ret_six_nine

    def get_io_to_byte(self):
        output = open(self.outfile, 'r').read() if self.outfile else ""
        LOG.info(output)
        ret = re.findall(': bw=.+io=(\S+)\s', output)
        print(ret)
        val = re.findall('(\S+)\DiB', ret[0])
        tmp = val[0]
        print(tmp)
        print(type(tmp))
        print(float(tmp))
        tmp = float(tmp)
        if 'GiB' in ret[0]:
            byte_val = 1024 * 1024 * 1024 * tmp
        elif 'MiB' in ret[0]:
            byte_val = 1024 * 1024 * tmp
        elif 'KiB' in ret[0]:
            byte_val = 1024 * tmp
        elif 'TiB' in ret[0]:
            byte_val = 1024 * 1024 * 1024 * 1024 * tmp
        else:
            byte_val = tmp
        print(byte_val)
        return int(byte_val)

    def terminate(self):
        if self.is_alive():
            LOG.warning("PROCESS: Terminate FIO!")

            try:
                parent = psutil.Process(self.thread.pid)
                for proc in parent.children(recursive=True) + [parent]:
                    proc.terminate()
            except Exception as err:
                LOG.error(err)
                return 1
        return 0
