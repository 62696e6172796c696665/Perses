## -*- coding: utf-8 -*-
import os
import re
import subprocess


class CnexSSDManager:

    def __init__(self):
        self.tool_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", "tools", "CNEXlabSSDManager")

    def upgrade_fw(self, fw_path, device_index=1, slot=2):
        cmd = "cd /d {} && \"CNEXlab Manager.exe\" upgrade {} {} {}".format(self.tool_path, fw_path, device_index, slot)
        with subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE) as process:
            process.wait()
            stdout, stderr = process.communicate()
        str_out = stdout.decode()
        print(str_out)
        print(stderr)
        if "Firmware activate succeeded" in str_out:
            return True, str_out
        return False, str_out

    def list_dev(self):
        cmd = "cd /d {} && \"CNEXlab Manager.exe\" list_dev".format(self.tool_path)
        with subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE) as process:
            process.wait()
            stdout, _ = process.communicate()
        str_out = stdout.decode()
        print(str_out)
        dev_list = self._get_dev_index_name(str_out)
        return dev_list

    def _get_dev_index_name(self, str_prints):
        dev_list = list()
        rets = re.findall("nvme\sdevice\sindex\:\s(\d+)\.nvme\sname\:\s(.+)\n", str_prints)
        for dev in rets:
            dev_name = dev[1].replace(" ", "")
            dev = {"index": dev[0], "name": dev_name}
            dev_list.append(dev)
        return dev_list
