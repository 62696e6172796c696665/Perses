#!/usr/bin/env python
# -*- coding: utf-8 -*-
import logging
import os
import re
import time
from platform import platform

from lib.driver.utils.system import execute

LOG = logging.getLogger()


class UsbRelay:
    def __init__(self, device='6QMBS'):
        self.port_num = 2

        if 'Linux' in platform():
            self.usbrelay = os.path.join(os.getcwd(), 'tools', 'usbrelay', 'usbrelay')
            self.device = self._get_dev_name()
            self.format_on = '{} {}{{}}=1'.format(self.usbrelay, self.device)
            self.format_off = '{} {}{{}}=0'.format(self.usbrelay, self.device)
        else:
            self.usbrelay = os.path.join(os.getcwd(), 'tools', 'usbrelay', 'usbrelay.exe')
            self.device = device
            self.format_on = '{} {} open {{}}'.format(self.usbrelay, self.device)
            self.format_off = '{} {} close {{}}'.format(self.usbrelay, self.device)

        assert os.path.exists(self.usbrelay), "Can not find: {}".format(self.usbrelay)

    def _get_dev_name(self):
        _, output = execute(self.usbrelay, cmdline=True, console=True)
        match = re.findall(r'([a-zA-Z_]+)\d+=\d+', output)
        assert match, "Can not find any device matched"
        self.port_num = len(match)
        return match[0]

    def get_port_status(self, port=1):
        if 'Linux' not in platform():
            return None

        name = self.device + str(port)
        _, output = execute(self.usbrelay, cmdline=True, console=True)
        for line in output.split('\n'):
            if line.find(name) == -1:
                continue
            if line.find("=1") == -1:
                return 0
            return 1
        return None

    def get_all_port_status(self):
        if 'Linux' not in platform():
            return None

        status = []
        _, output = execute(self.usbrelay, cmdline=True, console=True)
        for port in range(1, self.port_num + 1):
            name = self.device + str(port)
            for line in output.split('\n'):
                if line.find(name) == -1:
                    continue
                if line.find("=1") == -1:
                    status.append(0)
                else:
                    status.append(1)
        return status

    def turn_off(self, port=1):
        cmd = self.format_off.format(port)
        LOG.info("USB Relay off: %s", cmd)
        status, output = execute(cmd, cmdline=False, console=False)
        assert status == 0, 'USB relay open failed!\n{}'.format(output)

    def turn_on(self, port=1):
        cmd = self.format_on.format(port)
        LOG.info("USB Relay on: %s", cmd)
        status, output = execute(cmd, cmdline=False, console=False)
        assert status == 0, 'USB relay close failed!\n{}'.format(output)

    def press(self, port=1, timeout=1):
        self.turn_on(port)
        time.sleep(timeout)
        self.turn_off(port)

    def power_on(self):
        for i in range(1, self.port_num + 1):
            self.turn_on(i)

    def power_off(self):
        for i in range(1, self.port_num + 1):
            self.turn_off(i)
