#!/usr/bin/env python
import argparse
import fcntl
import os.path
from ctypes import *
import logging

LOG = logging.getLogger()

class CP210X:
    IOCTL_GPIO_GET = 0x8000
    IOCTL_GPIO_SET = 0x8001

    def __init__(self, name=None):
        self.name = name
        if self.name is None:
            self.name = r'/dev/' + os.environ.get('cp210x', 'ttyUSB0')
        self._dev = None

        assert os.path.exists(self.name), 'Device({0}) is not exists!'.format(self.name)

    def __del__(self):
        if self._dev:
            os.close(self._dev)

    @staticmethod
    def open(dev):
        return os.open(dev, os.O_RDWR | os.O_NOCTTY | os.O_NDELAY)

    @property
    def dev(self):
        if not self._dev:
            self._dev = self.open(self.name)
        return self._dev

    @staticmethod
    def ioctl(dev, request, cmd):
        return fcntl.ioctl(dev, request, cmd)

    def power_on(self):
        LOG.info('CP210X Power On')
        gpio = c_uint16(0x101)
        assert self.ioctl(self.dev, self.IOCTL_GPIO_SET, gpio) == 0, 'Power On Failed!'

    def power_off(self):
        LOG.info('CP210X Power Off')
        gpio = c_uint16(0x1)
        assert self.ioctl(self.dev, self.IOCTL_GPIO_SET, gpio) == 0, 'Power Off Failed!'


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description='CP210X Debug')

    PARSER.add_argument('-p', '--power', default=None, help='Do power on(1) or power off(0)')
    ARGS = PARSER.parse_args()

    USB = CP210X()
    if int(ARGS.power) == 0:
        USB.power_off()
    elif int(ARGS.power) == 1:
        USB.power_on()
