# coding=utf-8
import logging
import operator
import os
import subprocess
import time

import xlrd

LOG = logging.getLogger()

WCS_BENCHMARK = [
    {"name": "4K Latency", "standard_data": [0.24, 0.30, 0.40, 0.50, 1.00, 3.00, 5.00, 7.00, 11.00]},
    {"name": "8K Latency", "standard_data": [0.25, 0.36, 0.48, 0.55, 2.00, 4.00, 6.00, 8.00, 12.00]},
    {"name": "64K Latency", "standard_data": [0.45, 0.77, 1.00, 3.00, 3.50, 5.00, 8.00, 10.00, 20.00]}
]

AD2_DATA = [
    {"name": "4K Max Latency", "avg_cell_key": (1, 22), "2-8nines_cell_key": (1, 26), "total_cell_key": (1, 34)},
    {"name": "8K Max Latency", "avg_cell_key": (4, 22), "2-8nines_cell_key": (4, 26), "total_cell_key": (4, 34)},
    {"name": "64K Max Latency", "avg_cell_key": (7, 22), "2-8nines_cell_key": (7, 26), "total_cell_key": (7, 34)},
]


class StorScore:

    def __init__(self):
        self.tool_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", "tools", "StorScore")
        self.base_results = self.get_current_results()
        self.calc_data = []

    def run_test(self, target_id, test_case):
        self.update_base_result()
        cmd = r"cd /d {} && StorScore.cmd -target={} -nocollect_logman -recipe={}". \
            format(self.tool_path, target_id, test_case)
        ret = subprocess.call(cmd, shell=True)
        return ret

    def parse_results(self, result_path, out_put_file="output.xlsx"):
        if os.path.exists(os.path.join(self.tool_path, "results", result_path)) is True:
            cmd = "cd /d {} && parse_results.cmd results\{} {}".format(self.tool_path, result_path, out_put_file)
            ret = subprocess.call(cmd, shell=True)
            if ret != 0:
                LOG.error("StorScore parse result failed, result: %s", result_path)

    def get_current_results(self):
        result_path = os.path.join(self.tool_path, "results")
        dirs = os.listdir(result_path)
        return dirs

    def update_base_result(self):
        self.base_results = self.get_current_results()

    def get_new_result(self):
        results = self.get_current_results()
        new_results = []
        for item in results:
            if item not in self.base_results:
                new_results.append(item)
        return new_results

    def parse_excel_result(self, excel_result):
        excel_path = os.path.join(self.tool_path, excel_result)
        if os.path.exists(excel_path):
            xl_ = xlrd.open_workbook(excel_path)
            sheet1 = xl_.sheet_by_name("Raw Data")
            for item in AD2_DATA:
                ret = self.get_data(sheet1, item)
                self.calc_data.append(ret)

    def parse_flash_result(self, excel_result):
        excel_path = os.path.join(self.tool_path, excel_result)
        if os.path.exists(excel_path):
            xl_ = xlrd.open_workbook(excel_path)
            sheet1 = xl_.sheet_by_name("Raw Data")
            max_latency = sheet1.col_values(34)  # col 34 is max latency col
        return max_latency

    def compare_result_with_wcs(self):
        cmp_result = True
        for i in range(3):
            ret = operator.le(self.calc_data[i], WCS_BENCHMARK[i]["standard_data"])
            cmp_result = cmp_result & ret
            if ret is False:
                LOG.error("Result cmp error: %s, wcs is %s}, get data is %s", WCS_BENCHMARK[i]["name"],
                          WCS_BENCHMARK[i]["standard_data"], self.calc_data[i])
            else:
                LOG.info("Result cmp passed: %s, wcs is %s, get data is %s", WCS_BENCHMARK[i]["name"],
                         WCS_BENCHMARK[i]["standard_data"], self.calc_data[i])
        return cmp_result

    def compare_result_in_fw_flash(self, get_datas):
        """
        fw_flash_scene only need Latency less then 3s
        :return: compare result
        """
        cmp_result = True
        for item in get_datas[1:]:
            ret = float(item) < 3000
            cmp_result = cmp_result & ret
            if ret is False:
                LOG.error("Result cmp error:stand less then 3000,get data is %s", item)
            else:
                LOG.info("Result cmp passed:stand less then 3000,get data is %s", item)
        return cmp_result

    def get_data(self, sheet, cell_info):
        data = []
        row_, col_ = cell_info["avg_cell_key"]
        value_ = float('%.2f' % max(sheet.cell_value(row_, col_), sheet.cell_value(row_ + 1, col_),
                                    sheet.cell_value(row_ + 2, col_)))
        data.append(value_)
        row_, col_ = cell_info["2-8nines_cell_key"]
        for i in range(7):
            value_ = float('%.2f' % max(sheet.cell_value(row_, col_ + i), sheet.cell_value(row_ + 1, col_ + i),
                                        sheet.cell_value(row_ + 2, col_ + i)))
            data.append(value_)
        row_, col_ = cell_info["total_cell_key"]
        value_ = float('%.2f' % max(sheet.cell_value(row_, col_), sheet.cell_value(row_ + 1, col_),
                                    sheet.cell_value(row_ + 2, col_)))
        data.append(value_)
        return data

    def analysis_result(self, result, fw_flash_mode=False):
        out_put = "result_{}.xlsx".format(time.strftime('%Y%m%d%H%M%S', time.localtime(time.time())))
        self.parse_results(result, out_put)

        if fw_flash_mode is False:
            self.parse_excel_result(out_put)
            ret = self.compare_result_with_wcs()
        else:
            max_latency = self.parse_flash_result(out_put)
            ret = self.compare_result_in_fw_flash(max_latency)
        return ret

    def analysis_results(self, fw_flash_mode=False):
        get_results = self.get_new_result()
        LOG.info("Get result: %s", get_results)
        result = True
        for result_ in get_results:
            ret = self.analysis_result(result_, fw_flash_mode)
            result = result & ret
        return result


if __name__ == '__main__':
    pass
