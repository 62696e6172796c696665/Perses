# coding=utf-8
import requests

from lib.driver.rest_client.resources.test_resource import TestResource
from lib.driver.rest_client.resources.operation_resource import OperationResource
from lib.driver.rest_client.resources.state_resource import StateResource
from lib.driver.rest_client.resources.remote_resource import RemoteResource
from lib.driver.rest_client.resources.benchmark_resource import BenchmarkResource


class RestClient:

    def __init__(self, host, port=5000, time_out=5):
        __session = requests.Session()
        self.test = TestResource(host, port, __session, time_out=time_out)
        self.operation = OperationResource(host, port, __session, time_out=time_out)
        self.state = StateResource(host, port, __session, time_out=time_out)
        self.remote = RemoteResource(host, port)
        self.benchmark = BenchmarkResource(host, port, __session, time_out)


if __name__ == '__main__':
    pass
