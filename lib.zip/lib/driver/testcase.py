#!/usr/bin/env python
# pylint: disable=too-many-locals,too-many-statements
"""
Created on 2021/12/07

@author: Yingjun Yang
"""
import os
import re
import logging
import platform
import subprocess

from lib.driver.utils.system import get_ip_address
from lib.driver.utils.ctype import byte_array_to_string

if 'Windows' not in platform.system():
    from lib.driver.nvme import Tahoe
    # from lib.driver.nvme import NVMe

LOG = logging.getLogger()


class TestCode:
    passed = 0
    failed = 1
    blocked = 2
    non_existed = 3
    unhealthy = 10
    abnormal = 99


class TestUnhealthy(Exception):
    pass


class TestFail(Exception):
    pass


class TestBlock(Exception):
    pass


class TestNonExisted(Exception):
    pass


class TestAbnormal(Exception):
    pass


class TestCase:
    def __init__(self):
        LOG.debug('__init__')
        self.check_info = True
        self.log = LOG
        self.is_linux = bool('Linux' in platform.system())

        if self.is_linux:
            self.nvme = Tahoe()

    def prescript(self, script_name=''):
        if self.is_linux:
            self.show_test_info(script_name)
            if os.environ['THIRD_SSD'] != 'True':
                self.check_sanitize()
                self.check_commit()
                self.check_wa()
                if os.environ.get('casemode', 'testcase') == 'testcase':
                    self.send_disable_bypass_gbb_vu()
            self.check_block_busy()
            self.check_available_spare()

    def _execute(self, cmd):
        status, output = subprocess.getstatusoutput(cmd)
        if status:
            return ''
        return output.strip()

    def _filter(self, string, pattern, index=0):
        try:
            return re.findall(pattern, string)[index].strip()
        except BaseException:
            return ''

    def _send_vu_cmd(self, func, *args, **kwargs):
        try:
            if os.environ['THIRD_SSD'] != 'True':
                return getattr(self.nvme.vu_cmd, func)(*args, **kwargs)
            return ''
        except BaseException as err:
            LOG.warning(err)
            return ''

    def show_testcase(self, string):
        if self.is_linux and os.environ.get('show_case', 'true') == 'true':
            self._send_vu_cmd('show_test_case', string)

    def check_sanitize(self):
        self.nvme.wait_sanitize_completed(300)

    def check_commit(self):
        commit = os.environ.get('commit')
        if commit:
            self.log.info('Commit id in command: %s', commit)
            if self.check_info and commit not in [None, 'no_set']:
                found = re.findall(r'commit (\w+)', byte_array_to_string(self.nvme.id_ctrl.VS))
                if found:
                    commit_id = found[0]
                    self.log.info('Commit id in identify ctrl: %s', commit_id)
                    assert commit in commit_id, f"Commit {commit} != {commit_id}"

    def check_available_spare(self):
        smart_log = self.nvme.get_log_smart_health_info()
        LOG.info('Available Spare: %s%%', smart_log.AS)
        assert smart_log.AS >= 50, "Available spare is < 50%, please check and recover!"

    def check_block_busy(self):
        for node in self.nvme.nodes:
            block = node['block']
            output = self._execute(f'lsof {block}')
            if output:
                self.log.info('lsof %s\n%s', block, output)
                assert block not in output, f'{block} is busy!'

    def check_wa(self):
        smart_log = self.nvme.get_log_smart_health_info()
        smart_ocp = self.nvme.get_log_smart_health_info_extend()

        nvm_capacity = self.nvme.id_ctrl.TNVMCAP.value
        host_written = smart_log.DUW.value * 512 * 1000
        nand_written = smart_ocp.PMUW.value
        self.log.info('Host Written: 0x%x, Nand Written: 0x%x, NVM Capacity: 0x%x',
                      host_written, nand_written, nvm_capacity)

        if host_written > nvm_capacity:
            write_amp = nand_written / host_written
            self.log.info('WA: Nand Written / Host Written = %.3f', write_amp)
            assert 5 >= write_amp >= 1, 'WA check failed!'
        else:
            self.log.warning('Host Written <= NVM Capacity, ignore WA check!')

    def show_test_info(self, script_name=''):
        node_name = self._execute('uname -n')
        kernel_release = self._execute('uname -r')
        cpu_version = self._filter(self._execute('dmidecode -t 4'), r'Version:\s+(.*)')
        product_name = self._filter(self._execute('dmidecode -t 2'), r'Product Name:\s+(.*)')
        login_info = f'{get_ip_address()}@{self._execute("whoami")}'

        int_type = self._send_vu_cmd('get_int_type')
        life_cycle = self._send_vu_cmd('get_drive_life_cycle_state')
        drive_info = byte_array_to_string(self._send_vu_cmd('get_drive_version_info'))
        security_type = self._filter(drive_info, r"Security type\s+:\s+([0-9_A-Za-z]+)")
        cfg_flash_type = self._filter(drive_info, r"CFG_FLASH_TYPE\s+:\s+([0-9_A-Za-z]+)")
        cfg_flash_bl = self._filter(drive_info, r"CFG_NAND_BLOCK_NUM\s+:\s+(\d+)")
        cfg_flash_pl = self._filter(drive_info, r"CFG_NAND_PLANE_NUM\s+:\s+(\d+)")
        cfg_flash_ln = self._filter(drive_info, r"CFG_NAND_LUN_NUM\s+:\s+(\d+)")
        cfg_flash_ch = self._filter(drive_info, r"Channel Count\s+:\s+(\d+)")
        fw_repo = self._filter(drive_info, r"GIT Path\s+:\s+(.*?)----->>")
        fw_branch = self._filter(drive_info, r"GIT Branch\s+:\s+(.*?)----->>")
        fw_commit = self._filter(drive_info, r"GIT Commit\s+:\s+commit\s+([a-z0-9]+)")

        script_repo = self._filter(self._execute('git remote -v'), r'origin\s+(.*?)\s+\(fetch\)')
        script_branch = self._execute('git symbolic-ref --short -q HEAD')
        script_commit = self._execute('git log -1 --pretty=format:%H')

        msg = list()
        msg.append('||||')
        msg.append('|--|--|--|')
        msg.append(f'|Tester Info|OS|{node_name} {kernel_release}|')
        msg.append(f'| |CPU|{cpu_version}|')
        msg.append(f'| |Base Board|{product_name}|')
        msg.append(f'| |PCIe Slot|{self.nvme.slot_dev}|')
        msg.append(f'| |Login Info|{login_info}|')

        msg.append(f'|Drive Info|INT type|{int_type}|')
        msg.append(f'| |Security Type|{security_type}|')
        msg.append(f'| |Life Cycle State|{life_cycle}|')
        msg.append(f'| |CFG Flash Type|{cfg_flash_type}|')
        msg.append(f'| |CFG Flash|BL({cfg_flash_bl}) PL({cfg_flash_pl}) LN({cfg_flash_ln}) CH({cfg_flash_ch})|')
        msg.append(f'| |Serial Number|{byte_array_to_string(self.nvme.id_ctrl.SN)}|')
        msg.append(f'| |Model Number|{byte_array_to_string(self.nvme.id_ctrl.MN)}|')
        if self.nvme.id_ns:
            mset = 'DIF' if self.nvme.id_ns.FLBAS & 0x10 else 'DIX'

            msg.append(f'| |Namespace Capacity(NCAP)|{self.nvme.id_ns.NCAP:#x}|')
            msg.append(f'| |Namespace Size(NSZE)|{self.nvme.id_ns.NSIZE:#x}|')
            msg.append(f'| |Namespace LBA Format|{self.nvme.lbads} + {self.nvme.lbams} ({mset})|')

        msg.append(f'|Firmware Info|Firmware Version|{byte_array_to_string(self.nvme.id_ctrl.FR)}|')
        msg.append(f'| |Firmware Repo|{fw_repo}|')
        msg.append(f'| |Firmware Branch|{fw_branch}|')
        msg.append(f'| |Firmware Commit|{fw_commit}|')

        msg.append('|Script Info|Script Platform|Perses|')
        msg.append(f'| |Script Repo|{script_repo}|')
        msg.append(f'| |Script Branch|{script_branch}|')
        msg.append(f'| |Script Commit|{script_commit}|')
        msg.append(f'| |Script Name|{script_name}|')

        msg.append('|Log Info|Script Log| |')
        msg.append('| |UART Log| |')
        msg.append('| |Telemetry Log| |')

        msg.append('|Fail Info|Fail Rate| |')
        msg.append('| |Time to Fail| |')
        msg.append('| |Customer Impact| |')
        msg.append('| |Recover Method| |')
        msg.append('| |Test Steps| |')

        LOG.info('\n%s', '\n'.join(msg))

    def send_disable_bypass_gbb_vu(self):
        self._send_vu_cmd('bypass_gbb', False)

    def setup(self):
        self.log.debug('setup')

    def teardown(self):
        self.log.debug('teardown')

    def passed(self, message):
        self.log.info(message)

    def failed(self, message):
        raise TestFail(message)

    def blocked(self, message):
        raise TestBlock(message)

    def unhealthy(self, message):
        raise TestUnhealthy(message)

    def search_for_ns(self, nsid_list):
        ns_list = []
        char = None
        for char in os.listdir("/sys/class/nvme"):
            if char in self.nvme.char_dev:
                break
        if char is None:
            return None
        char_path = os.path.join("/sys/class/nvme", char)
        for block in os.listdir(char_path):
            if re.findall(r'nvme\d+[c\d]*n\d+', block):
                _nsid = os.path.join(char_path, block, 'nsid')
                if os.path.exists(_nsid):
                    with open(_nsid, encoding="utf-8") as nsid_f:
                        nsid = int(nsid_f.read().strip())
                        if nsid in nsid_list:
                            ns_list.append("/dev/" + block)
        return ns_list


class TestDualPortCase:
    def __init__(self):
        LOG.debug('__init__')
        self.check_info = True
        self.log = LOG

    def setup(self):
        self.log.debug('setup')

    def teardown(self):
        self.log.debug('teardown')

    def passed(self, message):
        self.log.info(message)

    def failed(self, message):
        raise TestFail(message)

    def blocked(self, message):
        raise TestBlock(message)

    def unhealthy(self, message):
        raise TestUnhealthy(message)
