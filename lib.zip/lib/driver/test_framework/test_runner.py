# coding=utf-8
# pylint: disable=too-many-statements，raise-missing-from
import importlib
import logging
import os
import re
import sys
import time
from multiprocessing import Queue

from lib.driver.testcase import TestBlock, TestAbnormal, TestCode, TestUnhealthy
from lib.driver.utils.logger import Logging
from lib.driver.utils.process import MyProcess

LOG = logging.getLogger()


class Runner:

    def __init__(self):
        self.results = list()
        self.process_run_ = None

        self._class = None
        self._testcase = None
        self._class_name = None
        self._module_name = None
        self._func_name_list = []
        self.skip = os.environ.get('skip_teardown', 'false')

    @property
    def module_name(self):
        return self._module_name

    @property
    def class_name(self):
        return self._class_name

    @property
    def func_name_list(self):
        return self._func_name_list

    def _initial_testcase(self, path, name):
        try:
            matched = re.findall(r'^(.*?):(.*?)\.(.*?)$', name)
            assert matched, f'Invalid testcase: {name}'
            file_name, self._class_name, func_name = matched[0]
            self._func_name_list = [func_name]
        except BaseException:
            matched = re.findall(r'^(.*?):(.*?)$', name)
            assert matched, f'Invalid testcase: {name}'
            file_name, self._class_name = matched[0]

        sys.path.append(path)
        self._module_name = file_name.replace(r'.py', '')
        module = importlib.import_module(self._module_name)
        importlib.reload(module)
        self._class = getattr(module, self._class_name)

        for func_name in self.func_name_list:
            assert func_name.startswith(r'test_'), f'Invalid function name: {func_name}'
            assert hasattr(self._class, func_name), f'{self._class} has no {func_name}!'

        if not self.func_name_list:
            self._func_name_list = [f for f in dir(self._class) if f.startswith('test_')]

    def run(self, test_case, func_name):
        status = TestCode.passed
        try:
            LOG.info('%s - Test Start.', test_case)
            self._testcase = self._class()
            self._show_testcase(f'{test_case} Start')
            self._prescript(script_name=test_case)
            self._setup()
            self._run(func_name)
        except TestUnhealthy as exp:
            LOG.exception(exp)
            status = TestCode.unhealthy
        except TestAbnormal as exp:
            LOG.exception(exp)
            status = TestCode.abnormal
        except TestBlock as exp:
            LOG.exception(exp)
            status = TestCode.blocked
        except BaseException as exp:
            LOG.exception(exp)
            status = TestCode.failed
        finally:
            if status not in (TestCode.non_existed, TestCode.abnormal, TestCode.unhealthy):
                if status == TestCode.failed and self.skip.lower() == "true":
                    LOG.info('%s - Not run teardown.', test_case)
                else:
                    try:
                        self._teardown()
                    except Exception as exp:
                        LOG.exception(exp)
                        status = TestCode.failed

            try:
                self._show_testcase(f'{test_case} End')
            except:
                pass

            del self._testcase

            if status == TestCode.passed:
                LOG.info('%s - Test Passed.', test_case)
            elif status == TestCode.blocked:
                LOG.warning('%s - Test Blocked.', test_case)
            elif status == TestCode.abnormal:
                LOG.error('%s - Test Abnormal!', test_case)
            elif status == TestCode.unhealthy:
                LOG.error('%s - Test Unhealthy!', test_case)
            else:
                LOG.error('%s - Test Failed!', test_case)

        return status

    def _run(self, func_name):
        getattr(self._testcase, func_name)()

    def _prescript(self, script_name):
        if hasattr(self._testcase, 'prescript'):
            try:
                getattr(self._testcase, 'prescript')(script_name=script_name)
            except BaseException as exp:
                raise TestUnhealthy(repr(exp))

    def _show_testcase(self, string):
        if hasattr(self._testcase, 'show_testcase'):
            getattr(self._testcase, 'show_testcase')(string)

    def _setup(self):
        if hasattr(self._testcase, 'setup'):
            getattr(self._testcase, 'setup')()

    def _teardown(self):
        if hasattr(self._testcase, 'teardown'):
            getattr(self._testcase, 'teardown')()

    def run_test(self, file_name, test_case, queue):
        log = Logging(file_name, console_level=os.environ.get('level', 'INFO'))

        try:
            start_time = time.time()
            status = TestCode.abnormal
            try:
                path, name = os.path.split(test_case)
                self._initial_testcase(path, name)
            except BaseException as exp:
                LOG.exception(exp)
                LOG.error('%s - Test Non-Existed!', file_name)
                status = TestCode.non_existed
            else:
                for func_name in self.func_name_list:
                    status = self.run(f'{self.module_name}:{self.class_name}.{func_name}', func_name)
                    if status:
                        break

            result = {"name": file_name, "status": status, "log_file": log.log_file, "Elapsed": int(time.time() - start_time)}
            LOG.debug(result)
            queue.put(result)
        except BaseException as exp:
            LOG.exception(exp)
        finally:
            log.close()

        return status

    def get_results(self):
        return self.results

    def stop(self):
        print("test runner . stop")
        if self.process_run_ is not None:
            ret = self.process_run_.stop()
        else:
            ret = -1
        return ret

    def process_run(self, test_case, test_case_path, loop=1, timeout=0):
        value = None
        for _ in range(loop):
            start_time = time.time()
            current_time = start_time
            queue = Queue()
            self.process_run_ = MyProcess(target=self.run_test, args=(test_case, test_case_path, queue,))
            self.process_run_.start()
            if timeout > 0:
                while current_time - start_time < timeout:
                    current_time = time.time()
                    time.sleep(5)
                # os.kill(self.process_run_.pid, signal.CTRL_BREAK_EVENT)
                self.process_run_.terminate()
            else:
                self.process_run_.join()
            value = queue.get(True)
            self.results.append(value)
        return value


if __name__ == '__main__':
    pass
