import logging
import os
import re
import time

import checksumdir
from nose.tools import assert_equal

from lib.driver.test_framework.test_base import TestBase
from lib.driver.utils.ssh import SSH
from lib.driver.utils.system import get_root_path

LOG = logging.getLogger()


class OsRebootHandler(TestBase):

    def __init__(self):
        super().__init__()
        self.target_ip = os.environ["target_ip"]
        self.user = os.environ.get('user', 'root')
        self.password = os.environ.get('password', 'nvme')

        self.ssh = SSH(self.target_ip, username=self.user, password=self.password)
        self.ssh.open()
        self.ssh.command("mount -a")
        self.remote_env_path = self.get_remote_path()
        self.remote_env_perses_path = "{}/{}".format(self.remote_env_path, "perses")
        self.local_env_perses_path = get_root_path()
        self.setup_target_environment()

    def get_remote_path(self):
        network_path = r"/home/share/sqa/powercycle"
        if self.ssh.is_exist(network_path):
            remote_path = r"/home/share/sqa/powercycle/{}".format(self.target_ip)
        else:
            remote_path = r"/home/powercycle"
        return remote_path

    def remote_install(self, remote_path):
        command = "cd {} && python install.py".format(remote_path)
        status, output = self.ssh.command(command)
        if status != 0:
            print("remotes install failed")
        print(output)
        return status, output

    def dos2unit(self, remote_path):
        paths = ["{}/tools/fio".format(remote_path),
                 "{}/tools/vdbench504".format(remote_path)]
        for item in paths:
            command = "cd {} && dos2unix *".format(item)
            status, output = self.ssh.command(command)
            if status != 0:
                print("dos2unit {} install failed".format(item))
            print(output)

    def chmod_files(self, remote_path):
        paths = ["{}/tools/fio/fio".format(remote_path),
                 "{}/tools/vdbench504/vdbench".format(remote_path)]
        for item in paths:
            command = "chmod 777 {}".format(item)
            status, output = self.ssh.command(command)
            if status != 0:
                print("chmod  {}  failed".format(item))
            print(output)

    def upload_and_init_perses_2_target(self):
        if self.ssh.is_exist(self.remote_env_path) is False:
            self.ssh.make_dir(self.remote_env_path)
        if self.ssh.is_exist(self.remote_env_perses_path) is False:
            self.ssh.make_dir(self.remote_env_perses_path)
        self.ssh.sftp_put_dir(self.local_env_perses_path, self.remote_env_perses_path)
        self.remote_install(self.remote_env_perses_path)
        self.dos2unit(self.remote_env_perses_path)
        self.chmod_files(self.remote_env_perses_path)

    def update_modified_perses_2_target(self):
        compare_folder = ["configuration", "lib", "testcase", "testsuite", "testfile"]
        for folder in compare_folder:
            local_path = os.path.join(self.local_env_perses_path, folder)
            remote_path = r"{}/{}".format(self.remote_env_perses_path, folder)
            local_md5 = self.get_folder_md5(local_path)
            remote_md5 = self.get_folder_md5_by_ssh(remote_path)
            if local_md5 != remote_md5:
                temp_path = "{}/{}".format(self.remote_env_perses_path, folder)
                self.ssh.command("rm -r {}".format(temp_path))
                self.ssh.make_dir(temp_path)
                self.ssh.sftp_put_dir(local_path, temp_path)

    def setup_target_environment(self):
        ret = self.ssh.is_exist(self.remote_env_perses_path)
        if ret is False:
            self.upload_and_init_perses_2_target()
        else:
            self.update_modified_perses_2_target()

    def get_folder_md5(self, path):
        md5hash = None
        if os.path.exists(path):
            md5hash = checksumdir.dirhash(path, 'md5', excluded_extensions=['pyc'])
        return md5hash

    def get_folder_md5_by_ssh(self, path):
        md5 = None
        cmd = "checksumdir -a md5 {}".format(path)
        status, output = self.ssh.command(cmd)
        if status == 0:
            md5 = output.replace("\n", "")
        return md5

    def get_loop(self, test_name):
        loop = 1
        file_name = re.findall("([\w\.]*)\:", test_name)
        function_name = re.findall("\w*\:\w*\.(\w*)", test_name)
        if file_name:
            file_name_ = file_name[0] if ".py" in file_name[0] else file_name[0] + ".py"
            path = self.get_file_path(self.test_case_path, file_name_)
            with open(path, encoding='utf-8') as file:
                content = file.read()
            loops = re.findall(".*attr\(loop\=(\d+)\).*\n\s+def\s+{}\(self\)".format(function_name[0]), content)
            loop = loops[0] if loops else loop
        return loop

    def remote_run_test(self, test, loop=1):
        parameter = "loop:{}".format(loop)
        run_command = "cd {} && python run.py testcase -n {} -v {}".format(self.remote_env_perses_path, test, parameter)
        status, output = self.ssh.command(run_command)
        LOG.info("Remote_run_test command: %s, status: %s, output:\n %s", run_command, status, output)
        return status, output

    def wait_reboot_complete(self, time_out=1200):
        result = False
        start_time = time.time()
        current_time = start_time
        duration = current_time - start_time
        while duration < time_out:
            LOG.info("try to connect target compute: time %s", duration)
            try:
                self.ssh.open(timeout=1200)
            except RuntimeError:
                pass
            if self.ssh.is_active():
                self.ssh.command("mount -a")
                LOG.info("reboot succeed")
                result = True
                break
            duration = time.time() - start_time
        return result

    def run(self, test_name):
        loop = self.get_loop(test_name)
        for index in range(int(loop)):
            LOG.info("Run os reboot with io test: %s, loop: %s", test_name, index)
            self.remote_run_test(test_name, loop=index)
            result = self.wait_reboot_complete()
            assert_equal(result, True, msg="Reboot failed at loop {}".format(index))
            status, _ = self.remote_run_test(test_name, loop=index)
            assert_equal(status, 0, msg="{} failed at loop {}".format(test_name, index))
        LOG.info("Test case run succeed: %s", test_name)
