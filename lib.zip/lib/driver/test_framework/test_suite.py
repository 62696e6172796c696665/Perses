# coding=utf-8
# pylint: disable=unused-variable
import os
import time

import yaml

from lib.driver.testcase import TestCode
from lib.driver.test_framework.test_base import TestBase
from lib.driver.test_framework.test_runner import Runner


class TestSuite(TestBase):

    def __init__(self, stop_on_fail=1):
        super().__init__()
        self.runner = None
        self.stop_on_fail = stop_on_fail
        self.test_suite_folder = os.path.join(os.path.dirname(__file__), "..", "..", "..", "testsuite")
        self.test_suites = self.list_test_suite()

    def load_test_suite(self, test_suite):
        test_suite = test_suite + ".yaml"
        test_suite_path = self.get_file_path(self.test_suite_folder, test_suite)
        test_suites = None
        if test_suite_path is not None and os.path.exists(test_suite_path):
            with open(test_suite_path, encoding='utf-8') as file:
                test_suites = yaml.load(file, Loader=yaml.SafeLoader)
        else:
            raise Exception("TestSuite not exist: {}".format(test_suite))
        return test_suites

    def run(self, test_suite):
        self.runner = Runner()
        try:
            test_suites = self.load_test_suite(test_suite)
        except BaseException as message:
            print(message)
            result = [{"name": test_suite, "result": False}]
            return result

        for loop in range(int(test_suites["loop"])):
            print("Test Suite:%s, loop:%d", test_suites["name"], loop)
            for tests in test_suites["cases"]:
                test_path = self.get_all_script_path(tests["script"])
                test_path = test_path[0] if test_path else tests["script"]
                result = self.runner.process_run(tests["script"], test_path, tests["loop"], tests["duration"])
                if (result['status'] not in (TestCode.passed, TestCode.blocked, TestCode.non_existed)) \
                    and self.stop_on_fail:
                    break
                time.sleep(3)
        self.print_results(test_suite)
        return self.get_exit_code(self.runner.get_results())

    @staticmethod
    def get_exit_code(test_results):
        exit_code = 0
        for result in test_results:
            if result["status"] != TestCode.passed:
                exit_code = 10
                break
        return exit_code

    def list_test_suite(self):
        return self.list_and_filter_tests("all")

    def get_test_suites(self):
        return self.test_suites

    def list_and_filter_tests(self, filters):
        test_suites = []
        for root, dirs, files in os.walk(self.test_suite_folder):
            for file_ in files:
                if filters.lower() == "all":
                    test_suites.append(file_.split(".")[0])
                    continue
                if filters in file_:
                    test_suites.append(file_.split(".")[0])
        return test_suites

    def print_results(self, test_suite):
        result = self.runner.get_results()
        # print("###########################################################")
        # print("********************* Result Summary **********************")
        print('')
        print("********************* TestSuite: {} ***********************".format(test_suite))
        pass_items = filter(lambda x: x["status"] == TestCode.passed, result)
        fail_items = filter(lambda x: x["status"] != TestCode.passed, result)
        for item in result:
            if item["status"] == 0:
                print("TestCase: {}, Result: Pass".format(item["name"]))
            else:
                print("TestCase: {}, Result: Fail".format(item["name"]))
        print("Total Run {}, Pass {}, Fail {}".format(len(result), len(list(pass_items)), len(list(fail_items))))
        print('')
        # print("###########################################################")


if __name__ == '__main__':
    T = TestSuite()
    T.run("test_1")
