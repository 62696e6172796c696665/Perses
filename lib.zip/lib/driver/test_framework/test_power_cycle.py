import logging
import os
import re
import time
import checksumdir
from nose.tools import assert_equal
from lib.driver.utils.logger import Logging
from lib.driver.test_framework.test_base import TestBase
from lib.driver.utils.ssh import SSH
from lib.driver.utils.system import get_root_path
from lib.driver.testcase import TestCode

LOG = logging.getLogger()


class PowerCycleHandler(TestBase):

    def __init__(self, name):
        super().__init__()
        self.target_ip = os.environ["target_ip"]
        self.slot = os.environ.get("slot", 'None')
        self.dp_slot = os.environ.get("dp_slot", 'None')
        self.user = os.environ.get('user', 'root')
        self.password = os.environ.get('password', 'nvme')
        self.adapter = os.environ.get('adapter', 'cp20')
        self.commit = os.environ.get('commit', 'no_set')
        self.logging = Logging(name)

        self.ssh = SSH(self.target_ip, username=self.user, password=self.password)
        self.ssh.open()
        self.ssh.command("mount -a")
        self.remote_env_path = self.get_remote_path()
        self.remote_env_perses_path = "{}/{}".format(self.remote_env_path, "perses")
        self.local_env_perses_path = get_root_path()
        self.setup_target_environment()

    def __del__(self):
        self.logging.close()

    def get_remote_path(self):
        network_path = r"/home/nvme/SQA/powercycle"
        if self.ssh.is_exist(network_path):
            remote_path = r"/home/nvme/SQA/powercycle/{}".format(self.target_ip)
        else:
            remote_path = r"/home/powercycle"
        return remote_path

    def remote_install(self, remote_path):
        command = "cd {} && python install.py".format(remote_path)
        status, output = self.ssh.command(command)
        if status != 0:
            print("remotes install failed")
        print(output)
        return status, output

    def dos2unix(self, remote_path):
        paths = ["{}/tools/fio".format(remote_path),
                 "{}/tools/vdbench504".format(remote_path),
                 "{}/tools/usbrelay".format(remote_path)]
        for item in paths:
            command = "cd {} && dos2unix *".format(item)
            status, output = self.ssh.command(command)
            if status != 0:
                print("dos2unix {} install failed".format(item))
            print(output)

    def chmod_files(self, remote_path):
        paths = ["{}/tools/fio/fio".format(remote_path),
                 "{}/tools/vdbench504/vdbench".format(remote_path),
                 "{}/tools/usbrelay/usbrelay".format(remote_path)]
        for item in paths:
            command = "chmod 777 {}".format(item)
            status, output = self.ssh.command(command)
            if status != 0:
                print("chmod  {}  failed".format(item))
            print(output)

    def upload_and_init_perses_2_target(self):
        if self.ssh.is_exist(self.remote_env_path) is False:
            self.ssh.make_dir(self.remote_env_path)
        if self.ssh.is_exist(self.remote_env_perses_path) is False:
            self.ssh.make_dir(self.remote_env_perses_path)
        self.ssh.sftp_put_dir(self.local_env_perses_path, self.remote_env_perses_path)
        self.remote_install(self.remote_env_perses_path)
        self.dos2unix(self.remote_env_perses_path)
        self.chmod_files(self.remote_env_perses_path)

    def update_modified_perses_2_target(self):
        try:
            compare_folder = ["testfile", "configuration", "lib", "testcase", "testsuite", "tools"]
            for folder in compare_folder:
                local_path = os.path.join(self.local_env_perses_path, folder)
                remote_path = r"{}/{}".format(self.remote_env_perses_path, folder)
                local_md5 = self.get_folder_md5(local_path)
                remote_md5 = self.get_folder_md5_by_ssh(remote_path)
                if local_md5 != remote_md5:
                    temp_path = "{}/{}".format(self.remote_env_perses_path, folder)
                    self.ssh.command("rm -rf {}".format(temp_path))
                    self.ssh.make_dir(temp_path)
                    self.ssh.sftp_put_dir(local_path, temp_path)
            self.dos2unix(self.remote_env_perses_path)
        except Exception as exceptions:
            LOG.error(exceptions)

    def upload_tools(self):
        tools_path = "{}/tools".format(self.remote_env_perses_path)
        ret = self.ssh.is_exist(tools_path)
        if ret is False:
            local_path = os.path.join(self.local_env_perses_path, "tools")
            self.ssh.make_dir(tools_path)
            self.ssh.sftp_put_dir(local_path, tools_path)

    def update_run_file(self):
        local_path = os.path.join(self.local_env_perses_path, "run.py")
        remote_path = r"{}/{}".format(self.remote_env_perses_path, "run.py")
        self.ssh.command("rm -r {}".format(remote_path))
        self.ssh.sftp_put(local_path, remote_path)

    def setup_target_environment(self):
        ret = self.ssh.is_exist(self.remote_env_perses_path)
        if ret is False:
            self.upload_and_init_perses_2_target()
        else:
            self.update_modified_perses_2_target()
            # self.upload_tools()
            self.update_run_file()

    def get_folder_md5(self, path):
        md5hash = None
        if os.path.exists(path):
            md5hash = checksumdir.dirhash(path, 'md5', excluded_extensions=['pyc'])
        return md5hash

    def get_folder_md5_by_ssh(self, path):
        md5 = None
        cmd = "checksumdir {} -a md5 -x pyc".format(path)
        status, output = self.ssh.command(cmd)
        if status == 0:
            md5 = output.replace("\n", "")
        return md5

    def get_loop(self, test_name):
        loop = 1
        file_name = re.findall("([\w\.]*)\:", test_name)
        function_name = re.findall("\w*\:\w*\.(\w*)", test_name)
        if file_name:
            file_name_ = file_name[0] if ".py" in file_name[0] else file_name[0] + ".py"
            path = self.get_file_path(self.test_case_path, file_name_)
            with open(path, encoding='utf-8') as file:
                content = file.read()
            loops = re.findall(".*attr\((?:[^,]*,)*\s*loop\s*=\s*(\d+)\s*(?:,[^)]*)?\).*\n\s+def\s+{}\(self\)"
                               .format(function_name[0]), content)
            gbb = re.findall(r"@attr\((?:[^,]*,)*\s*gbb\s*=\s*(\d+)\s*(?:,[^)]*)?\).*\n\s+def\s+{}\(self\)"
                             .format(function_name[0]), content)
            loop = loops[0] if loops else loop
            bool_gbb = bool(int(gbb[0])) if gbb else False
        return loop, bool_gbb

    def remote_run_test(self, test, loop=1, before_reboot=True):
        before_reboot = "true" if before_reboot is True else "false"
        fw_path = os.environ.get('fw_path', 'not_set')
        parameter = "loop:{},before_reboot:{},adapter:{},commit:{},fw_path:{},casemode:powercycle".format(
            loop, before_reboot, self.adapter, self.commit, fw_path)
        if self.slot != "None":
            parameter = "{},slot:{}".format(parameter, self.slot)
        if self.dp_slot != "None":
            parameter = "{},dp_slot:{}".format(parameter, self.dp_slot)
        run_command = "cd {} && python run.py testcase -n {} -v {}".format(self.remote_env_perses_path, test, parameter)
        status, output = self.ssh.command(run_command)
        # LOG.info("Remote_run_test command: %s, status: %s, output:\n %s", run_command, status, output)
        return status, output

    def reboot(self):
        LOG.info("reboot......")
        for _ in range(20):
            self.check_ssh_is_open()
            try:
                self.ssh.command_without_result("reboot -nf", timeout=3)
                self.ssh.command_without_result("reboot", timeout=3)
            except Exception as err:
                LOG.info(err)
            if self.ssh.wait_disconnect(time_out=15) is True:
                self.ssh.close()
                return
        raise AssertionError("target computer fail to do reboot")

    def check_ssh_is_open(self, time_out=600):
        time_out += time.time()
        while time.time() < time_out:
            try:
                self.ssh.open(timeout=10)
                return
            except Exception:
                pass
        raise AssertionError("Fail to open ssh connect....")

    def wait_reboot_complete(self, time_out=600):
        result = False
        start_time = time.time()
        current_time = start_time
        duration = current_time - start_time
        while duration < time_out:
            LOG.info("try to connect target compute: time %s", duration)
            try:
                self.ssh.open(timeout=10)
            except Exception:
                pass
            if self.ssh.is_active():
                self.ssh.command("mount -a")
                LOG.info("reboot succeed")
                result = True
                break
            duration = time.time() - start_time
        return result

    def run(self, test_name):
        status = 0
        try:
            loop, gbb = self.get_loop(test_name)
            if gbb:
                status, _ = self.remote_run_test('test_power:TestPowerCycle.test_stop_gbb')
                if status != TestCode.passed:
                    return TestCode.failed
            for index in range(int(loop)):
                LOG.info("Run Power Cycle test: %s, loop: %s", test_name, index)
                status, _ = self.remote_run_test(test_name, loop=index, before_reboot=True)
                assert_equal(status, 0, msg="Before reboot: {} failed at loop {}".format(test_name, index))
                LOG.info("run testcase %s done", test_name)
                self.reboot()
                result = self.wait_reboot_complete()
                assert_equal(result, True, msg="Reboot failed at loop {}".format(index))
                status, _ = self.remote_run_test(test_name, loop=index, before_reboot=False)
                assert_equal(status, 0, msg="After reboot: {} failed at loop {}".format(test_name, index))
            LOG.info("Test case run succeed: %s", test_name)
            if gbb:
                status, _ = self.remote_run_test('test_power:TestPowerCycle.test_start_gbb', before_reboot=False)
                if status != TestCode.passed:
                    return TestCode.failed
        except Exception as exp:
            status = TestCode.failed if status == TestCode.passed else status
            LOG.exception(exp)
        finally:
            self.logging.close()
        return status
