import platform
import re
from ctypes import string_at, addressof
from lib.driver.utils.system import get_vendor_name
from lib.driver.utils.system import get_ip_address


if platform.system() == 'Windows':
    from lib.driver.nvme.nvme_windows import NVMe
else:
    from lib.driver.nvme import NVMe


class Environment:

    def __init__(self, dev="/dev/nvme0n1"):
        self.dev = dev
        self.dev_name, self.nsid = None, None
        self.nvme = self.get_nvme()

    def get_nvme(self):
        if self.get_operating_system() == "Windows":
            self.dev_name, self.nsid = self._get_windows_dev_name_nsid(self.dev)
            nvme = NVMe(self.nsid)
        else:
            self.dev_name, self.nsid = self._get_linux_dev_name_nsid(self.dev)
            nvme = NVMe(self.dev_name)
        return nvme

    def get_environments(self):
        env_args = {
            "vendor": self.get_vendor(),
            "vendor_name": get_vendor_name(self.get_vendor()),
            "ip": self.get_ip_addr(),
            "operating_system": self.get_operating_system(),
            "capacity": self.get_capacity_unit_gb(),
            "dev_name": self.dev,
            "fw_version": self.get_fw_version()
        }
        return env_args

    def _get_windows_dev_name_nsid(self, dev):
        namespace_id = None
        rets = re.findall("Drive(\d+)", dev)
        if rets:
            namespace_id = rets[0]
        return dev, int(namespace_id)

    def _get_linux_dev_name_nsid(self, dev):
        dev_name, namespace_id = None, None
        rets = re.findall("([\w\/]+\d)n(\d)", dev)
        if rets:
            dev_name, namespace_id = rets[0]
        return dev_name, int(namespace_id)

    def get_vendor(self):
        id_ctrl = self.nvme.identify_ctrl()
        return id_ctrl.VID

    def get_fw_version(self):
        id_ctrl = self.nvme.identify_ctrl()
        version = string_at(addressof(id_ctrl) + 64, 8)
        return version.decode('utf-8', errors='ignore')

    def get_ip_addr(self):
        ip_addr = get_ip_address()
        return ip_addr

    def get_operating_system(self):
        system = "Windows" if platform.system() == 'Windows' else "Linux"
        return system

    def get_capacity_unit_gb(self):
        id_ns = self.nvme.identify_ns()
        namespace_size = id_ns.NS
        formatted_lba_size = id_ns.FLBAF
        lba_data_size = id_ns.LBAF[int(formatted_lba_size)].LBADS
        lba_size = 2 ** (int(lba_data_size))
        size = (namespace_size * lba_size) / 1024 / 1024 / 1024
        return size

    def get_temperature(self):
        _, smart_health = self.nvme.get_log(lid=0x2, nsid=self.nsid, numdu=128)
        smart_health = smart_health.buf[0]
        print(smart_health.CT)
        return float('%.2f' % (smart_health.CT - 273.15))

    def get_ns_identify(self):
        pass

    def get_log_page(self):
        pass

    def get_project(self):
        pass
