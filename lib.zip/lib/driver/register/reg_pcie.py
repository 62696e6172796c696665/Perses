#!/usr/bin/env python
# pylint: disable=invalid-name
"""
NVMe System Bus (PCI Express) Registers

@author: Liangmin Huang
"""
import re
import time
from ctypes import sizeof

import lib.driver.nvme.struct.pcie as register
from lib.driver.utils.buf import Malloc
from lib.driver.utils.system import execute


class PCIeReg:
    """System Bus (PCI Express) Registers"""

    def __init__(self, debug=False, vf=None, bdf=None):
        self.cfg_space = None
        self.debug = debug
        self.header = None
        self.pmcap = None
        self.msicap = None
        self.msixcap = None
        self.pxcap = None
        self.aercap = None
        self.msicap_addr = 0
        self.msicap_buf = None
        self.aercap_addr = 0
        self.aercap_buf = None
        self.vf = vf

        self.bdf = self.get_pcie_bdf() if not bdf else bdf
        self.get_cfg_space()

        self.get_pcie_header()
        self.get_pm_capability()
        self.get_msi_capability()
        self.get_px_capability()
        self.get_msix_capability()
        # self.get_aer_capability()

    @staticmethod
    def get_pcie_bdf():
        """get BDF of Non-volatile device"""
        cmd = r"lspci | grep 'Non-Volatile'"
        status, output = execute(cmd, console=False, interrupt=False)
        if status:
            time.sleep(1)
            _, output = execute(cmd, console=False)
            #if status:
                #raise RuntimeError("{} failed!".format(cmd))

        bdf = re.findall("([a-f0-9:.]+)", output)[0]
        return bdf
        # self.bdf = r'0000:02:00.1'

    def get_cfg_space(self):
        """get config space of device"""
        #self.cfg_space = Malloc(512)
        self.cfg_space = Malloc(4096)
        cmd = "lspci -s {} -xxxx".format(self.bdf)
        status, output = execute(cmd, console=False, interrupt=False)
        if status:
            time.sleep(1)
            _, output = execute(cmd, console=False)
            #if status:
                #raise RuntimeError("{} failed!".format(cmd))
        reg = []
        #for i in range(32):
        for i in range(256):
            line = re.findall("%x0: ([0-9a-f ]+)" % i, output)[0]
            reg += line.split(" ")

        registers = [int(i, 16) for i in reg]
        #for i in range(512):
        for i in range(4096):
            self.cfg_space.set_uint8(i, registers[i])

    def set_pcie_reg(self, addr, val):
        cmd = "setpci -s {} {:x}.B={:x}".format(self.bdf, addr, val)
        status, _ = execute(cmd, console=False, interrupt=False)
        if status:
            time.sleep(1)
            _, _ = execute(cmd, console=False)
            #if status:
                #raise RuntimeError("{} failed!".format(cmd))

    def get_pcie_header(self):
        """get PCI Header"""
        self.header_buf = self.cfg_space.set_sub_buffer(0, sizeof(register.PCIHeader), types=register.PCIHeader)
        # self.header = self.cfg_space.convert(register.PCIHeader)
        # self.header_buf = buf.realloc(types=register.PCIHeader)
        self.header_addr = 0
        # print("ID Offset: %x"%register.PCIHeader.CMD_ID.offset)
        if self.debug:
            self.header_buf.dump()
        self.header = self.header_buf[0]

    def display_header(self):
        self.header_buf.dump(only_values=False)

    def display_pxcap(self):
        self.pxcap_buf.dump(only_values=False)

    def display_pm_cap(self):
        self.pmcap_buf.dump(only_values=False)

    def display_msi_cap(self):
        self.msicap_buf.dump(only_values=False)

    def set_pcie_header(self):
        length = self.header_buf.size
        #print("header_length: %d" % length)
        # return 1
        for i in range(length):
            val = self.header_buf.get_uint8(i)
            self.set_pcie_reg(self.header_addr + i, val)

    def get_pm_capability(self):
        """get PCI Power Management Capability"""
        off = self.get_base_address(register.CapabilityID.PMCapability)
        if off:
            self.pmcap_addr = off
            self.pmcap_buf = self.cfg_space.set_sub_buffer(off, sizeof(register.PMCapability),
                                                           types=register.PMCapability)
            # self.pmcap = buf.realloc(register.PMCapability)
            # self.pmcap_buf = buf.realloc(types=register.PMCapability)
            if self.debug:
                self.pmcap_buf.dump()
            self.pmcap = self.pmcap_buf[0]

    def set_pmcap(self):
        if self.pmcap_buf:
            length = self.pmcap_buf.size
            for i in range(length):
                val = self.pmcap_buf.get_uint8(i)
                self.set_pcie_reg(self.pmcap_addr + i, val)

    def get_msi_capability(self):
        """get Message Signaled Interrupt Capability"""
        off = self.get_base_address(register.CapabilityID.MSICapability)
        if off:
            self.msicap_addr = off
            self.msicap_buf = self.cfg_space.set_sub_buffer(off, sizeof(register.MSICapability),
                                                            types=register.MSICapability)
            # self.msicap = buf.realloc(register.MSICapability)
            # self.msicap_buf = buf.realloc(types=register.MSICapability)
            if self.debug:
                self.msicap_buf.dump()
            self.msicap = self.msicap_buf[0]

    def set_msicap(self):
        if self.msicap_buf:
            length = self.msicap_buf.size
            for i in range(length):
                val = self.msicap_buf.get_uint8(i)
                self.set_pcie_reg(self.msicap_addr + i, val)

    def get_msix_capability(self):
        """get MSI-X Capability"""
        off = self.get_base_address(register.CapabilityID.MSIXCapability)
        if off:
            self.msixcap_addr = off
            self.msixcap_buf = self.cfg_space.set_sub_buffer(off, sizeof(register.MSIXCapability),
                                                             types=register.MSIXCapability)
            # self.msixcap = buf.realloc(register.MSIXCapability)
            # self.msixcap_buf = buf.realloc(types=register.MSIXCapability)
            if self.debug:
                self.msixcap_buf.dump()
            self.msixcap = self.msixcap_buf[0]

    def set_msixcap(self):
        if self.msixcap_buf:
            length = self.msixcap_buf.size
            for i in range(length):
                val = self.msixcap_buf.get_uint8(i)
                self.set_pcie_reg(self.msixcap_addr + i, val)

    def get_px_capability(self):
        """get PCI Express Capability"""
        off = self.get_base_address(register.CapabilityID.PXCapability)
        if off:
            self.pxcap_addr = off
            self.pxcap_buf = self.cfg_space.set_sub_buffer(off, sizeof(register.PXCapability),
                                                           types=register.PXCapability)
            # self.pxcap_buf = buf.realloc(types=register.PXCapability)
            if self.debug:
                self.pxcap_buf.dump()
            self.pxcap = self.pxcap_buf[0]

    def set_pxcap(self):
        if self.pxcap_buf:
            length = self.pxcap_buf.size
            for i in range(length):
                val = self.pxcap_buf.get_uint8(i)
                self.set_pcie_reg(self.pxcap_addr + i, val)

    def get_aer_capability(self):
        """get PCI Express Capability"""
        off = self.get_aer_address(register.CapabilityID.AERCapability)
        if off:
            self.aercap_addr = off
            self.aercap_buf = self.cfg_space.set_sub_buffer(off, sizeof(register.AERCapability),
                                                            types=register.AERCapability)
            # self.aercap_buf = buf.realloc(types=register.AERCapability)
            if self.debug:
                self.aercap_buf.dump()
            self.aercap = self.aercap_buf[0]

    def set_aercap(self):
        if self.aercap_buf:
            length = self.aercap_buf.size
            for i in range(length):
                val = self.aercap_buf.get_uint8(i)
                self.set_pcie_reg(self.aercap_addr + i, val)

    def get_base_address(self, cid):
        """get base address"""
        base = self.header.CAP_CP
        for _ in range(10):
            did = self.cfg_space.get_uint8(base)
            if did == cid:
                # break
                return base
            base = self.cfg_space.get_uint8(base + 1)
        # else:
        #    raise RuntimeError("cannot get CID[%x] base address" % cid)
        # print("find base addr, Cid: %x, Base: %x"%(cid, base))
        return 0

    def get_aer_address(self, cid):
        """get base address"""
        return 0x100
