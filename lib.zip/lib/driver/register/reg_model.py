#!/usr/bin/python
# pylint: disable=inconsistent-return-statements
"""
Created on 2017/10/30

@author: Liangmin
"""
import logging
import collections

from lib.driver.utils.pcie import PCIe
LOG = logging.getLogger()

def reg_info(info):
    LOG.info("[REGMODE][INFO]%s", info)


def reg_warn(info):
    LOG.info("[REGMODE][WARN]%s", info)


def reg_err(info):
    LOG.info("[REGMODE][ERROR]%s", info)


class RegField:
    def __init__(self, rwdev, addr, \
                 name, des, bitw, startp, default, mode):
        self.name = name
        self.bitw = bitw
        self.stp = startp
        self.mode = mode
        self.addr = addr
        self.default = default
        self.is_skip = False
        if rwdev is None:
            self.rwdev = PCIe()
        else:
            self.rwdev = PCIe(rwdev)
        self.act_val = default
        self.exp_val = default
        self.length = 32
        self.des = des
        self.is_checkable = 1

    def write(self, value, force=1):
        if (not self.is_skip) or (force):
            self.regset(value)
            self.val_up(value, 1)

    def read(self):
        value = self.regget()
        self.val_up(value, 0)
        return value

    def set(self, value):
        self.exp_val = value

    def get(self):
        return self.exp_val

    def val_up(self, value, wrf):
        mask = (2 ** self.bitw - 1)
        value = value & mask
        if self.mode.upper() == "RW":
            self.act_val = value
            self.exp_val = value
        elif self.mode.upper() == "RW1C":
            self.act_val = 0
            self.exp_val = 0
        elif self.mode.upper() == "RW1S":
            self.act_val = 0
            self.exp_val = 0
        elif self.mode.upper() == "WC":
            if wrf == 1:
                self.act_val = 0
                self.exp_val = 0
        elif self.mode.upper() == "RO":
            self.act_val = self.exp_val
        elif self.mode.upper() == "RC":
            if wrf == 0:
                self.act_val = 0
                self.exp_val = 0
        elif self.mode.upper() == "NA":
            self.act_val = value
            self.exp_val = value
            self.is_checkable = 0
        else:
            reg_err("register[%s] RW_mode[%s] is illegal" % (self.name, self.mode))

    def mirror(self, chk=0):
        self.act_val = self.regget()
        ok_flag = 1
        if (chk == 1) and (self.is_checkable):
            if self.act_val != self.exp_val:
                reg_err("register[%30s] RW_mode[%s] check failed[exp:%x,act:%x]" \
                        % (self.name, self.mode, self.exp_val, self.act_val))
                ok_flag = 0
        self.exp_val = self.act_val
        return ok_flag

    def update(self):
        self.regset(self.act_val)

    def bit32get(self, off, wid, val):
        mask = (2 ** wid - 1)
        value = (val & (mask << off))
        return value

    def bit32set(self, off, wid, value, setv):
        mask = 0xffffffff - ((2 ** wid - 1) << off)
        set_mask = setv << off
        val = ((value & mask) | set_mask) & 0xffffffff
        return val

    def get_field(self, value):
        mask = (2 ** self.bitw - 1)
        off = self.stp
        return (value & (mask << off)) >> off

    def set_field(self, fval, tval):
        off = self.stp
        mask = 0xffffffff - ((2 ** self.bitw - 1) << off)
        set_mask = fval << off
        val = ((tval & mask) | set_mask) & 0xffffffff
        # print(off,hex(mask))
        # print("tval:%x, fval:%x, mask:%x, val:%x"%(tval,fval,set_mask,val))
        return val

    def regget(self):
        # reg_info("register[%40s]:addr[0x%08x][%s] "%(self.name,self.addr,self.mode))
        value = self.readreg32(self.addr)
        val = self.get_field(value)
        # print hex(val)
        return val

    def regset(self, setv):
        value = self.readreg32(self.addr)
        val = self.set_field(setv, value)
        # reg_info("write register[%40s]:addr[0x%08x] val[0x%x] "%(self.name,self.addr,val))
        self.writereg32(self.addr, val)
        return val

    def readreg32(self, addr):
        val = self.rwdev.read_bar_uint32(self.addr)
        return val

    def writereg32(self, addr, val):
        self.rwdev.write_bar_uint32(self.addr, val)

    def regprint(self):
        reg_info("register[%10s]: Val[0x%08x][%s]  %s " \
                 % (self.name, self.act_val, self.mode, self.des))

    def setskip(self, val):
        self.is_skip = val


class Reg:
    def __init__(self, rwdev, addr, name, des=""):
        self.addr = addr
        self.name = name
        self.des = des
        self.field_list = collections.OrderedDict()

    def build(self, reg_field, bitw=32):
        if isinstance(reg_field, RegField):
            self.field_list[reg_field.name] = (reg_field)

    def mirror(self, chk=0):
        ok_flag = 1
        for i in self.field_list:
            tmp = self.field_list[i].mirror(chk)
            if tmp == 0:
                ok_flag = 0
                reg_err("------------Register[%s][addr:0x%x] check Failed----------" \
                        % (self.name, self.addr))
        return ok_flag

    def update(self):
        for i in self.field_list:
            self.field_list[i].update()

    def setrdma(self, val):
        for i in self.field_list:
            self.field_list[i].setrdma(val)

    def setskip(self, value, field):
        if field in self.field_list:
            self.field_list[field].setskip(value)
            return 1
        reg_err("Not Exist Filed[%s]" % field)
        return 0

    def regprint(self):
        reg_info("------------%s[addr:0x%x] Regprint begin----------" \
                 % (self.name, self.addr))
        for i in self.field_list:
            self.field_list[i].regprint()

    def write(self, value, field):
        if field.upper() == "ALL":
            for i in self.field_list:
                fval = self.field_list[i].get_field(value)
                self.field_list[i].write(fval, force=0)
        else:
            if field in self.field_list:
                self.field_list[field].write(value, force=1)
            else:
                reg_err("Not Exist Filed[%s]" % field)
                return 0

    def read(self, field):
        if field.upper() == "ALL":
            value = 0
            for i in self.field_list:
                fval = self.field_list[i].read()
                self.field_list[i].set_field(value, fval)
            return value
        if field in self.field_list:
            value = self.field_list[field].read()
        else:
            reg_err("Not Exist Filed[%s]" % field)
            value = 0
        return value

    def set(self, value, field):
        if field.upper() == "ALL":
            reg_err("Not Support yet")
            return 0
        if field in self.field_list:
            self.field_list[field].set(value)
        else:
            reg_err("Not Exist Filed[%s]" % field)
            return 0

    def get(self, field):
        if field.upper() == "ALL":
            reg_err("Not Support yet")
            return 0
        if field in self.field_list:
            value = self.field_list[field].get()
        else:
            reg_err("Not Exist Filed[%s]" % field)
            return 0
        return value


class RegBlock:
    def __init__(self, rwdev):
        self.rwdev = rwdev
        self.reg_list = collections.OrderedDict()

    def build(self, reg):
        if isinstance(reg, Reg):
            self.reg_list[reg.name] = (reg)

    def mirror(self, chk=0):
        ok_flag = 1
        for i in self.reg_list:
            tmp = self.reg_list[i].mirror(chk)
            if tmp == 0:
                ok_flag = 0
        return ok_flag

    def update(self):
        for i in self.reg_list:
            self.reg_list[i].update()

    def setrdma(self, val):
        for i in self.reg_list:
            self.reg_list[i].setrdma(val)

    def setskip(self, value, reg, field):
        if reg in self.reg_list:
            self.reg_list[reg].setskip(value, field)
        else:
            reg_err("Not Exist Reg[%s]" % reg)

    def regprint(self):
        for i in self.reg_list:
            self.reg_list[i].regprint()

    def write(self, value, reg, field):
        if isinstance(reg, str):
            if reg in self.reg_list:
                self.reg_list[reg].write(value, field)
            else:
                reg_err("Not Exist Reg[%s]" % reg)
        elif isinstance(reg, int):
            for i in self.reg_list:
                if self.reg_list[i].addr == reg:
                    self.reg_list[i].write(value, field)
                    return
            reg_err("Not Exist Reg[%s]" % reg)

    def read(self, reg, field):
        if isinstance(reg, str):
            if reg in self.reg_list:
                value = self.reg_list[reg].read(field)
                return value
            reg_err("Not Exist Reg[%s]" % reg)
        elif isinstance(reg, int):
            for i in self.reg_list:
                if self.reg_list[i].addr == reg:
                    value = self.reg_list[i].read(field)
                    return value
            reg_err("Not Exist Reg[%s]" % reg)

    def set(self, value, reg, field):
        if isinstance(reg, str):
            if reg in self.reg_list:
                self.reg_list[reg].set(value, field)
            else:
                reg_err("Not Exist Reg[%s]" % reg)
        elif isinstance(reg, int):
            for i in self.reg_list:
                if self.reg_list[i].addr == reg:
                    self.reg_list[reg].set(value, field)
                    return
            reg_err("Not Exist Reg[%s]" % reg)

    def get(self, reg, field):
        if isinstance(reg, str):
            if reg in self.reg_list:
                value = self.reg_list[reg].get(field)
                return value
            reg_err("Not Exist Reg[%s]" % reg)
        elif isinstance(reg, int):
            for i in self.reg_list:
                if self.reg_list[i].addr == reg:
                    value = self.reg_list[reg].get(field)
                    return value
            reg_err("Not Exist Reg[%s]" % reg)

    def rw_check(self):
        # val = random.randrange(0, 0xffffffff)
        for i in self.reg_list:
            # self.reg_list[i].write(0xa5a5a5a5, "ALL")
            val = self.reg_list[i].read("ALL")
        for i in self.reg_list:
            self.reg_list[i].write(0xffffffff - val, "ALL")
        return self.mirror(1)
