#!/usr/bin/python
# pylint: disable=invalid-name
'''
NVME 1.2
'''
from lib.driver.register import reg_model


class REG_CAP_L(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "MQES", "Maxinum Queue Entries Supported", 16, 0, 0xffff, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CQR", "Contiguous Queues Required", 1, 16, 1, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "AMS", "Arbitration Mechanism Supported", 2, 17, 1, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 5, 19, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "TO", "Timeout", 8, 24, 0xff, "RO"))


class REG_CAP_H(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "DSTRD", "Doorbell Stride", 4, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "NSSRS", "NVM Subsystem Reset Supported", 1, 4, 1, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CSS", "Command Sets Supported", 8, 5, 1, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "BPS", "Boot Partition Support", 1, 13, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 2, 14, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "MPSMIN", "Memory Page Size Minimum", 4, 16, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "MPSMAX", "Memory Page Size Maximum", 4, 20, 0xf, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "PMRS", "Persistent Memory Region Supported", 1, 24, 1, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CMBS", "Controller Memory Buffer Supported", 1, 25, 1, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV1", "Reserved", 6, 26, 0, "RO"))


class REG_VS(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "TER", "Reserved", 8, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "MNR", "Minor Version Number", 8, 8, 0x3, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "MJR", "Major Version Number", 16, 16, 0x1, "RO"))


class REG_INTMS(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "IVMS", "Interrupt Vector Mask Set", 32, 0, 0, "RW1S"))


class REG_INTMC(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "IVMC", "Interrupt Vector Mask Clear", 32, 0, 0, "RW1C"))


class REG_CC(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "EN", "Enable", 1, 0, 1, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 3, 1, 0, "RO"))
        self.build(
            reg_model.RegField(rwdev, addr, "CSS", "I/O Command Set Selected", 3, 4, 0, "RW"))  # RW when CC.EN is low
        self.build(reg_model.RegField(rwdev, addr, "MPS", "Memory Page Size", 4, 7, 0, "RW"))  # RW when CC.EN is low
        self.build(reg_model.RegField(rwdev, addr, "AMS", "Arbitration Mechanism Selected", 2, 11, 0,
                                      "RW"))  # RW when CC.EN is low
        self.build(reg_model.RegField(rwdev, addr, "SHN", "Shutdown Notification", 2, 14, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "IOSQES", "I/O Submission Queue Entry Size", 4, 16, 6, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "IOCQES", "I/O Completion Queue Entry Size", 4, 20, 4, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV1", "Reserved", 8, 24, 0, "RO"))


class REG_CSTS(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "RDY", "Ready", 1, 0, 1, "NA"))
        self.build(reg_model.RegField(rwdev, addr, "CFS", "Controller Fatal Status", 1, 1, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "SHST", "Shutdown Status", 2, 2, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "NSSRO", "NVM Subsystem Reset Occured", 1, 4, 0, "RW1C"))
        self.build(reg_model.RegField(rwdev, addr, "PP", "Processing Paused", 1, 5, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 26, 6, 0, "RO"))


class REG_NSSR(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "NSSRC", "NVM Subsystem Reset Control", 32, 0, 0, "RO"))


class REG_AQA(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "ASQS", "Admin Submission Queue Size", 12, 0, 0x3f, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 4, 12, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "ACQS", "Admin Completion Queue Size", 12, 16, 0x3f, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV1", "Reserved", 4, 28, 0, "RO"))


class REG_ASQ_L(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 12, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "ASQB", "Admin Submission Queue Base", 20, 12, 0, "RW"))


class REG_ASQ_H(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "ASQB", "Admin Submission Queue Base", 32, 0, 0, "RW"))


class REG_ACQ_L(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 12, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "ACQB", "Admin Completion Queue Base", 20, 12, 0, "RW"))


class REG_ACQ_H(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "ACQB", "Admin Completion Queue Base", 32, 0, 0, "RW"))


class REG_CMBLOC(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "BIR", "Base Indicator Register", 3, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CQMMS", "CMB Queue Mixed Memory Support", 1, 3, 0, "RO"))
        self.build(
            reg_model.RegField(rwdev, addr, "CQPDS", "CMB Queue Physically Discontiguous Support", 1, 4, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CDPMLS", "CMB Data Pointer Mixed Locations Support", 1, 5, 0, "RO"))
        self.build(
            reg_model.RegField(rwdev, addr, "CDPCILS", "CMB Data Pointer and Command Independent Locations Support", 1,
                               6, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CDMMMS", "CMB Data Metadata Mixed Memory Support", 1, 7, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CQDA", "CMB Queue Dword Alignment", 1, 8, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 3, 3, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "OFST", "Offset", 20, 12, 0, "RO"))


class REG_CMBSZ(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "SQS", "Submission Queue Support", 1, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CQS", "Completion Queue Support", 1, 1, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "LISTS", "PRP SGL List Support", 1, 2, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "RDS", "Read Data Support", 1, 3, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "WDS", "Write Data Support", 1, 4, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 3, 5, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "SZU", "Size Units", 4, 8, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "SZ", "Size", 20, 12, 0, "RO"))


class REG_BPINFO(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "BPSZ", "Boot Partition Size", 15, 0, 0x0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 9, 15, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "BRS", "Boot Read Status", 2, 24, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV1", "Reserved", 5, 26, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "ABPID", "Active Boot Partition ID", 1, 31, 0, "RO"))


class REG_BPRSEL(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "BPRSZ", "Boot Partition Read Size", 10, 0, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "BPROF", "Boot Partition Read Offset", 20, 10, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 1, 30, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "BPID", "Boot Partition ID", 1, 31, 0, "RW"))


class REG_BPMBL_L(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 12, 0, 0, "RO"))
        self.build(
            reg_model.RegField(rwdev, addr, "BMBBA", "Boot Partition Memory Buffer Base Address", 20, 12, 0, "RW"))


class REG_BPMBL_H(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(
            reg_model.RegField(rwdev, addr, "BMBBA", "Boot Partition Memory Buffer Base Address", 32, 0, 0, "RW"))


class REG_CMBMSC_L(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "CRE", "Capabilities Registers Enabled", 1, 0, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "CMSE", "Controller Memory Space Enable", 1, 1, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 10, 2, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CBA", "Controller Base Address", 20, 12, 0, "RW"))


class REG_CMBMSC_H(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "CBA", "Controller Base Address", 32, 0, 0, "RW"))


class REG_CMBSTS(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "CBAI", "Controller Base Address Invalid", 1, 0, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 31, 1, 0, "RO"))


class REG_PMRCAP(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 3, 1, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "RDS", "Read Data Support", 1, 3, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "WDS", "Write Data Support", 1, 4, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "BIR", "Base Indicator Register", 3, 4, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "PMRTU", "Persistent Memory Region Time Units", 3, 8, 0, "RO"))
        self.build(
            reg_model.RegField(rwdev, addr, "PMRWBM", "Persistent Memory Region Write Barrier Mechanisms", 4, 10, 0,
                               "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV1", "Reserved", 2, 14, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "PMRTO", "Persistent Memory Region Capabilities", 8, 16, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CMSS", "Controller Memory Space Supported", 1, 24, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV2", "Reserved", 7, 25, 0, "RO"))


class REG_PMRCTL(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "EN", "Enable", 1, 0, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 31, 1, 0, "RO"))


class REG_PMRSTS(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "ERR", "Error", 8, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "NRDY", "Not Ready", 1, 8, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "HSTS", "Health Status ", 3, 9, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CBAI", "Controller Base Address Invalid", 1, 12, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 19, 13, 0, "RO"))


class REG_PMREBS(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "PMRSZU", "PMR Elasticity Buffer Size Units", 4, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "RBB", "Read Bypass Behavior", 1, 4, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 3, 5, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "PMRWBZ", "PMR Elasticity Buffer Size Base", 24, 8, 0, "RO"))


class REG_PMRSWTP(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "PMRSWTU", "Error", 4, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "REV", "Reserved", 4, 4, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "PMRSWTV", "PMR Sustained Write Throughput", 24, 8, 0, "RO"))


class REG_PMRMSC_L(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "REV0", "Reserved", 1, 0, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CMSE", "Controller Memory Space Enable", 1, 1, 0, "RW"))
        self.build(reg_model.RegField(rwdev, addr, "REV1", "Reserved", 10, 2, 0, "RO"))
        self.build(reg_model.RegField(rwdev, addr, "CBA", "Controller Base Address", 20, 12, 0, "RW"))


class REG_PMRMSC_H(reg_model.Reg):
    def __init__(self, rwdev, addr, name, des):
        super().__init__(rwdev, addr, name, des)
        self.build(reg_model.RegField(rwdev, addr, "CBA", "Controller Base Address", 32, 0, 0, "RW"))


class nvm_reg_model(reg_model.RegBlock):
    def __init__(self, rwdev=None):
        super().__init__(rwdev)
        # self.build(REG_CAP_L(rwdev, 0x600000+0x0 ,"CAPL",  "Controller Capabilities low32"))
        # self.build(REG_CAP_H(rwdev, 0x600000+0x4 ,"CAPH",  "Controller Capabilities high32"))
        # self.build(REG_VS(rwdev,    0x600000+0x8 ,"VS",  "Version"))
        # self.build(REG_INTMS(rwdev, 0x600000+0xc ,"INTMS",  "Interrupt Mask Set"))
        # self.build(REG_INTMC(rwdev, 0x600000+0x10,"INTMC", "Interrupt Mask Clear"))
        # self.build(REG_CC(rwdev,    0x600000+0x14,"CC", "Controller Configuration"))
        # self.build(REG_CSTS(rwdev,  0x600000+0x1c,"CSTS", "Controller Status"))
        # self.build(REG_NSSR(rwdev,  0x600000+0x20,"NSSR", "NVM Subsystem Reset"))
        # self.build(REG_AQA(rwdev,   0x600000+0x24,"AQA", "Admin Queue Attributes"))
        # self.build(REG_ASQ_L(rwdev, 0x600000+0x28,"ASQL", "Admin Submission Queue Base Address low32"))
        # self.build(REG_ASQ_H(rwdev, 0x600000+0x2c,"ASQH", "Admin Submission Queue Base Address high32"))
        # self.build(REG_ACQ_L(rwdev, 0x600000+0x30,"ACQL", "Admin Completion Queue Base Address low32"))
        # self.build(REG_ACQ_H(rwdev, 0x600000+0x34,"ACQH", "Admin Completion Queue Base Address high32"))
        # self.build(REG_CMBLOC(rwdev,0x600000+0x38,"CMBLOC", "Controller Memory Buffer Location"))
        # self.build(REG_CMBSZ(rwdev, 0x600000+0x3c,"CMBSZ", "Controller Memory Buffer Size"))
        self.build(REG_CAP_L(rwdev, 0x0, "CAPL", "Controller Capabilities low32"))
        self.build(REG_CAP_H(rwdev, 0x4, "CAPH", "Controller Capabilities high32"))
        self.build(REG_VS(rwdev, 0x8, "VS", "Version"))
        self.build(REG_INTMS(rwdev, 0xc, "INTMS", "Interrupt Mask Set"))
        self.build(REG_INTMC(rwdev, 0x10, "INTMC", "Interrupt Mask Clear"))
        self.build(REG_CC(rwdev, 0x14, "CC", "Controller Configuration"))
        self.build(REG_CSTS(rwdev, 0x1c, "CSTS", "Controller Status"))
        self.build(REG_NSSR(rwdev, 0x20, "NSSR", "NVM Subsystem Reset"))
        self.build(REG_AQA(rwdev, 0x24, "AQA", "Admin Queue Attributes"))
        self.build(REG_ASQ_L(rwdev, 0x28, "ASQL", "Admin Submission Queue Base Address low32"))
        self.build(REG_ASQ_H(rwdev, 0x2c, "ASQH", "Admin Submission Queue Base Address high32"))
        self.build(REG_ACQ_L(rwdev, 0x30, "ACQL", "Admin Completion Queue Base Address low32"))
        self.build(REG_ACQ_H(rwdev, 0x34, "ACQH", "Admin Completion Queue Base Address high32"))
        self.build(REG_CMBLOC(rwdev, 0x38, "CMBLOC", "Controller Memory Buffer Location"))
        self.build(REG_CMBSZ(rwdev, 0x3c, "CMBSZ", "Controller Memory Buffer Size"))
        self.build(REG_BPINFO(rwdev, 0x40, "BPINFO", "Boot Partition Information"))
        self.build(REG_BPRSEL(rwdev, 0x44, "BPRSEL", " Boot Partition Read Select"))
        self.build(REG_BPMBL_L(rwdev, 0x48, "BPMBLL", "Boot Partition Memory Buffer Location LOW32"))
        self.build(REG_BPMBL_H(rwdev, 0x4C, "BPMBLH", "Boot Partition Memory Buffer Location HIGH32"))
        self.build(REG_CMBMSC_L(rwdev, 0x50, "CMBMSCL", " Controller Memory Buffer Memory Space Control LOW32"))
        self.build(REG_CMBMSC_H(rwdev, 0x54, "CMBMSCH", " Controller Memory Buffer Memory Space Control HIGH32"))
        self.build(REG_CMBSTS(rwdev, 0x58, "CMBSTS", "Controller Memory Buffer Status"))
        self.build(REG_PMRCAP(rwdev, 0xE00, "PMRCAP", "Persistent Memory Region Capabilities"))
        self.build(REG_PMRCTL(rwdev, 0xE04, "PMRCTL", "Persistent Memory Region Control"))
        self.build(REG_PMRSTS(rwdev, 0xE08, "PMRSTS", "Persistent Memory Region Status"))
        self.build(REG_PMREBS(rwdev, 0xE0C, "PMREBS", "Persistent Memory Region Elasticity Buffer Size"))
        self.build(REG_PMRSWTP(rwdev, 0xE10, "PMRSWTP", "Persistent Memory Region Sustained Write Throughput"))
        self.build(REG_PMRMSC_L(rwdev, 0xE14, "PMRMSCL", "Persistent Memory Region Memory Space Control LOW32"))
        self.build(REG_PMRMSC_H(rwdev, 0xE18, "PMRMSCH", "Persistent Memory Region Memory Space Control HIGH32"))
