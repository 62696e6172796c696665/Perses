#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>


#define nvme_ctrl_sysfs_dir "/sys/class/nvme"

//data write to addr+offset
void writeMMap(int dev_fd,unsigned int addr,unsigned int offset,unsigned int data)
{
	unsigned int mmapByte = getpagesize();
	// unsigned int mmapByte = offset + 0x04;
	unsigned char *map_base = (unsigned char * )mmap(NULL, mmapByte, PROT_READ | PROT_WRITE, MAP_SHARED, dev_fd, addr );  
	if(map_base == (unsigned char *)-1)
	{
		printf("MMAP Error.\r\n");
		return;
	}
	printf("Before Modify : addr 0x%08X = 0x%08X\r\n",(addr+offset),*(volatile unsigned int *)(map_base+offset));
	*(volatile unsigned int *)(map_base + offset) = data;
	printf("After Modify : addr 0x%08X = 0x%08X\r\n",(addr+offset),*(volatile unsigned int *)(map_base+offset));
	munmap(map_base,mmapByte);
}


int write_regs(char* dev, int addr,int off,int byte)
{
	char* path_head = "/sys/class/nvme/";
	char* path_tail = "/device/resource0";
	char* path = (char *) malloc(strlen(path_head)+strlen(dev)+strlen(path_tail)+1);
	strcpy(path, path_head);
	strcat(path, dev);
	strcat(path, path_tail);
	int fd = open(path, O_RDWR | O_NDELAY);
	if (fd < 0)
	{
		printf("open(%s) failed.", path);    
		return -1;
	}
	free(path);
	writeMMap(fd,addr,off,byte);
	close(fd);
	return 0;
}