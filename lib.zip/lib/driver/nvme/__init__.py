import platform

if 'Linux' in platform.platform():
    from lib.driver.nvme.ioctl import IOCTL, IO, ADMIN, PIOCTL
    from lib.driver.nvme.nvme import NVMe, CNEX, Raven, Tahoe, R5TEST, CYTEST, VUBMI
    from lib.driver.nvme.traffic import LBAOperate
    from lib.driver.nvme.sgl import SGL
    from lib.driver.nvme.ptraffic import PnvmeOperate

    __all__ = ['NVMe', 'CNEX', 'Raven', 'R5TEST', 'Tahoe', 'CYTEST', 'VUBMI', 'ADMIN', 'IO', 'IOCTL',
               'LBAOperate', 'PIOCTL', 'SGL', 'PnvmeOperate']
