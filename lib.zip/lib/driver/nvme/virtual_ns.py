#!/usr/bin/python
# coding=utf-8
"""
Class of Mult NS operation
"""
import logging
from nose.tools import assert_equal

from lib.driver.nvme import NVMe

LOG = logging.getLogger()


class NSOperate:

    def __init__(self, dev=None, max_ns=8, max_sz=128):
        self.max_ns = max_ns
        self.max_sz = max_sz * 1000 * 1000 * 1000 / 1024 / 4
        #  self.ns_list = list()
        self.dev = dev if dev else NVMe()
        self.id_ctrl = self.dev.identify_ctrl()
        self.control_id = self.id_ctrl.CNTLID
        self.controller_list = []
        self.controller_list.append(self.control_id)
        self.orig_ns_list = self.get_current_namespace_list()
        self.lbaf = None

    def get_namespace_pro(self, ns_id):
        id_ns = self.dev.identify_ns(ns_id)
        capacity = id_ns.NCAP
        self.lbaf = id_ns.LBAF
        return {'cap': capacity, 'lbaf': id_ns.FLBAS, 'size': id_ns.NSIZE}

    def get_max_sz(self, ns_list):
        max_sz = 0
        for i in ns_list:
            if self.lbaf[i['lbaf']].LBADS == 12:
                max_sz += i['cap'] * 8
            else:
                max_sz += i['cap']
        return max_sz

    @staticmethod
    def cap_align(cap, step=0x40000):
        return int(cap / step) * step

    def get_recreate_ns_pro(self, ns_num, lbaf):
        max_sz = self.get_max_sz(self.orig_ns_list)
        # print("Max namespace sz: %x"%max_sz)
        ns_cap = max_sz / ns_num
        if self.lbaf[lbaf].LBADS == 12:
            return self.cap_align(ns_cap / 8)
        return self.cap_align(ns_cap)

    def get_current_namespace_list(self):
        id_class = self.dev.identify_allocated_ns_list()
        namespace_list = []
        nlist = id_class
        for idx, ns_id in enumerate(nlist.ID):
            if ns_id != 0x0:
                cap = self.get_namespace_pro(ns_id)
                LOG.info("namespace id: %d is 0x%x, size: 0x%x, cap: 0x%x, lbaf: 0x%x",
                         idx, ns_id, cap['size'], cap['cap'], cap['lbaf'])
                namespace = {"id": ns_id}
                namespace.update(cap)
                namespace_list.append(namespace)
        return namespace_list

    def create_orig_namespace(self):
        for namespace in self.orig_ns_list:
            _, ret = self.dev.create_ns(namespace["size"], namespace["cap"], namespace["lbaf"])
            self.dev.attach_ns(self.controller_list, ret)
            LOG.info("create_orig_namespace: ns id:{}, cap:0x{:x}".format(ret, namespace["cap"]))

    def delete_orig_namespace(self):
        for namespace in self.orig_ns_list:
            # self.dev.detach_ns(self.controller_list, namespace["id"])
            self.dev.delete_ns(namespace["id"])
            LOG.info("delete_orig_namespace: ns id:{}, cap:0x{:x}".format(
                namespace["id"], namespace["cap"]))

    def delete_generate_namespace(self):
        ns_list = self.get_current_namespace_list()
        # print(self.controller_list)
        # print(ns_list)
        for namespace in ns_list:
            # self.dev.namespace_detach(namespace['id'], self.controller_list)
            self.dev.delete_ns(namespace['id'])
            LOG.info("delete_generate_namespace: ns id:%s", namespace['id'])


class NameSpaceOperate:

    def __init__(self, dev=None):
        if dev is None:
            self.dev = NVMe()
        else:
            self.dev = dev
        self.controller_num = None
        self.controller_list = list()
        self.lbaf_list = list()
        self.support_lbaf_list = list()
        self.get_controller_list()
        self.get_dev_support_lbaf_list()
        self.orig_ns_list = self.get_current_namespace_list()

    def get_controller_list(self):
        dev_ctrllist = self.dev.identify(0, 0x13, 0)[1]
        self.controller_num = int(dev_ctrllist.NUM)
        for i in range(self.controller_num):
            self.controller_list.append(dev_ctrllist.ID[i])

    def get_dev_support_lbaf_list(self):
        idn_ns = self.dev.identify(1, 0, 0)[1]
        for i in range(16):
            lba_size = 2**idn_ns.LBAF[i].LBADS
            meta_size = idn_ns.LBAF[i].MS
            flbas = i if meta_size == 0 else i|0b10000
            lbaf = {"LBAF":flbas, "lba_size":lba_size, "meta_size":meta_size}
            if lbaf["lba_size"] >= 512:
                self.support_lbaf_list.append(lbaf)
            self.lbaf_list.append(lbaf)

    def get_current_namespace_list(self):
        namespace_list = list()
        dev_nslist = self.dev.identify(0, 0x10, 0)[1]
        for _, ns_id in enumerate(dev_nslist.ID):
            if ns_id != 0x0:
                idn_ns = self.dev.identify(ns_id)[1]
                ns = {"id":ns_id, "NSIZE":idn_ns.NSIZE, "NCAP":idn_ns.NCAP, "FLBAS":idn_ns.FLBAS, "DPS":idn_ns.DPS, "NMIC":idn_ns.NMIC}
                idn_ctrl = self.dev.identify(ns_id, 1)[1]
                ns.update({"cntid": [idn_ctrl.CNTLID]})
                namespace_list.append(ns)
                LOG.info("get current namespace: %s", ns)
        return namespace_list

    def delete_orig_namespace_once(self):
        ret, _ = self.dev.delete_ns(nsid=0xffffffff)
        assert_equal(ret & 0xff, 0x0, msg='delete namespace failed')
        LOG.info("delete orig namespace: nsid: %d", 0xffffffff)

    def create_4k_size_namespace(self, reset=False, attach=True):
        LOG.info("create 4k namespace")
        nsze = 4096
        _, nsid = self.dev.create_ns(nsze=nsze, ncap=nsze, flbas=0)
        if attach:
            self.dev.attach_ns_without_sleep(self.controller_list, nsid, reset=reset)

    def create_orig_namespace(self, reset=True):
        LOG.info("create orig namespace")
        idn_ctrl = self.dev.identify_ctrl()
        lbads = self.support_lbaf_list[0]["lba_size"]
        nsze = int(idn_ctrl.TNVMCAP.value / lbads)
        _, nsid = self.dev.create_ns(nsze=nsze, ncap=nsze, flbas=self.support_lbaf_list[0]["LBAF"], nmic=1)
        self.dev.attach_ns(self.controller_list, nsid, reset=reset)

    def delete_orig_namespace(self, reset=True):
        for ns in self.orig_ns_list:
            ret = self.dev.detach_ns(ns["cntid"], ns["id"], reset=reset)
            assert_equal(ret & 0xff, 0x0, msg='detach namespace failed')
            ret, _ = self.dev.delete_ns(ns["id"])
            assert_equal(ret & 0xff, 0x0, msg='delete namespace failed')
            LOG.info("delete orig namespace: nsid: %d", ns["id"])

    def delete_generate_namespace(self):
        generate_ns_list = self.get_current_namespace_list()
        for ns in generate_ns_list:
            ret, _ = self.dev.delete_ns(ns["id"])
            assert_equal(ret & 0xff, 0x0, msg='delete namespace failed')
            LOG.info("delete generate namespace: nsid: %d", ns["id"])
