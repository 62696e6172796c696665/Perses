import logging
import random
import threading
import time
from ctypes import c_uint64, c_uint32

from nose.tools import assert_equal, assert_in

from lib.driver.nvme import Raven
from lib.driver.nvme.struct.command import LVMTenantID, LVMTrackIOEntry, DatasetManagementEntry
from lib.driver.nvme.struct.command import LiveMigrationSQE, OPCODE, LVMOPCODE, NVMePassthruCmd
from lib.driver.utils.buf import Malloc

LOG = logging.getLogger()


class TrackIO:
    WRITE = 0
    WRITE_ZERO = 2
    TRIM = 1
    READ = 3


class LiveMigration:

    def __init__(self, cntid=0, nsid=1, mvf_nsid=1, io_tenant_id=LVMTenantID.LVM_IO, mem_tenant_id=LVMTenantID.LVM_MWR):
        self.hbm_lock = threading.RLock()
        self.io_tenant_id = io_tenant_id
        self.mem_tenant_id = mem_tenant_id
        self.mvf_nsid = mvf_nsid
        self.cntid = cntid
        self.raven = Raven(cntid=cntid, nsid=nsid)
        self.max_entry_numbers = 255 * 512

    def gen_sqe(self, controller_id, function_code, head_point=0, tail_point=0, prp_list=0, npages=255):
        cmd = LiveMigrationSQE()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_SUM
        cmd.SUB_OPCODE = OPCODE.KNUCKLE_VU_SUB_LVM
        cmd.CNTID = controller_id
        cmd.NPAGES = npages
        cmd.BK_HEAD = head_point
        # cmd.HEAD = head_point
        # cmd.TAIL = tail_point
        # cmd.PRP = prp_list
        cmd.CDW10_OPCODE = function_code
        return cmd

    def set_io_prp0_layout(self, tid):
        nprps = 254  # it is 0 base
        status, prp_addr_buf = self.raven.hmb_get_prp_list(tid, start_prp=1, nprps=nprps)
        if status == 0:
            dwd_offset = 2
            num_dwd = (nprps + 1) * 8 / 2 - 1  # one page is 8B, this is 0 base
            self.write_prp_to_hmb(prp_addr_buf, num_dwd=num_dwd, tid=tid, dwd_offset=dwd_offset, nsid=1)
            self._read_prp0_hmb(tid)
        return status

    def get_io_points(self, tid):
        with self.hbm_lock:
            _, prp_addr_buf = self.raven.hmb_get_prp_list(teneat_id=tid, start_prp=0, nprps=1)
        head_point = prp_addr_buf[0]
        tail_point = prp_addr_buf[0] + 4
        prp_point = prp_addr_buf[0] + 8
        LOG.info("head_point: %#x, tail_point:%#x, prp_point:%#x", head_point, tail_point, prp_point)
        return head_point, tail_point, prp_point

    def write_prp_to_hmb(self, prp, num_dwd, tid, dwd_offset=0, nsid=1):
        try:
            self.raven.hmb_write(prp.address, nsid, numd=int(num_dwd), ofsd=dwd_offset, tid=tid)
        except (AssertionError, AttributeError):
            pass

    def _read_prp0_hmb(self, tid):
        read_buffer = Malloc(512, c_uint64)
        try:
            self.raven.hmb_read(read_buffer.address, 1, 1024, 0, tid=tid)
        except (AssertionError, AttributeError):
            pass
        return read_buffer

    def start_track(self, controller_id, opcode, tenant_id):
        status = self.set_io_prp0_layout(tenant_id)
        if status == 0:
            head_point, tail_point, prp_point = self.get_io_points(tenant_id)
            self.clear_tail_head(self.mvf_nsid, tenant_id)
            cmd = self.gen_sqe(controller_id, opcode, head_point, tail_point, prp_point)
            self.raven.admin_passthru(cmd)
        else:
            LOG.info("get prp list failed, state: %s", status)

    def start_track_io(self, controller_id):
        try:
            self.start_track(controller_id, LVMOPCODE.START_TRACK_IO, self.io_tenant_id)
        except (AssertionError, AttributeError, IOError):
            pass

    def start_track_mem_wr(self, controller_id):
        try:
            self.start_track(controller_id, LVMOPCODE.START_TRACK_MEM, self.mem_tenant_id)
        except (AssertionError, AttributeError, IOError):
            pass

    def get_io_track_entry(self, entry, index, numbers_of_entry=1, ns_id=1):
        """
        Entry size is 8 Bytes, 2 dwd
        Entry start from prp1, prp0(4kiB) is prp address list, so dwd offset start from 1024
        :param index: entry index
        :param ns_id:
        :param numbers_of_entry, one entry is 8 byte = 2 dwd
        :return:
        """

        if (index + numbers_of_entry) >= self.max_entry_numbers:
            print("Get entry is need max_entry_numbers ", index, numbers_of_entry)
            length = self.max_entry_numbers - index
            dwd_offset = 1024 + index * 2
            print("read step 1 ", entry.address, length, dwd_offset)
            self.raven.hmb_read(entry.address, ns_id, 2 * length, dwd_offset, tid=self.io_tenant_id)
            left_length = numbers_of_entry - length
            dwd_offset = 1024
            buf_addr = entry.address + 8 * length
            print("read step 1 ", buf_addr, left_length, dwd_offset)
            self.raven.hmb_read(buf_addr, ns_id, 2 * left_length, dwd_offset, tid=self.io_tenant_id)
        else:
            dwd_offset = 1024 + index * 2
            self.raven.hmb_read(entry.address, ns_id, 2 * numbers_of_entry, dwd_offset, tid=self.io_tenant_id)

    def get_men_track_entry(self, entry, index, numbers_of_entry=1, ns_id=1):
        """
        Entry size is 8 Bytes, 2 dwd
        Entry start from prp1, prp0(4kiB) is prp address list, so dwd offset start from 1024
        :param index: entry index
        :param ns_id:
        :param numbers_of_entry, one entry is 8 byte = 2 dwd
        :return:
        """
        dwd_offset = 1024 + index * 2
        self.raven.hmb_read(entry.address, ns_id, 2 * numbers_of_entry, dwd_offset, tid=self.mem_tenant_id)

    def stop_track(self, controller_id):
        try:
            cmd = self.gen_sqe(controller_id, function_code=LVMOPCODE.STOP_TRACK)
            self.raven.admin_passthru(cmd)
        except (AssertionError, AttributeError, IOError):
            pass

    def stop_memwr(self, controller_id):
        try:
            cmd = self.gen_sqe(controller_id, function_code=LVMOPCODE.STOP_MWR)
            self.raven.admin_passthru(cmd)
        except (AssertionError, AttributeError, IOError):
            pass

    def read_bhp_btp(self, tid):
        read_buffer = Malloc(2, c_uint32)
        self.raven.hmb_read(read_buffer.address, 1, 2, 0, tid=tid)
        bhp = read_buffer[0]
        btp = read_buffer[1]
        return bhp, btp

    def read_io_bhp_btp(self):
        return self.read_bhp_btp(self.io_tenant_id)

    def read_mem_bhp_btp(self):
        return self.read_bhp_btp(self.mem_tenant_id)

    def set_bhp(self, value, nsid, tid):
        prp = Malloc(1, c_uint32)
        prp.set_uint32(0, value)
        state = self.raven.hmb_write(prp.address, nsid, 1, tid=tid)
        return state

    def set_btp(self, value, nsid, tid):
        prp = Malloc(1, c_uint32)
        prp.set_uint32(0, value)
        state = self.raven.hmb_write(prp.address, nsid, 1, ofsd=1, tid=tid)
        return state

    def clear_tail_head(self, nsid, tid):
        prp = Malloc(2, c_uint32)
        state = self.raven.hmb_write(prp.address, nsid, 2, tid=tid)
        return state

    def get_queue_state(self, cn_id, sq_id, cq_id):
        data = Malloc(4, c_uint32)
        cmd_sqe = NVMePassthruCmd()
        cmd_sqe.OPCODE = OPCODE.KNUCKLE_VU_RD
        cmd_sqe.CDW15 = OPCODE.KNUCKLE_VU_SUB_QUEUE_STATE
        cmd_sqe.NSID = cn_id
        cmd_sqe.CDW10 = sq_id + (cq_id << 16)
        cmd_sqe.DATA = data.address
        cmd_sqe.DATA_LEN = 16
        self.raven.admin_passthru(cmd_sqe)
        data.dump()
        sqt = data[0]
        cqt = data[1]
        cqh = data[2]
        return sqt, cqt, cqh

    def send_write(self, traffic, lba, nlb):
        traffic.write_sync(lba, nlb, mode=0, pattern=0xff, printf=False)

    def send_write_zero(self, traffic, lba, nlb):
        traffic.write_zeroes(lba, nlb, printf=False)

    def send_trim(self, traffic, slba, nlb, n_range):
        ret = traffic.dataset(range_num=n_range, slba=slba, range_length=nlb)
        return ret

    def send_read(self, traffic, lba, nlb):
        print("Before read")
        traffic.read_sync(lba, nlb, compare=False)
        print("after read")

    def send_command(self, traffic, command):
        print("Send command", command)
        if command[-1] == TrackIO.WRITE:
            self.send_write(traffic, command[0], command[1])
        elif command[-1] == TrackIO.WRITE_ZERO:
            self.send_write_zero(traffic, command[0], command[1])
        elif command[-1] == TrackIO.READ:
            self.send_read(traffic, command[0], command[1])
        elif command[-1] == TrackIO.TRIM:
            self.send_trim(traffic, command[0], command[1], command[2])
            time.sleep(1)

    def compare_command_entry(self, command, io_bhp, io_btp, mem_bhp, men_btp):
        _, new_io_btp = self.read_bhp_btp(self.io_tenant_id)
        _, new_mem_btp = self.read_bhp_btp(self.mem_tenant_id)
        print("Before send command, io_btp, men_btp", io_btp, men_btp)
        print("After send command, io_btp, men_btp:", new_io_btp, new_mem_btp)
        if command[-1] in [TrackIO.WRITE, TrackIO.WRITE_ZERO]:
            self.compare_tail_value(io_btp, (io_btp + 1) % self.max_entry_numbers, self.io_tenant_id)
            self.compare_write_entry(new_io_btp, command)
        elif command[-1] == TrackIO.READ:
            expects = [(men_btp + command[1]) % self.max_entry_numbers,
                       (men_btp + command[1] + 1) % self.max_entry_numbers]
            self.compare_tail_value(men_btp, expects, self.mem_tenant_id)
            self.comapre_read_entry(new_mem_btp, command)
        elif command[-1] == TrackIO.TRIM:
            expect_btp = (io_btp + 1 + command[2] * 2) % self.max_entry_numbers
            self.compare_tail_value(io_btp, expect_btp, self.io_tenant_id)
            trim_buffer = self.get_trim_buffer(command[2], command[0], command[1])
            self.compare_trim_entry((io_btp + 1) % self.max_entry_numbers, command, trim_buffer)

    def wait_trim_entry_update_finished(self, expect_tail):
        start_time = time.time()
        current_time = start_time
        wait_state = "wait trim entry update finished: timeout 5s"
        _, new_io_btp = self.read_bhp_btp(self.io_tenant_id)
        while (current_time - start_time) < 5:
            if expect_tail > new_io_btp:
                time.sleep(1)
            else:
                wait_state = "wait trim entry update finished"
                break
            current_time = time.time()
            _, new_io_btp = self.read_bhp_btp(self.io_tenant_id)
        print("LVM", self.cntid, self.cntid, wait_state)

    def compare_tail_value(self, last_tail, expect_tail, tid):
        new_btp = self.wait_tail_changed(last_tail, tid)
        if isinstance(expect_tail, list) is True:
            assert_in(new_btp, expect_tail, msg="Read command: before :{}, after:{}".format(expect_tail, new_btp))
        else:
            assert_equal(new_btp, expect_tail, msg="IO command, expect btp:{}, after:{}".format(expect_tail, new_btp))

    def wait_tail_changed(self, btp, tid):
        """
        Tail changed mean command log succeed, then we can compare command entry
        :return:
        """
        start_time = time.time()
        current_time = start_time
        wait_state = "wait_tail_changed: timeout 30s"
        _, new_btp = self.read_bhp_btp(tid)
        while (current_time - start_time) < 30:
            if btp == new_btp:
                time.sleep(1)
                current_time = time.time()
            else:
                wait_state = "wait_tail_changed: tail changed"
                break
            _, new_btp = self.read_bhp_btp(tid)
        print("LVM controller id:", self.cntid, wait_state)
        return new_btp

    def compare_command_entry_without_tail_point(self, command, io_bhp, io_btp, mem_bhp, men_btp):
        if command[-1] in [TrackIO.WRITE, TrackIO.WRITE_ZERO]:
            self.wait_tail_changed(io_btp, self.io_tenant_id)
            self.compare_write_entry(io_btp + 1, command)
        elif command[-1] == TrackIO.READ:
            self.wait_tail_changed(men_btp, self.mem_tenant_id)
            self.comapre_read_entry(men_btp + 1, command)
        elif command[-1] == TrackIO.TRIM:
            self.wait_tail_changed(io_btp, self.io_tenant_id)
            trim_buffer = self.get_trim_buffer(command[2], command[0], command[1])
            self.compare_trim_entry(io_btp + 1, command, trim_buffer)

    def check_io_command_is_logged(self, io_btp, men_btp):
        start_time = time.time()
        current_time = start_time
        run_time = 30
        while (current_time - start_time) < run_time:
            _, new_io_btp = self.read_bhp_btp(self.io_tenant_id)
            _, new_men_btp = self.read_bhp_btp(self.mem_tenant_id)
            if (io_btp != new_io_btp) or (men_btp != new_men_btp):
                break
            current_time = time.time()
            time.sleep(1)

    def comapre_read_entry(self, index, command):
        print(command)
        entry = Malloc(command[1], c_uint64)
        self.get_men_track_entry(entry, index - command[1] + 1, command[1])
        entry.dump()

    def compare_write_entry(self, index, command):
        entry = Malloc(1, LVMTrackIOEntry)
        self.get_io_track_entry(entry, index % self.max_entry_numbers)
        entry.dump()
        assert_equal(entry[0].TYPE, 0,
                     msg="Entry type failed, get:{}, expect:{}".format(entry[0].TYPE, command[2]))
        assert_equal(entry[0].NLB + 1, command[1],
                     msg="Entry nlb failed, get:{}, expect:{}".format(entry[0].NLB, command[1]))
        assert_equal(entry[0].SLBA_L, command[0],
                     msg="Entry slba failed, get:{}, expect:{}".format(entry[0].SLBA_L, command[0]))
        assert_equal(entry[0].NSID, self.mvf_nsid,
                     msg="Entry nsid failed, get:{}, expect:{}".format(entry[0].NSID, self.mvf_nsid))

    def get_trim_buffer(self, range_num, slba, range_length, mode=0):
        range_buf = Malloc(range_num, DatasetManagementEntry)
        for i in range(range_num):
            _slba = slba + i * range_length
            if (mode == 1) & (i % 2 == 1):
                nlb = range_length + 1
            else:
                nlb = range_length
            range_buf[i].SLBA = _slba
            range_buf[i].LENGTH = nlb
        return range_buf

    def compare_trim_entry(self, entry_start_index, command, expect_trim_buffer):
        entry = Malloc(1, LVMTrackIOEntry)
        self.get_io_track_entry(entry, entry_start_index)
        assert_equal(entry[0].TYPE, 1, msg="trim entry type is not correct")
        assert_equal(entry[0].NSID, self.mvf_nsid, msg="trim entry nsid is not correct")
        assert_equal(entry[0].NLB, command[2], msg="trim entry nlb  is not correct")
        expect_io_tail = (entry_start_index + command[2] * 2) % self.max_entry_numbers
        self.wait_trim_entry_update_finished(expect_io_tail)
        trim_range = command[2]
        trim_entry = Malloc(trim_range, DatasetManagementEntry)
        self.get_io_track_entry(trim_entry, entry_start_index + 1, trim_range * 2)  # trim entry is 16byte
        ret = trim_entry.compare(expect_trim_buffer, 0, 16 * trim_range, 0, 16 * trim_range)
        if ret != 0:
            print("Trim start entry buffer:")
            entry.dump()
            print("Actual trim entry buffer:")
            trim_entry.dump()
            print("Expect trim entry buffer:")
            expect_trim_buffer.dump()
            print(command)
            assert_equal(ret, 0, msg="trim entry compare failed")

    def get_trim(self, value, trim_range):
        trim_entry = Malloc(trim_range, DatasetManagementEntry)
        self.get_io_track_entry(trim_entry, value + 1, trim_range * 2)  # trim entry is 16byte
        trim_entry.dump()


class TestGenerator:

    def __init__(self):
        pass

    @staticmethod
    def generate_write_command():
        nlb = random.choice([1, 2, 4, 8])
        slba = random.randint(0x0, 0xffffff)
        command = (slba, nlb, TrackIO.WRITE)
        return command

    @staticmethod
    def generate_write_zero_command():
        nlb = random.choice([1, 2, 4, 8])
        slba = random.randint(0x0, 0xffffff)
        command = (slba, nlb, TrackIO.WRITE_ZERO)
        return command

    @staticmethod
    def generate_trim_command():
        nlb = random.choice([1, 2, 4, 8])
        slba = random.randint(0x0, 0xffffff)
        numbers_of_range = random.randint(200, 255)
        command = (slba, nlb, numbers_of_range, TrackIO.TRIM)
        return command

    @staticmethod
    def generate_read_command():
        nlb = random.choice([1, 2, 4, 8])
        slba = random.randint(0x0, 0xffffff)
        command = (slba, nlb, TrackIO.READ)
        return command

    def random_generate_one_command(self):
        test_type = random.choice([TrackIO.READ, TrackIO.WRITE_ZERO, TrackIO.WRITE, TrackIO.TRIM])
        if test_type == TrackIO.READ:
            command = self.generate_read_command()
        elif test_type == TrackIO.WRITE:
            command = self.generate_write_command()
        elif test_type == TrackIO.WRITE_ZERO:
            command = self.generate_write_zero_command()
        elif test_type == TrackIO.TRIM:
            command = self.generate_trim_command()
        else:
            command = self.generate_write_command()
        return command

    def get_full_type_command_list(self):
        command_list = list()
        command_list.append(self.generate_read_command())
        command_list.append(self.generate_write_command())
        command_list.append(self.generate_write_zero_command())
        command_list.append(self.generate_trim_command())
        return command_list
