#!/usr/bin/env python
# pylint: disable=too-many-locals,too-many-arguments,superfluous-parens,import-error,invalid-name,arguments-differ
"""
Created on 2019/4/26

@author: yyang
"""
import math
from ctypes import *

from lib.driver.nvme.struct import *
from lib.driver.utils.buf import *
from lib.driver.utils.ctype import Byte

LOG = logging.getLogger()


class VUProjectType:

    def __init__(self):
        pass

    @classmethod
    def from_name(cls, name):
        """
            Return the class which matches ``name`` if it exists inside this
            module or raise an exception.
        """
        if name not in globals():
            raise NotImplementedError('Project of type %s is not supported' % name)
        return globals()[name]


class TahoeVU(VUProjectType):
    def __init__(self, dev):
        super().__init__()
        self.dev = dev
        LOG.debug("Tahoe VU class init!")

    def get_ftl_cache_info(self):
        # dptr = (c_uint32 * 15)()
        dptr = CasheStruct()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xc0
        cmd.CDW[10] = 0x20002071
        cmd.CDW[11] = 15
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        return self.dev.admin_passthru(cmd), dptr

    def get_ftl_sub_entry_info(self, sub_idx: int, sub_cnt: int):
        assert sub_idx <= 0xffff, "sub_idx out of range"
        assert sub_cnt in range(1, 86), "sub_cnt out of range"
        dptr = SubindexStruct()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xc0
        cmd.CDW[10] = 0x20002070
        cmd.CDW[11] = sub_cnt * 12
        cmd.CDW[12] = sub_idx
        cmd.CDW[13] = sub_cnt
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        return self.dev.admin_passthru(cmd), dptr

    def device_self_test_error(self, insert=1, segment=1):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x1000000d
        cmd.CDW[11] = 0
        cmd.CDW[12] = int(insert)
        cmd.CDW[13] = int(segment)
        cmd.CDW[14] = 0
        return self.dev.admin_passthru(cmd)

    def trigger_format_progress(self, switch=0):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x1000000f
        cmd.CDW[11] = 0
        cmd.CDW[12] = int(switch)
        cmd.CDW[13] = 0
        cmd.CDW[14] = 0
        return self.dev.admin_passthru(cmd)

    def trigger_format_progress_clear_after_reset(self, switch=1):
        """
        clear after reset
        """
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000087
        cmd.CDW[11] = 0
        cmd.CDW[12] = int(switch)
        cmd.CDW[13] = 0
        cmd.CDW[14] = 0
        return self.dev.admin_passthru(cmd)

    def set_compsite_temp(self, val=0xffffffff):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000023
        cmd.CDW[11] = 0
        cmd.CDW[12] = int(val)
        cmd.CDW[13] = 0
        LOG.info("Set throttle temperature with value %d by VU command successfully.", val)
        return self.dev.admin_passthru(cmd)

    def show_test_case(self, show_string, *args, **kwargs):
        """Show test case in UART log
        Domain      DW10       DW11       DW12   DW13    DW14  DW15   DW0(CQE)
        | Media  |  0x10001007  |  1024 |  None |  None  | None | None| None

        This is VU command for showing test case in UART log
        Raises:
           send VU cmd fail
        """
        buf = NVMeMalloc(512, stream=show_string)

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC1
        cmd.CDW[10] = 0x10001007
        cmd.CDW[11] = 1024
        cmd.DATA = buf.address
        cmd.DATA_LEN = buf.size
        return self.dev.admin_passthru(cmd, *args, **kwargs)

    def get_power_consumption(self, length=64):
        """get_async_event_info

            Domain         DW10       DW11         DW12               DW13    DW14   DW15  DW0(CQE)
        |Host/Platform| 0x10002028  | 4    |        None            | None  | None  | None| None

        Returns:
            power consumption data: Word0: Voltage, Word1: Current
        """
        dptr = TahoeVUPower()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10002028
        cmd.CDW[11] = length
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        vol = dptr.pw_int
        cur = dptr.pw_float
        ret = float(str(vol) + '.' + str(cur))
        # LOG.info("Get Power Consumption syccessfully[int: %x, float: %x].", vol, cur)
        LOG.info("Get Power Consumption syccessfully[Power: %f].", ret)
        LOG.info("Get Power Consumption syccessfully[Credit: max:%d, min:%d, avg:%d].",
                 dptr.max_credit, dptr.min_credit, dptr.avg_credit)
        return ret, dptr.max_credit, dptr.min_credit, dptr.avg_credit

    def get_memory(self, addr, length=1, cpu=0):
        dptr = (c_uint32 * length)()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10002005
        cmd.CDW[11] = length
        cmd.CDW[12] = cpu
        cmd.CDW[13] = addr
        cmd.CDW[14] = length * 4
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return dptr

    def set_memory(self, addr, dptr, length=0, cpu=0):
        length = length if length else sizeof(dptr) // 4
        buf = NVMeMalloc(length=sizeof(dptr), stream=dptr)

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC1
        cmd.CDW[10] = 0x10001006
        cmd.CDW[11] = length
        cmd.CDW[12] = cpu
        cmd.CDW[13] = addr
        cmd.CDW[14] = length * 4
        cmd.DATA = buf.address
        cmd.DATA_LEN = buf.size
        return self.dev.admin_passthru(cmd)

    def get_idle_state(self):

        # dptr = (c_uint16 * (length//2))()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10002042
        cmd.CDW[11] = 1
        # cmd.DATA = addressof(dptr)
        # cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return cmd.RESULT

    def force_gc(self, blk):

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x2000000C
        cmd.CDW[12] = blk

        return self.dev.admin_passthru(cmd)

    def enable_disable_gc(self, flag):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x2000000D
        cmd.CDW[12] = flag

        return self.dev.admin_passthru(cmd)

    def get_free_block_count(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = 1024
        cmd.CDW[12] = 0x8
        status = self.dev.admin_passthru(cmd)
        return status, cmd.RESULT

    def force_erase(self, blk):

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20000013
        cmd.CDW[12] = blk
        return self.dev.admin_passthru(cmd)

    def get_bmi_entry(self, blk):
        dptr = TahoeBMIEntry()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = 32
        cmd.CDW[12] = 1
        cmd.CDW[13] = blk

        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return dptr

    def get_device_config(self):
        dptr = TahoeDeviceConfig()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = 8
        cmd.CDW[12] = 0xe

        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return dptr

    def get_bmi_list(self, blk):
        dptr = (TahoeBMIEntry * blk)()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x30002011
        cmd.CDW[11] = blk * 128 // 4

        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return dptr

    def write_bmi_entry_badb_field(self, blk, bmi_list):
        dptr = bmi_list
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC1
        cmd.CDW[10] = 0x20001003
        cmd.CDW[11] = 32
        cmd.CDW[12] = 0x8
        cmd.CDW[13] = blk

        cmd.DATA = addressof(dptr) + blk * 128
        cmd.DATA_LEN = 512

        # Ctype(cmd).dump()
        # Ctype(dptr[blk]).dump()

        self.dev.admin_passthru(cmd)

    def read_nor(self, addr, size):
        size = math.ceil(size / 4096) * 4096
        dptr = Malloc(size, c_uint8)

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10002037

        for offset in range(0, size, 4096):
            cmd.CDW[11] = 4096 // 4
            cmd.CDW[12] = addr + offset
            cmd.CDW[13] = 4096

            cmd.DATA = dptr.address + offset
            cmd.DATA_LEN = 4096

            # Ctype(cmd).dump()
            self.dev.admin_passthru(cmd)

        return dptr

    def erase_nor(self, addr, size):
        size = math.ceil(size / 4096) * 4096
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000035
        cmd.CDW[12] = addr
        cmd.CDW[13] = size
        cmd.CDW[14] = 0
        cmd.CDW[15] = 0

        self.dev.admin_passthru(cmd)

    def write_nor(self, addr, size, dptr):
        size = math.ceil(size / 4) * 4
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC1
        cmd.CDW[10] = 0x10001036
        cmd.CDW[11] = size // 4
        cmd.CDW[12] = addr
        cmd.CDW[13] = size
        cmd.CDW[14] = 0
        cmd.CDW[15] = 0

        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        self.dev.admin_passthru(cmd)

    def adjust_nor_bb_addr(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000038
        cmd.CDW[11] = 0
        cmd.CDW[12] = 0

        self.dev.admin_passthru(cmd)

    def force_flush(self, task="host", ftype="block"):
        cmd = NVMePassthruCmd()
        assert task in ["host", "gc", "ftl"], "task type not support!"
        assert ftype in ["raidline", "block", "pu", "pad", "wordline"], \
            "task type not support!"
        if task == "host":
            cmd.CDW[12] = 0
        elif task == "gc":
            cmd.CDW[12] = 1
        elif task == "ftl":
            cmd.CDW[12] = 2

        if ftype == "raidline":
            cmd.CDW[13] = 0
        elif ftype == "block":
            cmd.CDW[13] = 1
        elif ftype == "pu":
            cmd.CDW[13] = 2
        elif ftype == "pad":
            cmd.CDW[13] = 3
        elif ftype == "wordline":
            cmd.CDW[13] = 4
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20000011

        LOG.info('Send force flush, task: %s, type: %s', task, ftype)
        return self.dev.admin_passthru(cmd)

    def get_ppa_from_lba(self, lba, nsid=None):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = self.dev.nsid if nsid is None else nsid
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = 6
        cmd.CDW[12] = 0
        cmd.CDW[14] = lba & 0xFFFFFFFF
        cmd.CDW[15] = (lba >> 32) & 0xFFFFFFFF
        dptr = PPAEntry()
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return cmd.RESULT, dptr

    def get_ppa_from_lba64(self, lba, nsid=None):
        cmd = NVMePassthruCmd64()
        cmd.OPCODE = 0xC0
        cmd.NSID = self.dev.nsid if nsid is None else nsid
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = 6
        cmd.CDW[12] = 0
        cmd.CDW[14] = lba & 0xFFFFFFFF
        cmd.CDW[15] = (lba >> 32) & 0xFFFFFFFF
        dptr = PPAEntry()
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru64(cmd)
        return cmd.RESULT, dptr

    def read_ppa(self, ppa, nsid=None):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = self.dev.nsid if nsid is None else nsid
        cmd.CDW[10] = 0x20002006
        cmd.CDW[11] = 1024
        cmd.CDW[12] = ppa
        dptr = (c_uint8 * 4096)()
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)

    def check_ppa_to_lba_valid(self, ppa, nsid=None):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = self.dev.nsid if nsid is None else nsid
        cmd.CDW[10] = 0x20002067
        cmd.CDW[11] = 12
        cmd.CDW[12] = ppa
        dptr = (c_uint32 * 1024)()
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        lba = dptr[1] + (dptr[2] << 32)
        return dptr[0], lba

    def get_int_type(self):
        """Get INT type
        Domain      DW10          DW11    DW12    DW13    DW14  DW15   DW0(CQE)
        | Media  |  0x10002034   |  4   |  None |  None  | None | None |  None

        Returns:
            INT type:INT0/INT1 or INT2
        Raises:
            send VU cmd fail
        """
        dptr = (c_uint8 * 32)()
        cmd = NVMePassthruCmd()
        dw10 = 0x10002034
        cmd.CDW[10] = dw10
        cmd.CDW[11] = 4
        cmd.OPCODE = 0xC0
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        tmp = map(chr, dptr[0:17])
        int_type = ''
        for char in tmp:
            if char == '\x00':
                break
            int_type += char
        return int_type

    def get_drive_life_cycle_state(self):
        """ get drive life cycle state
        Domain      DW10          DW11    DW12    DW13    DW14  DW15   DW0(CQE)
        | Media  |  0x10002045   |  2   |  None |  None  | None | None |  None

        Returns:
            Data saved in Nor
        Raises:
            send VU cmd fail
        """
        dptr = (c_uint32 * 2)()
        cmd = NVMePassthruCmd()
        cmd.CDW[10] = 0x10002045
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.OPCODE = 0xC0
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return dptr[1]

    def get_drive_version_info(self):
        """ get FW version info(corresponding to UART output)
        Domain      DW10          DW11    DW12    DW13    DW14  DW15   DW0(CQE)
        | Media  |  0x1000204e   |  0x200   |  None |  None  | None | None |  None

        Returns:
            Returns the output from a UART 'VER" command in ASCII
        Raises:
            send VU cmd fail
        """
        dptr = (Byte * 0x800)()
        cmd = NVMePassthruCmd()
        cmd.CDW[10] = 0x1000204e
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.OPCODE = 0xC0
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return dptr

    def get_cmd_cnt_per_queue(self, qid=1):
        """get_cmd_cnt_per_queue

            Domain         DW10       DW11    DW12   DW13    DW14   DW15  DW0(CQE)
        |Host/Platform| 0x10000043    | 0x0 |  qid |     None | None | None| None

        This is VU command for get command counter per queu

        Returns:
            cqe dw0: command counter per Queue
        """
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000043
        cmd.CDW[12] = qid
        # cmd.DATA = addressof(dptr)
        # cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        LOG.info("get_cmd_cnt_per_queue[q:%d, number:%d] successfully.", qid, cmd.RESULT)
        return cmd.RESULT

    def set_crecit(self, val):
        cmd = NVMePassthruCmd()
        # cmd.OPCODE = 0xC0
        # cmd.CDW[10] = 0x10000046
        # cmd.CDW[11] = 0
        # cmd.CDW[12] = int(val)
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000066
        cmd.CDW[11] = 0
        cmd.CDW[12] = 0
        cmd.CDW[13] = int(val)
        return self.dev.admin_passthru(cmd)

    def get_drive_security_state(self):
        """this function is getting drive security state  (ISE/SED/TCG not enable)

                Domain         DW10        DW11       DW12    DW13    DW14  DW15   DW0(CQE)
               | Generic   |  0x1000204f  |  0x04  |  0    |   0    |   0| None

               This is VU command for getting drive security state

               Returns:
                   Returns TCG State:
                    byte 0 - 1: return data length (big-endian)
                    byte 2: 0 = SED, 1 = ISE
                    byte 3: 1 = TCG is finalized
               Raises:
                   send VU cmd fail
               """
        cmd = NVMePassthruCmd()
        dw10 = 0x1000204f
        dptr = (c_uint8 * 4096)()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = dw10
        cmd.CDW[11] = 0x04
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.dev.admin_passthru(cmd)
        return dptr

    def set_sb_read_count(self, blk, read_count):
        """Set read count to super block
        Domain      DW10          DW11  DW12    DW13   DW14    DW15   DW0(CQE)
       | Media  |  0x20000003  |  0  |  12  |  blk  | None | read_count | None

       This is VU command for setting program fail in ppa
       Args:
           ppa
       Returns:
           None
       Raises:
           send VU cmd fail
       """
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20000003
        cmd.CDW[11] = 0
        cmd.CDW[12] = 12
        cmd.CDW[13] = blk
        cmd.CDW[15] = read_count
        return self.dev.admin_passthru(cmd)

    def set_queue_number(self, sqid, cqid):
        """Set queue number
        Domain      DW10          DW11    DW12    DW13   DW14    DW15   DW0(CQE)
       | Media  |  0x10000066  |  0  |  cqid/sqid  |  0  | 0    |    0 | None
       Args:
           ppa
       Returns:
           None
       Raises:
           send VU cmd fail
       """
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000066
        cmd.CDW[11] = 0
        cmd.CDW[12] = (cqid << 16) + sqid
        return self.dev.admin_passthru(cmd)

    def fw_qb_switch(self, on=1):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000072
        cmd.CDW[12] = on
        return self.dev.admin_passthru(cmd)

    def fw_ab_cnt(self, is_clear=1):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000071
        cmd.CDW[12] = is_clear
        return self.dev.admin_passthru(cmd)

    def fake_assert(self, core_id=0, assert_id=1):
        """
        Set pause in firmware active stage
        Domain      DW10       DW11    DW12     DW13    DW14   DW15   DW0(CQE)
        |Media  |  0x1000003d|  None |  1   |  None  | None | None  | None
        DW12: 1 : assert id: 1 for assert abort; 2 for assert fatal; 0xFF for assert fatal with warm reset
        DW13: Core ID (M30: 0, R5A: 2)
        # DW14: Quiesce state (0: Quiesce Down, 1: Quiesce Recover)
        # DW15: Trap Stage
        """
        cmd = NVMePassthruCmd()
        dw10 = 0x1000003d
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = dw10
        cmd.CDW[11] = 0
        cmd.CDW[12] = assert_id
        cmd.CDW[13] = core_id
        cmd.CDW[14] = 0
        cmd.CDW[15] = 0
        LOG.info("Send Assert Cmd [assert id:%d, core id:%d]", assert_id, core_id)
        return self.dev.admin_passthru(cmd)

    def clearspi(self, spi_id=1, spi_sub_id=0):
        """
        Set pause in firmware active stage
        Domain      DW10       DW11    DW12     DW13    DW14   DW15   DW0(CQE)
        |Media  |  0x10000020|  None |  1   |  None  | None | None  | None
        DW12: spi_id:
        DW13: spi_sub_id
        """
        cmd = NVMePassthruCmd()
        dw10 = 0x10000020
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = dw10
        cmd.CDW[11] = 0
        cmd.CDW[12] = spi_id
        cmd.CDW[13] = spi_sub_id
        cmd.CDW[14] = 0
        cmd.CDW[15] = 0
        LOG.info("Send clearspi %d %d", spi_id, spi_sub_id)
        return self.dev.admin_passthru(cmd)

    def pcie_reset(self, reset_type=1):
        """
        Set pause in firmware active stage
        Domain      DW10       DW11    DW12     DW13    DW14   DW15   DW0(CQE)
        |Media  |  0x10000021|  None |  1   |  None  | None | None  | None
        DW12: reset_type : crst : 1, wrst : 0
        """
        tp = reset_type & 0x1
        cmd = NVMePassthruCmd()
        dw10 = 0x10000021
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = dw10
        cmd.CDW[11] = 0
        cmd.CDW[12] = tp
        cmd.CDW[13] = 0
        cmd.CDW[14] = 0
        cmd.CDW[15] = 0
        cmd.TIMEOUT = 1
        LOG.info("Send pcie reset type :%d, crst : 1, wrst : 0", tp)
        return self.dev.admin_passthru(cmd, status=0x7)

    def get_user_available_spare(self):
        dptr = (c_uint32 * 0x100)()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10002054
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        return self.dev.admin_passthru(cmd), dptr[0]

    def get_bad_block_info(self):
        dptr = BadBlockInfo()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC2
        cmd.CDW[10] = 0x10002083
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        return self.dev.admin_passthru(cmd), dptr

    def get_capacitor_value(self):
        dptr = (c_uint32 * 128)()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC2
        cmd.CDW[10] = 0x10002084
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        return self.dev.admin_passthru(cmd), dptr[0]

    def get_valid_ppa_in_raidline(self, ppa, nsid=None):
        dptr = (c_uint32 * 1024)()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = self.dev.nsid if nsid is None else nsid
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.CDW[12] = 0x6
        cmd.CDW[15] = ppa
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        LOG.info("Send get raidline of ppa: 0x%x", ppa)
        status = self.dev.admin_passthru(cmd)
        ppa_list = [dptr[i] for i in range(cmd.RESULT)]

        return status, ppa_list

    def skip_lspp(self, enable=False):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20000014
        cmd.CDW[12] = int(enable)

        LOG.info("Send skip lspp: %s", enable)
        return self.dev.admin_passthru(cmd)

    def set_thermal_throttling_temperature(self, temp):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000023
        cmd.CDW[12] = temp

        LOG.info("Send set thermal throttling temp: %s (0x%x)", temp, temp)
        return self.dev.admin_passthru(cmd)

    def ocp_set_value(self, types, value):
        dptr = OPCSetValue()
        dptr.TYPE = types
        dptr.VALUE.value = value

        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC1
        cmd.CDW[10] = 0x10001082
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        LOG.info("Send OCP set value, type: %s, value: %s (0x%x)", types, value, value)
        return self.dev.admin_passthru(cmd)

    def rfs_write(self, length=4096):
        dptr = (c_uint8 * length)()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x2000203D
        cmd.CDW[11] = length // 4
        cmd.CDW[12] = 0x80000000
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        LOG.info("Send RFS write, length: %s", length)
        return self.dev.admin_passthru(cmd)

    def rfs_read(self, fid=31, length=4096):
        dptr = (c_uint8 * length)()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x2000203D
        cmd.CDW[11] = length // 4
        cmd.CDW[12] = fid
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        LOG.info("Send RFS read, fid: %s, length: %s", fid, length)
        return self.dev.admin_passthru(cmd)

    def get_last_write_info(self, cursor_id=0):
        dptr = LastWriteInfo()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.CDW[12] = 2
        cmd.CDW[15] = cursor_id  # 0-- host 1--gc
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        LOG.info("get last write info, cursor_id: %d", cursor_id)
        self.dev.admin_passthru(cmd)
        return dptr

    def change_security_type(self, state):
        # more vu info in Support #35555
        state_dict = {
            'ise': 0x00000101,
            'sed': 0x00000001,
            '1dwpd': 0x00000002,
            '3dwpd': 0x00000102,
        }
        if state not in state_dict:
            raise ValueError('Unknown state:', state)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0XC0
        cmd.CDW[10] = 0X10000085
        cmd.CDW[12] = state_dict[state]

        LOG.info(f"Set Security Type To:{state},Please Do MCP to Apply The Settings")
        self.dev.admin_passthru(cmd)

    def sgl_error_switch(self, user=1, interval=10, cnt=1, port=0):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000067
        cmd.CDW[12] = user
        cmd.CDW[13] = interval
        cmd.CDW[14] = cnt
        cmd.CDW[15] = port

        return self.dev.admin_passthru(cmd)

    def bypass_gbb(self, enable=False):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000076
        cmd.CDW[12] = 0x0 if enable is False else 0x1  # if enable, means bypass, will not generate bb

        if enable:
            LOG.debug("enable bypass gbb")
        else:
            LOG.debug("disable bypass gbb")
        return self.dev.admin_passthru(cmd)

    def get_mark_bb_info(self):
        dptr = MarkBBInfo()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10002077
        cmd.CDW[11] = sizeof(dptr) // 4
        cmd.CDW[12] = 0
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        self.dev.admin_passthru(cmd)
        return dptr

    def set_resv_lp_count(self, cdw12=0, cdw13=0):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000086
        cmd.CDW[12] = cdw12  # log page count low 32 bits
        cmd.CDW[13] = cdw13  # log page count high 32 bits

        LOG.info("set reservation log page count, value: 0x%x", (cmd.CDW[13] << 32) + cmd.CDW[12])
        return self.dev.admin_passthru(cmd)

    def rollback_ver(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x10000087

        # LOG.info('Send ROLLBACK VU')
        return self.dev.admin_passthru(cmd)

    def read_l2p_table(self, lba_index, size=512 * 512):
        dptr = Malloc(size)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x30002016
        cmd.CDW[11] = size // 4
        cmd.CDW[12] = lba_index
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        # LOG.info("MFG Read L2P table successfully.")
        return dptr

    def get_ppa_config(self):
        dptr = Malloc(4096)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = 14
        cmd.CDW[12] = 0xe
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        ch_size = dptr.get_uint32(offset=32)
        ep_size = dptr.get_uint32(offset=36)
        plane_size = dptr.get_uint32(offset=40)
        lun_size = dptr.get_uint32(offset=44)
        page_size = dptr.get_uint32(offset=48)
        block_size = dptr.get_uint32(offset=52)
        ppa_config = dict(ch_size=ch_size, ep_size=ep_size, plane_size=plane_size, lun_size=lun_size,
                          page_size=page_size, block_size=block_size)
        return ppa_config

    def read_ppa_data_with_scramble(self, ppa_add, scramble=0, ldpc_bypass=1):
        dptr = Malloc(4096)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x2000203a
        cmd.CDW[11] = 1024
        cmd.CDW[12] = (ppa_add & 0xFFFF_FFFF)
        cmd.CDW[13] = scramble
        cmd.CDW[14] = ldpc_bypass
        cmd.CDW[15] = (ppa_add >> 32) & 0xFFFF_FFFF
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        return dptr

    def parsed_ppa_to_lba(self, ppa):
        LOG.info("Read ppa before parsing it {:#x}".format(ppa))
        self.read_ppa_data(ppa)
        dptr = Malloc(4096)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x20002067
        cmd.CDW[11] = 12
        cmd.CDW[12] = (ppa & 0xFFFF_FFFF)
        cmd.CDW[13] = (ppa >> 32) & 0xFFFF_FFFF
        LOG.info("Get lba info successfully.")
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        valid = dptr.get_uint32(offset=0)
        if valid:
            lba_l = dptr.get_uint32(offset=4)
            lba_h = dptr.get_uint32(offset=8)
            lba = lba_l | (lba_h << 32)
        else:
            lba = 0xFFFF_FFFF_FFFF_FFFF
        return valid, lba

    def read_ppa_data(self, ppa_add):
        dptr = Malloc(4096)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x20002006
        cmd.CDW[11] = 1024
        cmd.CDW[12] = (ppa_add & 0xFFFF_FFFF)
        cmd.CDW[13] = (ppa_add >> 32) & 0xFFFF_FFFF
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        return self.dev.admin_passthru(cmd)

    def is_ppa_saved_host_data(self, ppa):
        dptr = Malloc(4096)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x20002068
        cmd.CDW[11] = 4
        cmd.CDW[12] = (ppa & 0xFFFF_FFFF)
        cmd.CDW[13] = (ppa >> 32) & 0xFFFF_FFFF
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        valid = dptr.get_uint32(offset=0)
        result = False
        if valid == 1:
            result = True
        elif valid == 0:
            result = False
        else:
            raise AssertionError("Invalid value {:#x}".format(valid))
        return result

    def get_all_bb_on_super_block(self, superblock=0):
        dptr = Malloc(4096)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x20002001
        cmd.CDW[11] = 1024
        cmd.CDW[12] = 0xD
        cmd.CDW[13] = superblock
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        blk_num = dptr.get_uint32(0)
        LOG.info("There are {blk_num} bad blocks")
        bad_block_list = []
        for i in range(blk_num):
            bad_block_list.append(dptr.get_uint64(8 + i * 8))
        return bad_block_list

    def get_elog_lba_cnt(self):
        cdw11 = 80  # 20 * 4
        dptr = Malloc(cdw11)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x2000204f
        cmd.CDW[11] = cdw11
        cmd.CDW[12] = 0
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        elog_slba = dptr.get_uint32(0)
        elog_elba = dptr.get_uint32(4)
        elog_count = dptr.get_uint32(8)
        elog_slba_written = dptr.get_uint32(12)
        elog_elba_written = dptr.get_uint32(16)
        elog_count_written = dptr.get_uint32(20)
        if elog_count_written >= elog_count:
            LOG.info(f"flushed elog count {elog_count_written} exceed max len {elog_count}, shorten it")
            elog_count_written = elog_count
        parsed_elog_lba_info = dict(elog_slba=elog_slba, elog_elba=elog_elba, elog_count=elog_count,
                                    elog_slba_written=elog_slba_written,
                                    elog_elba_written=elog_elba_written,
                                    elog_count_written=elog_count_written)
        LOG.info("\nELog start lba:{elog_slba:#x} end lba:{elog_elba:#x}, lba count:{elog_count:#x}\n,"
                 "Elog written start lba:{elog_slba_written:#x}, written end lba:{elog_elba_written:#x},"
                 "written lba count(in 4k unit):{elog_count_written:#x}"
                 .format(**parsed_elog_lba_info))
        return parsed_elog_lba_info

    def parse_elog_lba(self, lba):
        cdw11 = 80  # 20 * 4
        dptr = Malloc(cdw11)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.NSID = 0xFFFF_FFFF
        cmd.CDW[10] = 0x2000204f
        cmd.CDW[11] = cdw11
        cmd.CDW[12] = 1
        cmd.CDW[13] = lba
        cmd.DATA = dptr.address
        cmd.DATA_LEN = dptr.size
        self.dev.admin_passthru(cmd)
        start_offset = 24
        ppa = dptr.get_uint32(0 + start_offset)
        ch = dptr.get_uint32(4 + start_offset)
        ep = dptr.get_uint32(8 + start_offset)
        pl = dptr.get_uint32(12 + start_offset)
        ln = dptr.get_uint32(16 + start_offset)
        pg = dptr.get_uint32(20 + start_offset)
        bl = dptr.get_uint32(24 + start_offset)
        parsed_ppa = dict(ppa=ppa, ch=ch, ep=ep, plane=pl, lun=ln, page=pg, block=bl)
        LOG.info("Parsed ppa:{ppa:#x} info: channel:{ch}, lun:{lun}, plane:{plane}, block:{block},"
                 "page:{page}, ep:{ep}".format(**parsed_ppa))
        return parsed_ppa
