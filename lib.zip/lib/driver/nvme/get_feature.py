#!/usr/bin/env python
# coding=utf-8
import logging
import time
from ctypes import c_uint8, c_uint32, cast, POINTER, sizeof, addressof

from nose.tools import assert_equal
from lib.driver.nvme import NVMe
from lib.driver.nvme import link
from lib.driver.nvme import struct
from lib.driver.nvme.struct import FeatureID as Fid
from lib.driver.utils import buf
from lib.driver.utils.ctype import Ctype


LOG = logging.getLogger()


class Feature:
    def __init__(self, dev, fid, dw11=0, nsid=0):
        self.nsid = nsid
        self.fid = fid
        self.dw11 = dw11
        self.dev = NVMe() if dev is None else dev
        self.id_ctrl = self.dev.identify_ctrl()
        self.active_ns_list = self.dev.identify_active_ns_list().ID
        self.fids_0x10300 = [0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                             0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 0x10, 0x11,
                             0x80, 0x81, 0x82, 0x83, ]
        self.fids_0x10400 = [0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                             0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 0x10, 0x11, 0x12,
                             0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x80, 0x81,
                             0x82, 0x83, 0x84]
        self.feature_ns_specific = [0x3, 0x5, 0x82, 0x83, 0x84]
        self.feature_ns_specific_specified = [0x82, 0x83]
        self.optional_feature = [0x3, 0x6, 0xc, 0xd, 0xe, 0x10, 0x11, 0x17, 0x18, 0x80, 0x81, 0x82, 0x83]
        self.memery_buffer_attribute = [0x3, 0xc, 0xe, 0x13, 0x16]
        self.dword0 = buf.Malloc(length=1, types=c_uint32)
        self.buffer = buf.Malloc(length=4096 * 2, types=c_uint8)
        self.get_cap()
        self.base_values = {}
        self.cfg = None
        self.link = link.Link()

    def search_dev(self):
        self.link.search_dev()
        self.dev.scan_devices()

    def get_cap(self):
        """get capability"""
        cdword0_struct = self.dev.get_features(self.fid, 3, self.dw11)[1]
        cdword0 = cdword0_struct.DWORD
        self.saveable = cdword0 & 0x1
        self.changeable = (cdword0 & 0b100) >> 2
        self.ns_spec = (cdword0 & 0b10) >> 1
        if self.ns_spec == 1:
            assert self.fid in self.feature_ns_specific, f"fid: {self.fid} is namespace specific, " \
                                                         "inconsistent with The NVM Express"
        else:
            assert self.fid not in self.feature_ns_specific, f"fid: {self.fid} is not namespace specific, " \
                                                             "inconsistent with The NVM Express"

    def get_feature_status_ns(self, fid: int, nsid: int):
        if fid in self.feature_ns_specific_specified and nsid not in range(1, self.id_ctrl.NN + 1):
            # NS specific specified ns in [0, invalid, full_f]
            return 0x2
        if fid in self.feature_ns_specific and nsid not in range(1, self.id_ctrl.NN + 1):
            # NS specific ns in [0, invalid, full_f]
            return 0xb
        if fid in self.feature_ns_specific and self.active_ns_list[nsid - 1] == 0:
            # NS specific ns is inactive
            return 0x2
        if fid not in self.feature_ns_specific and nsid not in list(range(0, self.id_ctrl.NN + 1)) + [0xFFFFFFFF]:
            # controller specific ns is invalid
            return 0xb
        return 0

    def set_features_status_ns(self, fid: int, nsid: int):
        if fid in self.feature_ns_specific_specified and nsid not in range(1, self.id_ctrl.NN + 1):
            # NS specific specified ns in [0, invalid, full_f]
            return 0x2
        if fid in self.feature_ns_specific and nsid not in range(1, self.id_ctrl.NN + 1):
            # NS specific ns in [0, invalid, full_f]
            return 0xb
        if fid in self.feature_ns_specific and self.active_ns_list[nsid - 1] == 0:
            # NS specific ns is inactive
            return 0x2
        if fid not in self.feature_ns_specific and nsid not in list(range(0, self.id_ctrl.NN + 1)) + [0xFFFFFFFF]:
            # controller specific ns is invalid
            return 0xb
        if fid not in self.feature_ns_specific and nsid in range(1, self.id_ctrl.NN + 1):
            return 0x10f
        return 0

    def get_expect_value(self, sel, set_attr):
        """get expect value"""
        if 'save' in set_attr:
            set_sv = set_attr['save']
        else:
            set_sv = 0
        if sel == 0:
            if self.changeable:
                new_base_values = set_attr.copy()
                new_base_values.pop('save')
                self.base_values[0] = new_base_values
            return self.base_values[0]
        if sel == 1:
            return self.base_values[1]
        if sel == 2:
            if (set_sv == 0) or (not self.saveable):
                return self.base_values[2]
            new_base_values = set_attr.copy()
            new_base_values.pop('save')
            self.base_values[2] = new_base_values
            return self.base_values[2]
        LOG.info("Not supported SEL in compare mode")
        return False

    def printf(self):
        pass

    def get_current_value(self):
        pass

    def check_attr(self, set_attr, sel):
        """check attribute"""
        expect = self.get_expect_value(sel, set_attr)
        if not expect:
            print(expect)
            return expect
        # LOG.info('actual value:')
        self.printf()
        # LOG.info('expect value: %d', (expect))
        return self.compare_field(expect)

    def check_after_set(self, set_attr):
        ns_list = [0, 0xffffffff, self.dev.nsid, self.id_ctrl.NN, self.id_ctrl.NN+1, 0xfffffffe]
        for i in range(3):
            for ns in ns_list:
                expected_status = self.get_feature_status_ns(fid=self.fid, nsid=ns)
                LOG.info(f"get feature: fid: {self.fid:#x}; sel: {i:#x}; "
                         f"cdw11: {self.dw11:#x}; nsid: {ns:#x}; expected status: {expected_status:#x};")
                self.dev.get_features(fid=self.fid, sel=i, cdw11=self.dw11, nsid=ns, status=expected_status)
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
                return ret
            LOG.info("***********************Test Passed: select is %d", i)
        return True

    def check_is_true_saved(self):
        if self.fid in self.memery_buffer_attribute:
            saved_buffer = self.dev.get_features(fid=self.fid, sel=2, cdw11=self.dw11)[2]
            self.link.hot_plug_action(5)
            self.dev.waiting_device_ready()
            saved_buffer_after_plp = self.dev.get_features(fid=self.fid, sel=2, cdw11=self.dw11)[2]
            current_buffer = self.dev.get_features(fid=self.fid, sel=0, cdw11=self.dw11)[2]
            # assert_equal(saved_buffer.value, saved_buffer_after_plp.value)
            saved = cast(addressof(saved_buffer), POINTER(c_uint8*sizeof(saved_buffer))).contents
            saved_af_plp = cast(addressof(saved_buffer_after_plp),
                                POINTER(c_uint8*sizeof(saved_buffer_after_plp))).contents
            current = cast(addressof(current_buffer), POINTER(c_uint8*sizeof(current_buffer))).contents
            for i in range(sizeof(saved)):
                # LOG.info(saved[i])
                if saved[i] != saved_af_plp[i]:
                    LOG.info("saved value:")
                    Ctype(saved_buffer).dump()
                    LOG.info("saved after plp value:")
                    Ctype(saved_buffer_after_plp).dump()
                assert_equal(saved[i], saved_af_plp[i], msg="saved value check fail")
                if saved[i] != current[i]:
                    LOG.info("saved value:")
                    Ctype(saved_buffer).dump()
                    LOG.info("current value:")
                    Ctype(current_buffer).dump()
                assert_equal(saved[i], current[i], msg="saved value check fail")
            return
        get_value_before_crash = self.base_values[2].copy()
        self.link.hot_plug_action(5)
        time.sleep(10)
        self.search_dev()
        self.get_current_value()
        get_value_after_crash = self.base_values[2].copy()
        assert_equal(get_value_before_crash, get_value_after_crash, msg="set feature with save failed")

    def compare_field(self, expect):
        pass


class Arbitration(Feature):
    """Arbitration base on Feature"""

    def __init__(self, dev=None, nsid=0):
        super().__init__(dev, Fid.Arbitration, nsid=nsid)
        self.cfg = self.dword0.convert(struct.Arbitration)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"hpw": dw0.HPW,
                     "mpw": dw0.MPW,
                     "lpw": dw0.LPW,
                     "ab": dw0.AB}
            self.base_values[i] = value

    def printf(self):
        """print Arbitration"""
        LOG.info("---------> get feature Arbitration")
        LOG.info(" Namespace:                                 0x%x", self.nsid)
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" High Priority Weight:                      0x%x", self.cfg.HPW)
        LOG.info(" Medium Priority Weight:                    0x%x", self.cfg.MPW)
        LOG.info(" Low Priority Weight:                       0x%x", self.cfg.LPW)
        LOG.info(" Arbitration Burst:                         0x%x", self.cfg.AB)

    def test_values(self, set_attr, status=0, **kwargs):
        """set_and_get_all_sel"""
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_arbitration(set_attr['save'], set_attr['ab'], set_attr['lpw'],
                                          set_attr['mpw'], set_attr['hpw'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.HPW == expect['hpw'] and self.cfg.MPW == expect['mpw'] and \
                self.cfg.LPW == expect['lpw'] and self.cfg.AB == expect['ab']:
            return True
        return False


class PowerManagement(Feature):
    """Power Management (Feature Identifier 02h)"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.PowerManagement)
        self.cfg = self.dword0.convert(struct.PowerManagement)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"wh": dw0.WH,
                     "ps": dw0.PS}
            self.base_values[i] = value

    def printf(self):
        """print value"""
        LOG.info("---------> Get Feature - Power Management")
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Workload Hint:                             0x%x", self.cfg.WH)
        LOG.info(" Power State:                               0x%x", self.cfg.PS)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.WH == expect['wh'] and self.cfg.PS == expect['ps']:
            return True
        return False

    def test_values(self, set_attr, status=0, **kwargs):
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_power_management(set_attr['save'],
                                               set_attr['ps'], set_attr['wh'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)


class LBARangeType(Feature):
    """LBA Range Type (Feature Identifier 03h), (Optional)"""

    def __init__(self, dev=None, prpo1=0, prpo2=0, index=0):
        super().__init__(dev, Fid.LBARangeType, prpo1, prpo2)
        self.cfg = self.dword0.convert(struct.LBARangeType)
        self.entry = self.buffer.convert(struct.LBARangeTypeEntry, index=index)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            entry = self.dev.get_features(self.fid, i, self.dw11)[2][0]
            value = {"TYPE": entry.TYPE, "ATTR": entry.ATTR, "SLBA": entry.SLBA,
                     "NLB": entry.NLB, "GUID": entry.GUID.LOW}
            self.base_values[i] = value
            LOG.info(self.base_values)

    def printf(self):
        """print value"""
        LOG.info("---------> get feature LBA Range Type")
        LOG.info(" Saveable:                    0x%x", self.saveable)
        LOG.info(" Changeable:                  0x%x", self.changeable)
        LOG.info(" Namespace specific:          0x%x", self.ns_spec)
        LOG.info(" Type:                        0x%x", self.entry.TYPE)
        LOG.info(" Attributes:                  0x%x", self.entry.ATTR)
        LOG.info(" Starting LBA:                0x%x", self.entry.SLBA)
        LOG.info(" Number of Logical Blocks:    0x%x", self.entry.NLB)
        LOG.info(" Unique Identifier:           0x%s", self.entry.GUID.LOW)

    def test_values(self, set_attr: dict, status=0, **kwargs):
        """test values"""
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        lrt = [set_attr.copy()]
        # lrt[0].pop("num")
        lrt[0].pop("save")
        self.dev.set_features_lba_range_type(lrt, set_attr['save'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def check_after_set(self, set_attr):
        ns_list = [0, 0xffffffff, self.dev.nsid, self.id_ctrl.NN, self.id_ctrl.NN+1, 0xfffffffe]
        for i in range(3):
            for ns in ns_list:
                expected_status = self.get_feature_status_ns(fid=self.fid, nsid=ns)
                LOG.info(f"get feature: fid: {self.fid:#x}; sel: {i:#x}; "
                         f"cdw11: {self.dw11:#x}; nsid: {ns:#x}; expected status: {expected_status:#x};")
                self.dev.get_features(fid=self.fid, sel=i, cdw11=self.dw11, nsid=ns, status=expected_status)
            self.entry = self.dev.get_features(self.fid, i, self.dw11)[2][0]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
                return ret
            LOG.info("***********************Test Passed: select is %d", i)
        LOG.info("Check after reset")
        self.dev.reset()
        self.entry = self.dev.get_features(self.fid, 0, self.dw11)[2][0]
        saved = self.dev.get_features(self.fid, 2, self.dw11)[2][0]
        expect = {"TYPE": saved.TYPE, "ATTR": saved.ATTR, "SLBA": saved.SLBA,
                  "NLB": saved.NLB, "GUID": saved.GUID.LOW}
        actual = {"TYPE": self.entry.TYPE, "ATTR": self.entry.ATTR, "SLBA": self.entry.SLBA,
                  "NLB": self.entry.NLB, "GUID": self.entry.GUID.LOW}
        LOG.info(f"actual: {actual}")
        LOG.info(f"expect: {expect}")
        return self.compare_field(expect)

    def compare_field(self, expect):
        """compare_field"""
        if self.entry.TYPE == expect['TYPE'] and self.entry.ATTR == expect['ATTR'] and \
                self.entry.SLBA == expect['SLBA'] and self.entry.NLB == expect['NLB'] and \
                self.entry.GUID.LOW == expect['GUID']:
            return True
        return False


class TemperatureThreshold(Feature):
    """TemperatureThreshold base on Feature"""

    def __init__(self, dev=None, dw11=0, nsid=0):
        super().__init__(dev, Fid.TemperatureThreshold, dw11=dw11, nsid=nsid)
        self.cfg = self.dword0.convert(struct.TemperatureThreshold)
        self.set_attr = None
        self.get_current_value()

    def printf(self):
        """print value"""
        LOG.info("---------> get feature Temperature Threshold")
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info("Threshold Type Select:                      0x%x", self.cfg.THSEL)
        LOG.info("Threshold Temperature Select:               0x%x", self.cfg.TMPSEL)
        LOG.info("Temperature Threshold:                      0x%x", self.cfg.TMPTH)

    def get_current_value(self):
        """get current value"""
        LOG.info(f"get feature: fid: {self.fid:#x}, cdw11: {self.dw11}")
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"thsel": dw0.THSEL,
                     "tmpsel": dw0.TMPSEL,
                     "tmpth": dw0.TMPTH}
            self.base_values[i] = value

    def test_values(self, set_attr, status=0, **kwargs):
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_temperature_threshold(set_attr['save'], set_attr['tmpth'],
                                                    set_attr['tmpsel'], set_attr['thsel'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.THSEL == expect['thsel'] and self.cfg.TMPSEL == expect['tmpsel'] and \
                self.cfg.TMPTH == expect['tmpth']:
            return True
        return False


class ErrorRecovery(Feature):
    """ErrorRecovery base on Feature"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.ErrorRecovery, 0, 0)
        self.cfg = self.dword0.convert(struct.ErrorRecovery)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"tler": dw0.TLER,
                     "dulbe": dw0.DULBE}
            self.base_values[i] = value
            LOG.info(self.base_values)

    def printf(self):
        """print value"""
        LOG.info(" Saveable:               0x%x", self.saveable)
        LOG.info(" Changeable:             0x%x", self.changeable)
        LOG.info(" Namespace specific:     0x%x", self.ns_spec)
        LOG.info(" Deallocated or Unwritten Logical Block Error Enable: 0x%x", self.cfg.DULBE)
        LOG.info(" Time Limited Error Recovery:  0x%x", self.cfg.TLER)

    # def test_values(self, set_attr):
    #     """test value"""
    #     self.dev.set_features_error_recovery(set_attr['save'],
    #                                          set_attr['tler'], set_attr['dulbe'])
    #     return self.check_after_set(set_attr)
    def test_values(self, set_attr, status=0, **kwargs):
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_error_recovery(set_attr['save'],
                                             set_attr['tler'], set_attr['dulbe'], nsid=self.dev.nsid,
                                             status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.DULBE == expect['dulbe'] and self.cfg.TLER == expect['tler']:
            return True
        return False


class VolatileWriteCache(Feature):
    """VolatileWriteCache base on Feature"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.VolatileWriteCache, 0, 0)
        self.cfg = self.dword0.convert(struct.VolatileWriteCache)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            valuse = {"wce": dw0.WCE}
            self.base_values[i] = valuse

    def printf(self):
        """print value"""
        LOG.info("---------> get feature Volatile WriteCache")
        LOG.info(" Saveable:             0x%x", self.saveable)
        LOG.info(" Changeable:           0x%x", self.changeable)
        LOG.info(" Namespace specific:   0x%x", self.ns_spec)
        LOG.info(" Volatile Write Cache Enable:     0x%x", self.cfg.WCE)

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_volatile_write_cache(set_attr['save'], set_attr['wce'])
        for i in range(3):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.WCE == expect['wce']:
            return True
        return False


class InterruptCoalescing(Feature):
    """InterruptCoalescing"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.InterruptCoalescing, 0, 0)
        self.cfg = self.dword0.convert(struct.InterruptCoalescing)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(3):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            values = {"time": dw0.TIME, "thr": dw0.THR}
            self.base_values[i] = values
            LOG.info(self.base_values)

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Aggregation Time:                          0x%x", self.cfg.TIME)
        LOG.info(" Aggregation Threshold:                     0x%x", self.cfg.THR)

    # def test_values(self, set_attr):
    #     """test value"""
    #     self.dev.set_features_interrupt_coalescing(set_attr['save'],
    #                                                set_attr['thr'], set_attr['time'])
    #     return self.check_after_set(set_attr)
    def test_values(self, set_attr, status=0, **kwargs):
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_interrupt_coalescing(set_attr['save'],
                                                   set_attr['thr'], set_attr['time'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.THR == expect['thr'] and self.cfg.TIME == expect['time']:
            return True
        return False


class InterruptVectorConfiguration(Feature):
    """InterruptVectorConfiguration"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.InterruptVectorConfiguration, 0, 0)
        self.cfg = self.dword0.convert(struct.InterruptVectorConfiguration)
        self.get_current_value()

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Coalescing Disable:                        0x%x", self.cfg.CD)
        LOG.info(" Interrupt Vector:                          0x%x", self.cfg.IV)

    def get_current_value(self):
        """get current value"""
        for i in range(3):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"cd": dw0.CD, "iv": dw0.IV}
            self.base_values[i] = value
            LOG.info(self.base_values)

    # def test_values(self, set_attr):
    #     """test value"""
    #     self.dev.set_features_interrupt_vector_configuration(set_attr['save'],
    #                                                          set_attr['iv'], set_attr['cd'])
    #     return self.check_after_set(set_attr)
    def test_values(self, set_attr, status=0, **kwargs):
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_interrupt_vector_configuration(set_attr['save'],
                                                             set_attr['iv'], set_attr['cd'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.CD == expect['cd'] and self.cfg.IV == expect['iv']:
            return True
        return False


class WriteAtomicity(Feature):
    """WriteAtomicity"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.WriteAtomicityNormal, 0, 0)
        self.cfg = self.dword0.convert(struct.WriteAtomicityNormal)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"dn": dw0.DN}
            self.base_values[i] = value
            LOG.info(self.base_values)

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Disable Normal:                            0x%x", self.cfg.DN)

    # def test_values(self, set_attr):
    #     """test value"""
    #     self.dev.set_features_write_atomicity_normal(set_attr['save'], set_attr['dn'])
    #     return self.check_after_set(set_attr)
    def test_values(self, set_attr, status=0, **kwargs):
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_write_atomicity_normal(set_attr['save'], set_attr['dn'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.DN == expect['dn']:
            return True
        return False


class AsynchronousEventConfiguration(Feature):
    """AsynchronousEventConfiguration"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.AsynchronousEventConfiguration, 0, 0)
        self.cfg = self.dword0.convert(struct.AsynchronousEventConfiguration)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"fan": dw0.FAN,
                     "nan": dw0.NAN,
                     "shcw": dw0.SHCW,
                     "tln": dw0.TLN}
            self.base_values[i] = value

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Firmware Activation Notices:               0x%x", self.cfg.FAN)
        LOG.info(" Namespace Attribute Notices:               0x%x", self.cfg.NAN)
        LOG.info(" SMART / Health Critical Warnings:          0x%x", self.cfg.SHCW)

    # def test_values(self, set_attr):
    #     """test_value"""
    #     self.dev.set_features_asynchronous_event_configuration(
    #         set_attr['save'], set_attr['shcw'], set_attr['nan'], set_attr['fan'], set_attr['tln'])
    #     return self.check_after_set(set_attr)
    def test_values(self, set_attr, status=0, **kwargs):
        LOG.info(f"set feature, fid: {self.fid}: {set_attr}, status: {status:#x}")
        self.dev.set_features_asynchronous_event_configuration(
            set_attr['save'], set_attr['shcw'], set_attr['nan'],
            set_attr['fan'], set_attr['tln'], status=status, **kwargs)
        if status != 0:
            return 1
        return self.check_after_set(set_attr)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.FAN == expect['fan'] and self.cfg.NAN == expect['nan'] and \
                self.cfg.SHCW == expect['shcw'] and self.cfg.TLN == expect['tln']:
            return True
        return False


class AutonomousPowerStateTransition(Feature):
    """Autonomous Power State Transition"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.AutonomousPowerStateTransition, 0, 0)
        self.entry = self.buffer.convert(struct.AutonomousPowerStateTransitionEntry)
        self.cfg = self.dword0.convert(struct.AutonomousPowerStateTransition)
        self.get_current_value()

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                   0x%x", self.saveable)
        LOG.info(" Changeable:                                 0x%x", self.changeable)
        LOG.info(" Namespace specific:                         0x%x", self.ns_spec)
        LOG.info(" Autonomous Power State Transition Enable:   0x%x", self.cfg.APSTE)
        LOG.info(" Idle Time Prior to Transition:              0x%x", self.entry.ITPT)
        LOG.info(" Idle Transition Power State:                0x%x", self.entry.ITPS)

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            valuse = {"apste": dw0.APSTE}
            self.base_values[i] = valuse

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.APSTE == expect['apste']:
            return True
        return False

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_autonomous_power_state_transition(set_attr['save'], set_attr['apste'])
        for i in range(3):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret


class SoftwareProgressMarker(Feature):
    """SoftwareProgressMarker base on Feature"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.SoftwareProgressMarker, 0, 0)
        self.cfg = self.dword0.convert(struct.SoftwareProgressMarker)
        self.get_current_value()

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Pre-boot Software Load Count:              0x%x", self.cfg.PBSLC)

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"pbslc": dw0.PBSLC}
            self.base_values[i] = value
            LOG.info(self.base_values[i])

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_software_progress_marker(set_attr['save'], set_attr['pbslc'])
        for i in range(3):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.PBSLC == expect['pbslc']:
            return True
        return False


class HostIdentifier(Feature):
    """Host Identifier ONLY 8 bytes data structure"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.HostIdentifier, 0, 0)
        self.entry = self.buffer.convert(struct.HostIdentifierEntry)
        self.cfg = self.dword0.convert(struct.HostIdentifier)
        self.get_current_value()

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Enable Host Identifier:                    0x%x", self.cfg.EXHID)
        LOG.info(" Host Identifier Low 64:                    0x%x", self.entry.HOSTIDL)
        LOG.info(" Host Identifier High 64:                   0x%x", self.entry.HOSTIDH)

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            value = {"exhid": dw0.EXHID,
                     "hostidl": self.entry.HOSTIDL,
                     "hostidh": self.entry.HOSTIDH, }
            self.base_values[i] = value
            LOG.info(self.base_values[i], "WWWW")

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_host_identifier(set_attr['exhid'], set_attr['hostidl'],
                                                    set_attr['hostidh'], set_attr['save'])
        for i in range(3):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret

    def compare_field(self, expect):
        """compare_field"""
        if self.entry.HOSTIDL == expect['hostidl'] and self.entry.HOSTIDH == expect['hostidh']:
            return True
        return False


class Timestamp(Feature):
    """ReservationPersistence"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.Timestamp, 0, 0)
        self.entry = self.buffer.convert(struct.Timestamp)
        self.cfg = self.dword0.convert(struct.Timestamp)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            value = {"timestamp": self.entry.TIMESTAMP,
                     "synch": self.entry.SYNCH,
                     "to": self.entry.TO}
            self.base_values[i] = value
            LOG.info(self.base_values[i])

    def printf(self):
        """print value"""
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Timestamp:                                 0x%x", self.entry.TIMESTAMP)
        LOG.info(" Synch:                                     0x%x", self.entry.SYNCH)
        LOG.info(" Timestamp Origin:                          0x%x", self.entry.TO)

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_timestamp(set_attr['timestamp'], set_attr['save'])
        for i in range(3):
            self.dword0 = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret

    def get_expect_value(self, sel, set_attr):
        """get expect value"""
        if sel in (0, 1, 2):
            value = self.base_values[0]
        else:
            LOG.info("Not supported SEL in compare mode")
            value = False
        return value

    def compare_field(self, expect):
        """compare_field"""
        if self.entry.TIMESTAMP == expect['timestamp'] and self.entry.SYNCH == expect['synch'] and \
                self.entry.TO == expect['to']:
            return True
        return False


class HostControlledThermalManagement(Feature):
    """KeepAliveTimer"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.HostControlledThermalManagement, 0, 0)
        self.cfg = self.dword0.convert(struct.HostControlledThermalManagement)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            LOG.info("-----------sel : %d", i)
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            valuse = {"tmt1": dw0.TMT1,
                      "tmt2": dw0.TMT2}
            self.base_values[i] = valuse

    def printf(self):
        """print value"""
        LOG.info("---------> get feature Number of Queues")
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Thermal Management Temperature 1:          0x%x", self.cfg.TMT1)
        LOG.info(" Thermal Management Temperature 2:          0x%x", self.cfg.TMT2)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.TMT1 == expect['tmt1'] and self.cfg.TMT2 == expect['tmt2']:
            return True
        return False

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_host_controlled_thermal_management(
            set_attr['save'], set_attr['tmt2'], set_attr['tmt1'])
        for i in range(3):
            self.dword0 = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret


class NonOperationalPowerStateConfig(Feature):
    """NonOperationalPowerStateConfig"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.NonOperationalPowerStateConfig, 0, 0)
        self.cfg = self.dword0.convert(struct.NonOperationalPowerStateConfig)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            valuse = {"NOPPME": dw0.NOPPME}
            self.base_values[i] = valuse

    def printf(self):
        """print value"""
        LOG.info("---------> get feature Number of Queues")
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Non-Operational Power State Permissive Mode Enable: 0x%x", self.cfg.NOPPME)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.NOPPME == expect['NOPPME']:
            return True
        return False

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_nonoperational_power_state_config(set_attr['save'], set_attr['noppme'])
        for i in range(3):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret


class HostMemoryBuffer(Feature):
    """HostMemoryBuffer"""

    def __init__(self, dev=None):
        super().__init__(dev, Fid.HostMemoryBuffer, 0, 0)
        self.cfg = self.dword0.convert(struct.HostMemoryBuffer)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(2):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            valuse = {"EHM": dw0.EHM,
                      "MR": dw0.MR}
            self.base_values[i] = valuse

    def printf(self):
        """print value"""
        LOG.info("---------> get feature Number of Queues")
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" Enable Host Memory: 0x%x", self.cfg.EHM)
        LOG.info(" Memory Return: 0x%x", self.cfg.MR)

    def test_values(self, set_attr):
        """test value"""
        return self.set_and_get_all_sel(set_attr)

    def set_and_get_all_sel(self, set_attr):
        """set_and_get_all_sel"""
        ret = self.dev.set_features_host_memory_buffer(
            set_attr['save'], set_attr['ehm'], set_attr['mr'], set_attr['esize'], set_attr['hdmlec'])
        for i in range(2):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return ret

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.EHM == expect['EHM'] and self.cfg.MR == expect['MR']:
            return True
        return False

class ReservationNotificationMask(Feature):

    def __init__(self, dev=None):
        super().__init__(dev, Fid.ReservationNotificationMask, 0, 0)
        self.cfg = self.dword0.convert(struct.ReservationNotificationMask)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            valuse = {"REGPRE": dw0.REGPRE,
                      "RESREL": dw0.RESREL,
                      "RESPRE": dw0.RESPRE
                      }
            self.base_values[i] = valuse

    def printf(self):
        """print value"""
        LOG.info("---------> get feature ReservationNotificationMask")
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" after set fea avlue of REGPRE:             0x%x", self.cfg.REGPRE)
        LOG.info(" after set fea avlue of RESREL:             0x%x", self.cfg.RESREL)
        LOG.info(" after set fea avlue of RESPRE:             0x%x", self.cfg.RESPRE)

    def compare_field(self, expect):
        """compare_field"""

        if self.cfg.REGPRE == expect['REGPRE'] and self.cfg.RESREL == expect['RESREL'] \
                and self.cfg.RESPRE == expect['RESPRE']:
            return True
        return False

    def test_values(self, set_attr, status=0):
        """test value"""
        if status != 0:
            return 1
        return self.set_and_get_all_sel(set_attr, status)

    def set_and_get_all_sel(self, set_attr, status=0):
        """set_and_get_all_sel"""
        self.dev.set_features_ReservationNotificationMask(
            set_attr['save'], set_attr['REGPRE'], set_attr['RESREL'], set_attr['RESPRE'], status=status)
        for i in range(3):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
                assert_equal(ret, True, msg='Test failed: select is %d", i')
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return True

class ReservationPersistence(Feature):

    def __init__(self, dev=None):
        super().__init__(dev, Fid.ReservationPersistence, 0, 0)
        self.cfg = self.dword0.convert(struct.ReservationPersistence)
        self.get_current_value()

    def get_current_value(self):
        """get current value"""
        for i in range(4):
            _, dw0, _ = self.dev.get_features(self.fid, i, self.dw11)
            valuse = {"PTPL": dw0.PTPL
                      }
            self.base_values[i] = valuse

    def printf(self):
        """print value"""
        LOG.info("---------> get feature ReservationPersistence")
        LOG.info(" Saveable:                                  0x%x", self.saveable)
        LOG.info(" Changeable:                                0x%x", self.changeable)
        LOG.info(" Namespace specific:                        0x%x", self.ns_spec)
        LOG.info(" after set fea avlue of PTPL:               0x%x", self.cfg.PTPL)

    def compare_field(self, expect):
        """compare_field"""
        if self.cfg.PTPL == expect['PTPL']:
            return True
        return False

    def test_values(self, set_attr, status=0):
        """test value"""
        if status != 0:
            return 1
        return self.set_and_get_all_sel(set_attr, status)

    def set_and_get_all_sel(self, set_attr, status=0):
        """set_and_get_all_sel"""
        self.dev.set_features_ReservationPersistence(
            set_attr['save'], set_attr['PTPL'], status=status)
        for i in range(3):
            self.cfg = self.dev.get_features(self.fid, i, self.dw11)[1]
            ret = self.check_attr(set_attr, i)
            if ret is False:
                LOG.info("***********************Test failed: select is %d", i)
                assert_equal(ret, True,msg='Test failed: select is %d", i')
            else:
                LOG.info("***********************Test Passed: select is %d", i)
        return True
