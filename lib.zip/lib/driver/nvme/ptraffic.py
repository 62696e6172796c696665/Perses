#!/usr/bin/env python
# coding=utf-8
# pylint: disable=superfluous-parens,missing-docstring,too-many-public-methods,too-many-locals
import random
import datetime
import time
import logging
import os
# import re
from lib.driver.nvme.struct import DatasetManagementEntry
from lib.driver.utils import buf, system
from lib.driver.nvme import PIOCTL, LBAOperate
from lib.driver.nvme import nvme
from lib.tool.fio.fio_linux import Fio

LOG = logging.getLogger()


class PnvmeOperate(LBAOperate):
    def __init__(self, dev=None, cntid=0, nsid=1, pid=0):
        super().__init__(dev, cntid, nsid)
        self.pid = pid
        self.p_char = f"pnvme{self.pid}"
        self.load_pnvme()
        self.pnvme = PIOCTL()
        self.awun = 0
        self.awupf = 0
        self.acwu = 0
        self.absn = 0
        self.abo = 0
        self.abspf = 0
        self.pnvme.format_up()
        self.par_up()
        self.fio = None

    @property
    def is_pnvme_exist(self):
        base_path = '/dev'
        for cdev in os.listdir(base_path):
            if self.p_char in cdev:
                return 1
        return 0

    def load_pnvme(self):
        root_path = os.getcwd()
        pnvme_file = root_path+f'/tools/nvme_plugin/pnvme{self.pid}.ko'
        cmd = 'insmod '+pnvme_file+f" ctrl_id={self.dev.char_id}"
        print(cmd)
        if not self.is_pnvme_exist:
            system.execute(cmd)

    def remove_pnvme(self):
        cmd = f"rmmod {self.p_char}"
        system.execute(cmd)

    def par_up(self, nsid=1, cntid=0):
        nsid = 1
        cntid = 0
        _, id_ctrl = self.dev.identify(nsid=nsid, cns=0x1, cntid=cntid)
        _, id_ns = self.dev.identify(nsid=nsid, cns=0x0, cntid=cntid)
        self.awun = id_ctrl.AWUN if id_ns.NAWUN == 0 else id_ns.NAWUN
        self.awupf = id_ctrl.AWUPF if id_ns.NAWUPF == 0 else id_ns.NAWUPF
        self.acwu = id_ctrl.ACWU if id_ns.NACWU == 0 else id_ns.NACWU
        self.absn = id_ns.NABSN
        self.abo = id_ns.NABO
        self.abspf = id_ns.NABSPF

    def dsm_async(self, range_num, slba, range_length, qid, mode=0, chk_flg=False, nsid=1):
        assert range_num != 0, 'range num can not be set to 0'
        range_buf = buf.Malloc(range_num, DatasetManagementEntry)
        for i in range(range_num):
            _slba = slba + i * range_length
            if (mode == 1) & (i % 2 == 1):
                nlb = range_length + 1
            else:
                nlb = range_length

            range_buf[i].SLBA = _slba
            range_buf[i].LENGTH = nlb
            if chk_flg:
                self._update_map(_slba, nlb, mode=0, pattern=self._get_pattern())
        return self.pnvme.dataset_management(range_num, range_buf.buf, qid=qid, nsid=nsid)

    def write_sgl_sync(self, lba, nlb, d_sgl, qid, m_sgl=None, status=0, sgl_data_offset=0, sgl_meta_offset=0, mode=0,
                       pattern=0, printf=True):
        if printf:
            LOG.info("WRITE: [LBA:0x%x, NLB:0x%x, MODE:0x%x, PATN:0x%x]", lba, nlb, mode, pattern)
        if self.meta_size != 0 and self.is_dif != 1:
            if m_sgl is None:
                raise AssertionError("Invalid Meta SGL")
            mdes_num = m_sgl.des_num
            msglptr = m_sgl.buf
        else:
            msglptr = None
            mdes_num = 0
        self._malloc_write_buffer(lba, nlb, mode, pattern)
        status = self.pnvme.write_sgl(lba, nlb, d_sgl.des_num, mdes_num, self._wt_data.buf, d_sgl.buf,
                                     mptr=self._wt_meta.buf, msglptr=msglptr, qid=qid, nsid=self.nsid,
                                     ctrl=self.ctrl, status=status, flags=self.flags, doff=sgl_data_offset,
                                     moff=sgl_meta_offset)
        self._update_map(lba, nlb, mode, pattern)

    def read_sgl_sync(self, lba, nlb, d_sgl, qid, m_sgl=None, sgl_data_offset=0, sgl_meta_offset=0, status=0,
                      compare=True, mode=None, pattern=None, printf=True, dump=True):
        self._malloc_read_buffer(nlb)
        dptr_len, mptr_len = self.get_dptr_mptr_len()
        if printf:
            LOG.info("READ : [LBA: 0x%x, NLB: 0x%x]", lba, nlb)
        if mptr_len:
            if m_sgl is None:
                raise AssertionError("Invalid Meta SGL")
            mdes_num = m_sgl.des_num
            msglptr = m_sgl.buf
        else:
            msglptr = None
            mdes_num = 0
        self.pnvme.read_sgl(lba, nlb, d_sgl.des_num, mdes_num, self._rd_data.buf, d_sgl.buf, mptr=self._rd_meta.buf,
                           msglptr=msglptr, qid=qid, nsid=self.nsid, ctrl=self.ctrl, status=status,
                           flags=self.flags, doff=sgl_data_offset, moff=sgl_meta_offset)
        if compare and (status == 0):
            for i in range(nlb):
                if mode is None or (pattern is None and isinstance(pattern, int)):
                    if lba + i not in self._lba_map:
                        LOG.info('Warning: Skip unknown LBA: 0x%x', lba + i)
                        continue
                    _mode, _pattern = self._lba_map[lba + i].mode, self._lba_map[lba + i].pattern
                else:
                    _mode, _pattern = mode, pattern

                self._compare(self._rd_data, lba + i, _mode, _pattern, start=i * dptr_len,
                              size=dptr_len, dump=dump)
                if mptr_len:
                    self._compare(self._rd_meta, lba + i, _mode, _pattern, start=i * mptr_len,
                                  size=mptr_len, dump=dump)

    def read_sgl_bitb(self, lba, nlb, d_sgl, qid, m_sgl=None, sgl_data_offset=0, sgl_meta_offset=0, status=0,
                      compare=True, meta=0, mode=None, pattern=None, fix=False, printf=True, dump=True):
        self._malloc_read_buffer(nlb)
        if printf:
            LOG.info("READ : [LBA: 0x%x, NLB: 0x%x]", lba, nlb)
        if self.meta_size != 0 and self.is_dif != 1:
            if m_sgl is None:
                raise AssertionError("Invalid Meta SGL")
            mdes_num = m_sgl.des_num
            msglptr = m_sgl.buf
        else:
            msglptr = None
            mdes_num = 0
        self.pnvme.read_sgl(lba, nlb, d_sgl.des_num, mdes_num, self._rd_data.buf, d_sgl.buf, mptr=self._rd_meta.buf,
                           msglptr=msglptr, qid=qid, nsid=self.nsid, ctrl=self.ctrl, status=status,
                           flags=self.flags, doff=sgl_data_offset, moff=sgl_meta_offset)
        if compare and (status == 0):
            dptr_len, mptr_len = self.get_dptr_mptr_len()
            self._malloc_write_buffer(lba, nlb, mode, pattern, fixed=fix)
            # mask bitb with 0
            for bdes in d_sgl.bit_array:
                # print("{} {}......".format(bdes["d_ofs"], bdes["len"]))
                if bdes["len"]:
                    self._wt_data.fill_uint8_fix(0, bdes["d_ofs"], bdes["len"])
            # self._rd_data.dump_uint32()
            self._compare_data(lba, start=0, size=dptr_len * nlb, dump=dump)
            if meta:
                for mbdes in m_sgl.bit_array:
                    self._wt_meta.fill_uint8_fix(0, mbdes["d_ofs"], mbdes["len"])
                self._compare_meta(lba, start=0, size=mptr_len * nlb, dump=dump)

    def fio_io(self, mode=0, dev=None, runt=0, delay=600):
        self.fio = Fio()
        if dev is None:
            self.fio.set_parm("filename", nvme.Tahoe().block_dev)
        else:
            self.fio.set_parm("filename", dev)
        self.fio.set_parm("ioengine", "libaio")
        self.fio.set_parm("direct", "1")
        self.fio.set_parm('eta-newline', "1")
        self.fio.set_parm('group_reporting', True)
        self.fio.set_parm('continue_on_error', 1)
        self.fio.set_parm('name', "debug")
        self.fio.set_parm('eta', "always")
        if mode == 0:
            self.fio.set_parm('rw', 'write')
            self.fio.set_parm('blocksize', '256k')
            self.fio.set_parm('size', '100%')
            self.fio.set_parm('offset', '0%')
            self.fio.set_parm('iodepth', 128)
            self.fio.set_parm('rwmixread', 0)
            self.fio.set_parm('runtime', runt)
            self.fio.set_parm('numjobs', 1)
            self.fio.start()
        else:
            self.fio.set_parm('rw', 'randwrite')
            self.fio.set_parm('blocksize', '4k')
            self.fio.set_parm('size', '50%')
            self.fio.set_parm('offset', '50%')
            self.fio.set_parm('rwmixread', 0)
            self.fio.set_parm('continue_on_error', 1)
            self.fio.set_parm('runtime', runt)
            self.fio.set_parm('iodepth', 32)
            self.fio.set_parm('numjobs', 8)
            self.fio.run()
            time.sleep(delay)

    def wait_fio_done(self):
        self.fio.join()

    def async_one_io(self, nlb, qid, rdpct=0, duration=3600, maxlba=0x2000000, startlba=0):
        start = datetime.datetime.now()
        end = datetime.datetime.now()
        cmd_cnt = 0
        while((end-start).total_seconds() < duration):
            slba = random.randint(startlba, maxlba)
            is_wr = (random.randint(0, 100) > rdpct)
            if is_wr:
                self.pnvme.write_async(slba, nlb, qid=qid)
            else:
                self.pnvme.read_async(slba, nlb, qid=qid)
            end = datetime.datetime.now()
            cmd_cnt += 1
        print("Q[%d] Total Command[%d]"%(qid, cmd_cnt))

    def atomic_rand_io(self, nlb, qid, rdpct=0, duration=3600, maxlba=0x2000000, startlba=0, step=1, do_trim=0):
        #LOG.info(f"nlb:{nlb}")
        start = datetime.datetime.now()
        end = datetime.datetime.now()
        cmd_cnt = 0
        while((end-start).total_seconds() < duration):
            slba = random.randint(startlba, maxlba)
            slba = int(slba/step)*step
            is_wr = (random.randint(0, 100) > rdpct)
            #LOG.info(f"[atomic_io] lba:{slba} is_wr:{is_wr}")
            trim_flg = (random.randint(0, 100) > rdpct) if do_trim else 0
            if trim_flg:
                self.dsm_async(range_num=random.randint(1, 32), slba=slba, range_length=nlb, qid=self.qid)
            if is_wr:
                self.pnvme.write_atomic(slba, nlb, qid=qid, pat=cmd_cnt)
            else:
                self.pnvme.read_atomic(slba, nlb, qid=qid)
            end = datetime.datetime.now()
            cmd_cnt += 1

    def atomic_io(self, duration=3600, maxlba=0x2000000, startlba=0, qid=10, \
                    do_trim=0, single_step=100, mode=0, nsid=1, max_stream=0, callback=None):
        start = datetime.datetime.now()
        end = datetime.datetime.now()
        cmd_cnt = 0
        self.par_up(nsid=nsid)
        maxnlb = self.awun+1
        LOG.info(f"Atomic parameter: AWUN{self.awun}")
        off = 0
        nlb = maxnlb
        while((end-start).total_seconds() < duration):
            slba = (int)(random.randint(startlba, maxlba)/(self.absn+1))*(self.absn+1)
            if mode == 2:
                nlb = random.randint(1, maxnlb)
            elif mode == 1:
                off = 2
            LOG.info(f"do atomic test on lba:{slba:#7x}, nlb:{nlb}")
            self.pnvme.write_atomic(slba, nlb, qid=qid, pat=0, stream_id=random.randint(0, max_stream))
            time.sleep(1)
            for j in range(single_step):
                self.pnvme.write_atomic(slba, nlb-off, qid=qid, pat=0, \
                        nsid=nsid, stream_id=random.randint(0, max_stream))
                self.pnvme.write_atomic(slba+off, nlb-off, qid=qid, pat=j, nsid=nsid)
                if do_trim:
                    self.dsm_async(range_num=nlb-off, slba=slba+off, \
                                    range_length=1, qid=qid, nsid=nsid)
                if j%5 == 0:
                    if callback:
                        callback()
                    self.pnvme.read_atomic(slba+off, nlb-2*off, qid=qid, nsid=nsid)

            end = datetime.datetime.now()
            cmd_cnt += 1

    def write_lba(self, lba, nlb, mode=0, pattern=0, bypass=0, printf=True, **kwargs):
        if printf:
            LOG.info("Write LBA: 0x%x, nlb: 0x%x, mode: 0x%x, pattern: 0x%x", lba, nlb, mode, pattern)

        self._malloc_write_buffer(lba, nlb, mode, pattern, bypass)
        status = self.pnvme.write(lba, nlb, self._wt_data.buf, self._wt_meta.buf, **kwargs)
        if not status:
            self._update_map(lba, nlb=nlb, mode=mode, pattern=pattern)
        return status

    def read_lba(self, lba, nlb, mode=None, pattern=None, meta=True, compare=True, printf=True, dump=True, **kwargs):
        if printf:
            title = 'Read & Compare' if compare else 'Read'
            LOG.info("%s LBA: 0x%x, nlb: 0x%x", title, lba, nlb)

        self._malloc_read_buffer(nlb)
        status = self.pnvme.read(lba, nlb, self._rd_data.buf, self._rd_meta.buf, **kwargs)

        if not status and compare:
            dptr_len, mptr_len = self.get_dptr_mptr_len()
            for i, _lba in enumerate(range(lba, lba + nlb)):
                if mode is None or pattern is None:
                    if _lba not in self._lba_map:
                        LOG.warning('Warning: Skip unknown LBA: 0x%x', _lba)
                        continue
                    _mode, _pattern = self._lba_map[_lba].mode, self._lba_map[_lba].pattern
                else:
                    _mode, _pattern = mode, pattern

                # if printf:
                #     LOG.info('LBA: 0x%x, Mode: %s, Pattern: %s', _lba, _mode, _pattern)
                self._compare(self._rd_data, _lba, _mode, _pattern, start=i * dptr_len, size=dptr_len, dump=dump)
                if meta:
                    self._compare(self._rd_meta, _lba, _mode, _pattern, start=i * mptr_len, size=mptr_len, dump=dump)
        return status

    def get_latency(self, clear=False):
        """
        get latency from pnvme, unit: us
        """
        latency_cutoffs = [0.01, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.98, 0.99, 0.995,
                           0.999, 0.9999, 0.99999, 0.999999, 0.9999999, 0.99999999]
        latency = self.pnvme.get_latency(clear)
        percentiles = list()
        for index, value in enumerate(latency_cutoffs):
            percentiles.append({f"{value}": latency.CUTOFFS[index]})
        latency_dict = {
            "max": latency.MAX,
            "min": latency.MIN,
            "avg": latency.AVG,
            "percentiles": percentiles
        }
        return latency_dict
