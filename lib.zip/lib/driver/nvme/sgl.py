#!/usr/bin/env python
# pylint: disable=too-many-locals,too-many-arguments,superfluous-parens,import-error,invalid-name
"""
Created on 2019/4/26

@author: yyang
"""
import logging
from lib.driver.nvme.struct import *
from lib.driver.utils.buf import *

LOG = logging.getLogger()


class SGL:

    def __init__(self, des_num, wr_flg=1):
        self._des_num = des_num
        self._wr_flg = wr_flg       # use for write or read command, 0: read, 1: write
        self.seg_num = 0
        self.dat_num = 0
        self.bit_num = 0
        self.total_len = 0          # total data length, include bitb
        self._bit_array = []         # list output to mask compare read data
        self._bit_info = {"id": 0,
                         "len": 0,
                         "d_ofs": 0,     # offset of total data before bitb
                         }

        self.data_buff = Malloc(4096)
        self.sgl_segment = Malloc(length=self._des_num, types=SglDescriptorFormat)

    @property
    def buf(self):
        return self.sgl_segment.buf

    @property
    def bit_array(self):
        return self._bit_array

    @property
    def des_num(self):
        return self._des_num

    @property
    def wr_flg(self):
        return self._wr_flg

    @wr_flg.setter
    def wr_flg(self, val):
        self._wr_flg = val & 0x1

    def _reset(self):
        self.seg_num = 0
        self.dat_num = 0
        self.bit_num = 0
        self.total_len = 0
        self._bit_array = []

    def sgl_var_update(self):
        """
        update sgl class variable;
        bitb must be use for Traffic DATA Compare;
        """
        self._reset()
        seg_len = 0
        des_len = 16
        dat_len = 0

        for i in range(self._des_num):
            idx = self._des_num - i - 1
            if self.sgl_segment[idx].sdt in [0x2, 0x3]:
                self.sgl_segment[idx].length = seg_len
                seg_len = des_len
                self.seg_num += 1
            elif self.sgl_segment[idx].sdt == 0x0:
                dat_len += self.sgl_segment[idx].length
                seg_len += des_len
                self.dat_num += self.dat_num
            elif self.sgl_segment[idx].sdt == 0x1:
                if self._wr_flg == 0:
                    dat_len += self.sgl_segment[idx].length
                    # get bitb array para
                    self._bit_info["id"] = idx
                    self._bit_info["len"] = self.sgl_segment[idx].length
                    self._bit_info["d_ofs"] = dat_len
                    self._bit_array.append(self._bit_info)
                seg_len += des_len
                self.bit_num += 1
            else:
                seg_len += des_len
        #cal bitb offset
        self.total_len = dat_len
        for bb in self._bit_array:
            bb["d_ofs"] = self.total_len - bb["d_ofs"]
        self._bit_array.reverse()
        return dat_len

    def set_descriptor(self, index, length, des_type, des_err=0):
        # write descriptor data
        self.sgl_segment[index].length = length
        self.sgl_segment[index].sdt = des_type
        self.sgl_segment[index].dts = des_err

    def seg_len_update(self):
        return self.sgl_var_update()

    def form_sgl(self, size, step=4, mode=0):
        if size == 0:
            raise RuntimeError("[form_sgl] size error!")

        t_len = 0
        for i in range(self._des_num - 1):
            if i == 0:
                des_type = random.randrange(2, 3)
            else:
                des_type = random.randrange(0, 3)

            if des_type == 0x0:
                length = random.randrange(0, size // self._des_num, step)
            elif des_type == 0x1:
                if mode == 0:
                    length = 0
                elif mode == 1:
                    length = random.randrange(0, size // self._des_num, step)
                else:
                    raise RuntimeError("[form_sgl] mode error!")
            else:
                length = 0

            self.set_descriptor(i, length, des_type, des_err=0)
            t_len += length

        self.set_descriptor(self._des_num - 1, size - t_len, 0, 0)

        if self.seg_len_update() != size:
            raise RuntimeError("[form_sgl] length error!")

    def form_rand_sgl(self, size, step=4, mode=0):
        t_len = 0
        mode &= 0x1
        for i in range(0, self._des_num - 1):
            if i == 0:
                des_type = random.randrange(2, 3)
            else:
                des_type = random.randrange(0, 3)

            if des_type == 0x0:
                length = random.randrange(0, size // self._des_num, step)
            elif des_type == 0x1:
                length = 0   # write bitb
                if mode:     # mode=1, read bitb
                    length = random.randrange(0, size // self._des_num, step)
            else:
                length = 0

            self.set_descriptor(i, length, des_type, des_err=0)
            t_len = t_len + length
        #last data block descriptor
        self.set_descriptor(self._des_num - 1, size - t_len, 0, des_err=0)

        if self.seg_len_update() != size:
            raise RuntimeError("[form_rand_sgl] length error[act:%d vs exp:%d]" %
                               (self.seg_len_update(), size))

    def dump_sgl(self):
        self.sgl_segment.dump_uint8()

    def dump_sql_segment(self):
        self.sgl_segment.dump()

    def print_info(self):
        LOG.info("[SGL] seg_num:%d, data_bl_num:%d, bit_bk_num:%d", self.seg_num, self.dat_num, self.bit_num)
