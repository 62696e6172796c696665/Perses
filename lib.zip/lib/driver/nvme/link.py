#!/usr/bin/env python
# coding=utf-8
import os
import time
import logging
import multiprocessing
from lib.driver.nvme import NVMe
from lib.driver.nvme.traffic import LBAOperate
from lib.driver.register.reg_pcie import PCIeReg
from lib.driver.utils.system import execute

quarch_str = os.environ.get('quarch', None)
if quarch_str is not None:
    from quarchpy.device import *
    from quarchpy.disk_test.driveTestCore import executeAndCheckCommand
cnextb_str = os.environ.get('cnextb', None)
if cnextb_str is not None:
    from cnextb.device import *

LOG = logging.getLogger()


class Link:
    def __init__(self, dev=None):
        self.dev = NVMe() if dev is None else dev
        self.max_speed, self.max_width = self.get_max_link_status()
        current_speed = self.get_link_speed()
        self.get_link_width()
        if current_speed != self.max_speed:
            self.set_link_speed(self.max_speed)
        self.old_unco_status, self.old_corr_status = self.get_aer_status()
        self.lock = multiprocessing.Lock()
        self.serial = self.scan_usb_dev()

    def setup(self):
        pass

    def teardown(self):
        pass

    def search_dev(self):
        time.sleep(5)
        self.dev.waiting_device_ready(timeout=120, interval=5)
        return self.dev

    def scan_usb_dev(self):
        if quarch_str is not None:
            return quarchDevice(quarch_str)
        if cnextb_str is not None:
            return CnextbDevice(cnextb_str)
        return None

    def exe_serial_cmd(self, cmd):
        self.lock.acquire()
        try:
            LOG.info("execute cmd:%s", cmd)
            status = executeAndCheckCommand(self.serial, cmd)
            if not status:
                raise RuntimeError('execute serial command %s fail!' % cmd)
        finally:
            self.lock.release()

    def link_status_check(self):
        current_speed = self.get_link_speed()
        current_width = self.get_link_width()
        if current_speed != self.max_speed or current_width != self.max_width:
            raise RuntimeError('link status check fail!')

    def link_width_check(self, width=4):
        current_width = self.get_link_width()
        if current_width != width:
            LOG.info("expect link width: x%x", width)
            raise RuntimeError('link width check fail!')

    def trigger_perst(self):
        LOG.info("trigger perst")
        self.exe_serial_cmd("SIGnal:PERST:DRIVE CLOSED LOW")
        self.exe_serial_cmd("SIGnal:PERST:DRIVE CLOSED NONE")

    def hot_plug_action(self, delay=5):
        LOG.info("do hot plug")
        self.exe_serial_cmd("RUN:POWer DOWN")
        time.sleep(delay)
        self.exe_serial_cmd("RUN:POWer UP")

    def set_signal_source(self, signal, source):
        LOG.info("set signal %s source to %s", signal, source)
        cmd = "signal:" + str(signal) + ":source " + str(source)
        self.exe_serial_cmd(cmd)

    def set_source_delay(self, source, delay):
        LOG.info("set source %s delay to %s ms", source, delay)
        cmd = "source:" + str(source) + ":delay " + str(delay)
        self.exe_serial_cmd(cmd)

    def get_dev_pci_slot(self):
        bdf = os.environ.get('slot')
        cmd = "find /sys/devices/ -name 0000:{}".format(bdf)
        status, output = execute(cmd, console=False, interrupt=False)
        if status:
            time.sleep(1)
            _, output = execute(cmd, console=False)
        if "\n" in output:
            output_list = output.split("\n")
            for output in output_list:
                if "iommu" in output:
                    output_list.remove(output)
                    break
            bdf_list = output_list[0].split("/")
        else:
            bdf_list = output.split("/")
        pci_slot = bdf_list[-2]
        return pci_slot

    def get_pcie_cap_pointer(self, bdf, cap_id):
        pcie = PCIeReg(bdf=bdf)
        pointer = pcie.cfg_space.get_uint8(0x34)
        time1 = time.time()
        while True:
            next_id = pcie.cfg_space.get_uint8(pointer)
            next_point = pcie.cfg_space.get_uint8(pointer + 1)
            if next_id == cap_id:
                break
            pointer = next_point
            time2 = time.time()
            if time2-time1 > 0.001:
                LOG.info("get pcie cap id 0x%x timeout!", cap_id)
                cmd = "lspci -s {} -xxx".format(bdf)
                execute(cmd, console=True, interrupt=False)
                raise RuntimeError('get pcie cap id 0x%x fail!' % cap_id)
        return pcie, pointer

    def get_extend_cap_pointer(self, bdf, cap_id):
        pcie = PCIeReg(bdf=bdf)
        pointer = 0x100
        while True:
            next_id = pcie.cfg_space.get_uint16(pointer)
            next_point = (pcie.cfg_space.get_uint16(pointer + 2) >> 4)
            if next_id == cap_id:
                break
            pointer = next_point
        return pcie, pointer

    def lane_err_status_chk(self, bdf):
        pcie, pointer = self.get_extend_cap_pointer(bdf=bdf, cap_id=0x19)
        bits = (pcie.cfg_space.get_uint32(pointer + 0x8))
        LOG.info("bdf: %s, lane error status register value: 0x%x", bdf, bits)
        if bits != 0:
            raise RuntimeError('lane_err_status check fail!')

    def clear_lane_err(self, bdf):
        pcie, pointer = self.get_extend_cap_pointer(bdf=bdf, cap_id=0x19)
        bits = (pcie.cfg_space.get_uint32(pointer + 0x8))
        LOG.info("bdf: %s, lane error status register value: 0x%x", bdf, bits)
        LOG.info("bdf: %s, clear lane error", bdf)
        pcie.set_pcie_reg(pointer+0x8, 0xffffffff)
        pcie, pointer = self.get_extend_cap_pointer(bdf=bdf, cap_id=0x19)
        bits = (pcie.cfg_space.get_uint32(pointer + 0x8))
        LOG.info("bdf: %s, lane error status register value: 0x%x", bdf, bits)
        if bits != 0:
            raise RuntimeError('lane_err_status check fail!')

    def pcie_secondary_bus_reset(self, rescan=True):
        LOG.info("do SBR")
        bdf = self.get_dev_pci_slot()
        pcie = PCIeReg(bdf=bdf)
        old_val = pcie.cfg_space.get_uint8(0x3e)
        new_val = old_val | 0x40
        pcie.set_pcie_reg(0x3e, new_val)
        time.sleep(1)
        pcie.set_pcie_reg(0x3e, old_val)
        if rescan:
            time.sleep(1)
            cmd = "echo 1 > /sys/bus/pci/devices/{}/rescan".format(bdf)
            status, _ = execute(cmd, console=False, interrupt=False)
            if status:
                time.sleep(1)
                _, _ = execute(cmd, console=False)

    def pcie_function_level_reset(self):
        LOG.info("do FLR")
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        old_val = pcie.cfg_space.get_uint8(pointer + (0x8 + 0x1))
        new_val = old_val | (1 << 7)
        pcie.set_pcie_reg(pointer + (0x8 + 0x1), new_val)
        time.sleep(1)
        pcie.set_pcie_reg(pointer + (0x8 + 0x1), old_val)
        time.sleep(3)

    def pcie_link_disable_enable(self, rescan=True):
        LOG.info("do link disable enable")
        bdf = self.get_dev_pci_slot()
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        old_val = pcie.cfg_space.get_uint8(pointer + 0x10)
        new_val = old_val | 0x10
        pcie.set_pcie_reg(pointer + 0x10, new_val)
        time.sleep(1)
        pcie.set_pcie_reg(pointer + 0x10, old_val)
        if rescan:
            time.sleep(1)
            cmd = "echo 1 > /sys/bus/pci/devices/{}/rescan".format(bdf)
            status, _ = execute(cmd, console=False, interrupt=False)
            if status:
                time.sleep(1)
                _, _ = execute(cmd, console=False)

    def pcie_ref_clock_lost(self):
        LOG.info("do ref clock loss")
        self.set_signal_source("REFCLK0_PL", 0)
        if quarch_str is not None:
            self.set_signal_source("REFCLK0_MN", 0)
        time.sleep(1)
        LOG.info("do ref clock restore")
        self.set_signal_source("REFCLK0_PL", 3)
        if quarch_str is not None:
            self.set_signal_source("REFCLK0_MN", 3)
        time.sleep(8)

    def pcie_link_retrain(self, rescan=True):
        LOG.info("do link retrain")
        bdf = self.get_dev_pci_slot()
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        old_val = pcie.cfg_space.get_uint8(pointer + 0x10)
        new_val = old_val | 0x20
        pcie.set_pcie_reg(pointer + 0x10, new_val)
        if rescan:
            time.sleep(1)
            cmd = "echo 1 > /sys/bus/pci/devices/{}/rescan".format(bdf)
            status, _ = execute(cmd, console=False, interrupt=False)
            if status:
                time.sleep(1)
                _, _ = execute(cmd, console=False)

    def get_slot_mpss(self):
        bdf = self.get_dev_pci_slot()
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        bits = (pcie.cfg_space.get_uint8(pointer + 0x4)) & 0x7
        if bits == 0:
            LOG.info("Support 128 bytes max payload size")
            return bits
        if bits == 0x1:
            LOG.info("Support 256 bytes max payload size")
            return bits
        if bits == 0x2:
            LOG.info("Support 512 bytes max payload size")
            return bits
        if bits == 0x3:
            LOG.info("Support 1024 bytes max payload size")
            return bits
        if bits == 0x4:
            LOG.info("Support 2048 bytes max payload size")
            return bits
        if bits == 0x5:
            LOG.info("Support 4096 bytes max payload size")
            return bits
        raise RuntimeError('Invalid Max_Payload_Size Supported!')

    def set_slot_mps(self, value):
        bdf = self.get_dev_pci_slot()
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        old_val = pcie.cfg_space.get_uint8(pointer + 0x8)
        new_val = (old_val & 0x1f) + (value << 5)
        pcie.set_pcie_reg(pointer + 0x8, new_val)

    def set_dev_mps(self, value):
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        old_val = pcie.cfg_space.get_uint8(pointer + 0x8)
        new_val = (old_val & 0x1f) + (value << 5)
        pcie.set_pcie_reg(pointer + 0x8, new_val)

    def set_dev_mrrs(self, value):
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        old_val = pcie.cfg_space.get_uint8(pointer + 0x9)
        new_val = (old_val & 0x8f) + (value << 4)
        pcie.set_pcie_reg(pointer + 0x9, new_val)

    def set_link_speed(self, speed):
        bdf = self.get_dev_pci_slot()
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        old_val = pcie.cfg_space.get_uint8(pointer + 0x30)
        new_val = (old_val & 0xf0) | speed
        pcie.set_pcie_reg(pointer + 0x30, new_val)

    def get_max_link_status(self):
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        max_speed = (pcie.cfg_space.get_uint8(pointer + 0xc)) & 0xf
        max_width = ((pcie.cfg_space.get_uint8(pointer + 0xc)) >> 4) & 0x3f
        if max_speed == 1:
            LOG.info("max link speed is 2.5GT/s")
        elif max_speed == 2:
            LOG.info("max link speed is 5.0GT/s")
        elif max_speed == 3:
            LOG.info("max link speed is 8.0GT/s")
        elif max_speed == 4:
            LOG.info("max link speed is 16.0GT/s")
        elif max_speed == 5:
            LOG.info("max link speed is 32.0GT/s")
        else:
            LOG.info("max link speed bits is %s", max_speed)
        LOG.info("max link width is x%s", max_width)
        return max_speed, max_width

    def get_link_speed(self):
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        bits = (pcie.cfg_space.get_uint8(pointer + 0x12)) & 0xf
        if bits == 1:
            LOG.info("link speed is 2.5GT/s")
        elif bits == 2:
            LOG.info("link speed is 5.0GT/s")
        elif bits == 3:
            LOG.info("link speed is 8.0GT/s")
        elif bits == 4:
            LOG.info("link speed is 16.0GT/s")
        elif bits == 5:
            LOG.info("link speed is 32.0GT/s")
        else:
            LOG.info("link speed bits is %s", bits)
        return bits

    def get_link_width(self):
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x10)
        bits = (pcie.cfg_space.get_uint8(pointer + 0x12)) & 0x3f0
        bits >>= 4
        LOG.info("link width is x%s", bits)
        return bits

    def get_power_state(self):
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x1)
        bits = (pcie.cfg_space.get_uint8(pointer + 0x4)) & 0x3
        if bits == 0:
            LOG.info("current power state is D0")
        elif bits == 1:
            LOG.info("current power state is D1")
        elif bits == 2:
            LOG.info("current power state is D2")
        elif bits == 3:
            LOG.info("current power state is D3 hot")
        return bits

    def set_power_state(self, state):
        bdf = os.environ.get('slot')
        pcie, pointer = self.get_pcie_cap_pointer(bdf=bdf, cap_id=0x1)
        old_val = pcie.cfg_space.get_uint8(pointer + 0x4)
        new_val = (old_val & 0xfc) + state
        pcie.set_pcie_reg(pointer + 0x4, new_val)

    def get_aer_status(self):
        bdf = os.environ.get('slot')
        pcie = PCIeReg(bdf=bdf)
        offset = 0x100
        while True:
            cap_id = pcie.cfg_space.get_uint16(offset)
            next_cap_off = (pcie.cfg_space.get_uint16(offset + 2) >> 4)
            if cap_id == 0x0001:
                break
            offset = next_cap_off
        unco_err_status = pcie.cfg_space.get_uint32(offset+0x4)
        corr_err_status = pcie.cfg_space.get_uint32(offset+0x10)
        LOG.info("unco_err_status: 0x%x", unco_err_status)
        LOG.info("corr_err_status: 0x%x", corr_err_status)
        return unco_err_status, corr_err_status

    def run_vd(self, size='100g', runt=60, seekpct=0, rdpct=0, thread='128', mode='-v', xfersize=None):
        dev = self.search_dev()
        block_dev = dev.block_dev
        traffic = LBAOperate(dev)
        traffic.run_vdbench_mix(size=size, runt=runt, seekpct=seekpct, rdpct=rdpct, thread=thread, mode=mode,
                                dev=block_dev, xfersize=xfersize)

    def link_add_io(self, action=None, size='100g', runt=60, seekpct=100,
                    rdpct=0, thread='128', mode='-v', io_tag=True):
        if action == 1:
            self.hot_plug_action()
        if action == 2:
            self.trigger_perst()
        if action == 3:
            self.pcie_link_disable_enable()
        if action == 4:
            self.pcie_link_retrain()
        if action == 5:
            self.pcie_secondary_bus_reset()
        if action == 6:
            self.pcie_function_level_reset()
            # after FLR lost device, so add hot-plug to get device
            self.hot_plug_action()
        if action == 7:
            self.dev.subsys_reset()
        dev = self.search_dev()
        if io_tag is True:
            block_dev = dev.block_dev
            traffic = LBAOperate(dev)
            traffic.run_vdbench_mix(size=size, runt=runt, seekpct=seekpct, rdpct=rdpct, thread=thread, mode=mode,
                                    dev=block_dev)

    def link_add_io_16k(self, action=None, size='100g', runt=60, seekpct=0, rdpct=50,
                        thread='128', xfersize=None, mode='-v', io_tag=True):
        if action == 1:
            self.hot_plug_action()
        if action == 2:
            self.trigger_perst()
        if action == 3:
            self.pcie_link_disable_enable()
        if action == 4:
            self.pcie_link_retrain()
        if action == 5:
            self.pcie_secondary_bus_reset()
        if action == 6:
            self.pcie_function_level_reset()
            # after FLR lost device, so add hot-plug to get device
            self.hot_plug_action()
        if action == 7:
            self.dev.subsys_reset()
        dev = self.search_dev()
        if io_tag is True:
            block_dev = dev.block_dev
            traffic = LBAOperate(dev)
            traffic.run_vdbench_mix(size=size, runt=runt, seekpct=seekpct, rdpct=rdpct, thread=thread,
                                    xfersize= xfersize, mode=mode, dev=block_dev)

    def link_when_io(self, action=None, size='100g', runt=60, seekpct=100, rdpct=0, thread='128', mode='-v'):
        process1 = multiprocessing.Process(target=self.run_vd, args=(size, runt, seekpct, rdpct, thread, mode))
        process2 = multiprocessing.Process(target=self.link_add_io, args=(action, size, 30))
        process1.daemon = True
        process2.daemon = True
        process1.start()
        time.sleep(55)
        process2.start()
        process2.join()
        if process2.exitcode:
            raise RuntimeError("link when io test failed")

    def link_when_io_16k(self, action=None, size='100g', runt=60, seekpct=0, rdpct=50, thread='128',
                         xfersize=None, mode='-v'):
        process1 = multiprocessing.Process(target=self.run_vd, args=(size, runt, seekpct, rdpct, thread,
                                                                     mode, xfersize))
        process2 = multiprocessing.Process(target=self.link_add_io, args=(action, size, 30))
        process1.daemon = True
        process2.daemon = True
        process1.start()
        time.sleep(55)
        process2.start()
        process2.join()
        if process2.exitcode:
            raise RuntimeError("link when io test failed")

    def perst_when_reset(self):
        process1 = multiprocessing.Process(target=self.dev.reset)
        process2 = multiprocessing.Process(target=self.trigger_perst())
        process1.daemon = True
        process2.daemon = True
        process1.start()
        time.sleep(1)
        process2.start()
        process2.join()
        if process1.exitcode:
            raise RuntimeError("reset test failed")
        if process2.exitcode:
            raise RuntimeError("perst test failed")

    def driver_state_change(self, action):
        bdf = os.environ.get('slot')
        if action == 'bind':
            status = False
            LOG.info(f"status value is: {status}")
        elif action == 'unbind':
            status = True
            LOG.info(f"status value is: {status}")
        else:
            LOG.info(f"Unrecognized action: {action}")
            return False
        if os.path.exists('/sys/bus/pci/drivers/nvme/0000:' + bdf) == status:
            with open(f'/sys/bus/pci/drivers/nvme/{action}', 'w', encoding='utf-8') as fd:
                if fd.write('0000:' + bdf) != len('0000:' + bdf):
                    LOG.info(f"Error writing to {action} file for {bdf}")
                    return False
                LOG.info(f'Successfully {action} driver for device { bdf}')
        return True
