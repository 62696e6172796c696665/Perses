#!/usr/bin/env python
"""
Created on 3/4/2021

@author: wwang
"""

from lib.driver.nvme import Raven
from lib.driver.nvme.struct.rate_limits import RateLimitEntry
from lib.driver.utils.buf import Malloc
from lib.driver.utils.ctype import Ctype


class RateLimits:

    def __init__(self):
        self.raven = Raven()
        self.data_prt = Malloc(64, RateLimitEntry)
        self.prp = self.data_prt.address


class PFRateLimit(RateLimits):

    def enable_limiter(self, limiter_id=0x1, mask=0x1):
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = limiter_id
        self.data_prt[0].CTRL_MASK[0] = mask
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def disable_limiter(self):
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x1
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def update_limiter_resource(self, iow=0x0014, ior=0x0014, iow_s=0x1500, ior_s=0x1500):
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x1
        self.data_prt[0].IOW_VAL = iow
        self.data_prt[0].IOR_VAL = ior
        self.data_prt[0].IOW_STA = iow_s
        self.data_prt[0].IOR_STA = ior_s
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def add(self):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x1
        self.data_prt[0].IOW_CTR_VAL = 0x0000FFFF
        self.data_prt[0].IOR_CTR_VAL = 0x0000FFFF
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def remove(self):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x1
        self.data_prt[0].IOW_CTR_VAL = 0x80000500
        self.data_prt[0].IOR_CTR_VAL = 0x80000500
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def get_info(self):
        self.raven.rate_limits_rd(self.prp, self.data_prt.size // 4 - 1)
        Ctype(self.data_prt[1]).dump()


class VFRateLimit(RateLimits):

    def enable_limiter(self, limiter_id=0x2, mask=0x2):
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = limiter_id
        self.data_prt[0].CTRL_MASK[0] = mask
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def disable_limiter(self):
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def update_limiter_resource(self, iow=0x0014, ior=0x0014, iow_s=0x1500, ior_s=0x1500):
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.data_prt[0].IOW_VAL = iow
        self.data_prt[0].IOR_VAL = ior
        self.data_prt[0].IOW_STA = iow_s
        self.data_prt[0].IOR_STA = ior_s
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def add(self, limiter_id=0x2):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = limiter_id
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.data_prt[0].IOW_CTR_VAL = 0x0000FFFF
        self.data_prt[0].IOR_CTR_VAL = 0x0000FFFF
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def remove(self, limiter_id=0x2):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = limiter_id
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.data_prt[0].IOW_CTR_VAL = 0x80000500
        self.data_prt[0].IOR_CTR_VAL = 0x80000500
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def get_info(self):
        self.raven.rate_limits_rd(self.prp, self.data_prt.size // 4 - 1)
        Ctype(self.data_prt[2]).dump()


class TVFRateLimit(RateLimits):

    def enable_limiter(self):
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x6
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def disable_limiter(self):
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x6
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def update_limiter_resource(self, iow=0x0014, ior=0x0014, iow_s=0x1500, ior_s=0x1500):
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x6
        self.data_prt[0].IOW_VAL = iow
        self.data_prt[0].IOR_VAL = ior
        self.data_prt[0].IOW_STA = iow_s
        self.data_prt[0].IOR_STA = ior_s
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def add(self):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x6
        self.data_prt[0].IOW_CTR_VAL = 0x0000FFFF
        self.data_prt[0].IOR_CTR_VAL = 0x0000FFFF
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def remove(self):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x6
        self.data_prt[0].IOW_CTR_VAL = 0x80000500
        self.data_prt[0].IOR_CTR_VAL = 0x80000500
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def enable_limiter_diff(self):
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x4
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def disable_limiter_diff(self):
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x4
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def update_limiter_resource_diff(self, iow1=0x0014, ior1=0x0014, iow2=0x0001, ior2=0x0001):
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.data_prt[0].IOW_VAL = iow1
        self.data_prt[0].IOR_VAL = ior1
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x4
        self.data_prt[0].IOW_VAL = iow2
        self.data_prt[0].IOR_VAL = ior2
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def get_info(self):
        self.raven.rate_limits_rd(self.prp, self.data_prt.size // 4 - 1)
        Ctype(self.data_prt[3]).dump()


class PTVFRateLimit(RateLimits):

    def enable_limiter(self):
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x7
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def disable_limiter(self):
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x7
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def update_limiter_resource(self):
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x7
        self.data_prt[0].IOW_VAL = 0x0014
        self.data_prt[0].IOR_VAL = 0x0014
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def add(self):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x7
        self.data_prt[0].IOW_CTR_VAL = 0x0000FFFF
        self.data_prt[0].IOR_CTR_VAL = 0x0000FFFF
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def remove(self):
        self.data_prt[0].LIMITER_OP = 0x5
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x7
        self.data_prt[0].IOW_CTR_VAL = 0x80000500
        self.data_prt[0].IOR_CTR_VAL = 0x80000500
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def enable_limiter_diff(self):
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x1
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x1
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x4
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def disable_limiter_diff(self):
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x1
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x2
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x4
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)

    def update_limiter_resource_diff(
            self, iow1=0x0014, ior1=0x0014, iow2=0x0001, ior2=0x0001, iow3=0x0010, ior3=0x0010):
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x1
        self.data_prt[0].CTRL_MASK[0] = 0x1
        self.data_prt[0].IOW_VAL = iow1
        self.data_prt[0].IOR_VAL = ior1
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x2
        self.data_prt[0].CTRL_MASK[0] = 0x2
        self.data_prt[0].IOW_VAL = iow2
        self.data_prt[0].IOR_VAL = ior2
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
        self.data_prt[0].LIMITER_OP = 0x3
        self.data_prt[0].LIMITER_ID = 0x3
        self.data_prt[0].CTRL_MASK[0] = 0x4
        self.data_prt[0].IOW_VAL = iow3
        self.data_prt[0].IOR_VAL = ior3
        self.raven.rate_limits_wr(self.prp, self.data_prt.size // 4 - 1)
