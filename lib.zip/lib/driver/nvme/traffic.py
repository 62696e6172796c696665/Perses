#!/usr/bin/env python
# pylint: disable=too-many-branches,invalid-name,too-many-locals
import collections
import logging
import random
import shutil
import time
import os

from lib.driver.nvme import Tahoe
from lib.driver.nvme.struct import DatasetManagementEntry, CopyDescriptorFormat0h, CopyDescriptorFormat1h
from lib.driver.register import reg_model_nvm_14
from lib.driver.utils import buf, system
from lib.tool.fio.fio_linux import Fio
from lib.tool.vdbench import Vdbench

LOG = logging.getLogger()


class LBAOperate:
    def __init__(self, dev=None, cntid=0, nsid=1):
        if dev is None:
            self.dev = Tahoe(cntid=cntid, nsid=nsid)
            self.nsid = nsid
            self.cntid = cntid
        else:
            self.dev = dev
            self.nsid = self.dev.nsid
            self.cntid = self.dev.cntid

        self.prinfo = 0
        self.dtype = 0
        self.deac = 0
        self.dspec = 0
        self.reftag = 0
        self.apptag = 0
        self.appmask = 0
        self.ctrl = 0
        self.flags = 0

        self._lba = collections.namedtuple('lba', 'mode pattern')
        self._lba_map = {}
        self._rd_data = None
        self._rd_meta = None
        self._wt_data = None
        self._wt_meta = None

        self.reset_map()
        self.reset_mode()

    @property
    def pcie(self):
        return self.dev.pcie

    @property
    def block_dev(self):
        return self.dev.block_dev

    @property
    def id_ctrl(self):
        return self.dev.id_ctrl

    @property
    def id_ns(self):
        return self.dev.id_ns

    @property
    def data_size(self):
        return self.dev.lbads

    @property
    def meta_size(self):
        return self.dev.lbams

    @property
    def max_lba(self):
        return self.dev.max_lba

    @property
    def lbaf_list(self):
        return self.dev.lbaf_list

    @property
    def is_dif(self):
        return bool(self.dev.is_dif)

    @property
    def pi_type(self):
        return self.id_ns.DPS & 0x7

    @property
    def pi_pil(self):
        return (self.id_ns.DPS >> 3) & 0x1

    @property
    def dlb_val(self):
        return self.id_ns.DLFEAT & 0x7

    @property
    def dlb_bit(self):
        return (self.id_ns.DLFEAT >> 3) & 0x1

    @property
    def dlb_gud(self):
        return (self.id_ns.DLFEAT >> 4) & 0x1

    @property
    def mpsmin(self):
        return (self.pcie.uint32(0x4) >> 16) & 0xF  # Memory Page Size Minimum

    @property
    def vu_cmd(self):
        return self.dev.vu_cmd

    def args_to_str(self, **kwargs):
        return self.dev.args_to_str(**kwargs)

    @staticmethod
    def exc_cmd(cmd):
        LOG.info(cmd)
        status, text = system.execute(cmd, cmdline=False, console=False)
        assert status == 0, "{} failed!\n{}".format(cmd, text)

    def get_vss(self):
        return self.data_size, self.meta_size

    def get_max_nlb(self, pract=0):
        if self.id_ctrl.MDTS == 0:
            # A value of 0h indicates that there is no maximum data transfer size.
            return 0x10000

        if self.is_dif:
            ## Data Integrity Field(DIF)
            if pract and self.meta_size == 8:
                # Protection Information Action (PRACT):
                # The protection information is stripped (read) or inserted (write).
                lba_size = self.data_size
            else:
                # The protection information is passed (read and write)
                lba_size = self.data_size + self.meta_size
        else:
            # Data Integrity Extensions(DIX)
            lba_size = self.data_size

        return ((2 ** (12 + self.mpsmin)) * (2 ** self.id_ctrl.MDTS)) // lba_size

    def get_valid_lbaf(self):
        return [i for i, lbaf in enumerate(self.id_ns.LBAF) if lbaf.LBADS]

    def get_dptr_mptr_len(self):
        if self.is_dif:
            # Data Integrity Field(DIF)
            return self.data_size + self.meta_size, 0
        # Data Integrity Extensions(DIX)
        return self.data_size, self.meta_size

    def _update_map(self, lba, nlb=1, mode=0, pattern=0):
        for i in range(lba, lba + nlb):
            self._lba_map[i] = self._lba(mode=mode, pattern=pattern)

    def _insert_pi(self, nlb, data, meta, bypass=0, read_trim=False, compare=False):
        """
        :param nlb: number of logic block
        :param data: data buffer
        :param meta: meta buffer
        :param bypass: controller of error inject on PI filed
        :param read_trim: the PI use to compare trimed LBA, True: Trimed LBA; False: no trimed LBA
        :param compare: True: PI is ueed to compare, False:, PI is used in write command
        :return:
        """
        if not self.pi_type:
            # LOG.info('PI not Enable, no insert PI..........')
            return
        if (self.prinfo >> 3) & 0x1 and compare is False:
            # LOG.info('PRACT = 1, NVS Controller will insert PI..........')
            return
        dptr_len, mptr_len = self.get_dptr_mptr_len()
        for i in range(nlb):
            # insert PI on "meta on DIX" or "data on DIF"
            data_tmp = bytearray(data[dptr_len * i:dptr_len * i + self.data_size])
            if not self.pi_pil:
                if self.id_ns.FLBAS & 0x10:
                    data_tmp += bytearray(data[dptr_len * i + self.data_size:(dptr_len * (i + 1) - 8)])
                else:
                    data_tmp += bytearray(meta[mptr_len * i:(mptr_len * (i + 1) - 8)])
            # calc PI field
            if read_trim:
                guard = 0xffff
                if self.dlb_gud:
                    guard = self.calc_crc(data_tmp)
                app_val = 0xffff
                ref_val = 0xffffffff
            else:
                guard = self.calc_crc(data_tmp)
                app_val = self.apptag & self.appmask
                ref_val = self.reftag
                if self.pi_type in [1, 2]:
                    ref_val += i
                if bypass:
                    if (bypass >> 2) & 0x1:
                        guard += 3
                    if (bypass >> 1) & 0x1:
                        app_val += 3
                    if bypass & 0x1:
                        ref_val = 0xa5a55a
            pi_val = self.pi_byte_change(guard, app_val, ref_val)
            # insert PI to relate buffer
            if self.id_ns.FLBAS & 0x10:
                if self.pi_pil:
                    data.set_uint64(dptr_len * i + self.data_size, pi_val)
                else:
                    data.set_uint64(dptr_len * (i + 1) - 8, pi_val)
            else:
                if self.pi_pil:
                    meta.set_uint64(mptr_len * i, pi_val)
                else:
                    meta.set_uint64(mptr_len * (i + 1) - 8, pi_val)

    def _malloc_data_meta(self, nlb, mode=None, pattern=None, bypass=0, fixed=False, read_trim=False, compare=False):
        dptr_len, mptr_len = self.get_dptr_mptr_len()
        data = buf.Malloc(dptr_len * nlb)
        meta = buf.Malloc(mptr_len * nlb)

        # The protection information is stripped (read) or inserted(write)
        if self.meta_size == 8 and self.prinfo & 0x8 and self.id_ns.DPS & 0x3:
            dptr_len = self.data_size

        if mode is not None and pattern is not None:
            for i in range(nlb):
                _pattern = pattern if fixed is True else pattern + i
                data.fill_uint32(mode, _pattern, i * dptr_len, dptr_len)
                if meta.size > 0:
                    meta.fill_uint32(mode, _pattern, i * mptr_len, mptr_len)
            # insert PI
            self._insert_pi(nlb, data, meta, bypass=bypass, read_trim=read_trim, compare=compare)
        return data, meta

    def _malloc_read_buffer(self, nlb):
        self._rd_data, self._rd_meta = self._malloc_data_meta(nlb)

    def _malloc_write_buffer(self, lba, nlb, mode, pattern, bypass=0, fixed=False):
        pattern = pattern if fixed is True else pattern + lba
        self._wt_data, self._wt_meta = self._malloc_data_meta(nlb, mode, pattern, bypass, fixed=fixed)

    @staticmethod
    def _compare(buff, lba, mode, pattern, start=0, size=0, dump=False):
        if buff.len > 0:
            _pattern = pattern + lba
            count = buff.compare_uint32(mode, _pattern, start, size)
            if count:
                if dump:
                    buff.diff_uint32(mode, _pattern, start, size)
                    buff.dump_uint32(start=start, size=size)
                raise AssertionError("Compare LBA: {:#x}, mode: {:#x}, pattern: {:#x} miscompare!".format(lba, mode, pattern))

    def _compare_data(self, lba, start=0, size=0, dump=True):
        if self._wt_data.compare(self._rd_data, src_start=start, src_size=size):
            if dump:
                self._wt_data.dump_diff(self._rd_data, src_start=start, src_size=size)
            raise AssertionError("Compare LBA: {:#x} size: {:#x}, data miscompare!".format(lba, size))

    def _compare_meta(self, lba, start=0, size=0, dump=True):
        if self._wt_meta.compare(self._rd_meta, src_start=start, src_size=size):
            if dump:
                self._wt_meta.dump_diff(self._rd_meta, src_start=start, src_size=size)
            raise AssertionError("Compare LBA: {:#x} size: {:#x}, meta miscompare!".format(lba, size))

    def reset(self):
        self.reset_mode()
        self.reset_map()
        self.dev.scan_devices()

    def reset_mode(self):
        self.prinfo = 0
        self.dtype = 0
        self.dspec = 0
        self.reftag = 0
        self.apptag = 0
        self.appmask = 0
        self.deac = 0
        self.flags = 0x80
        self.ctrl = 0

    def reset_map(self):
        self._lba_map = {}

    def set_mode(self, **kwargs):
        for key, val in kwargs.items():
            setattr(self, key, val)

    def fw_update(self, file, action, slot=0, xfer=0x1000):
        stime = time.time()
        self.dev.fw_download(file, xfer)

        mtime = time.time()
        if action in [0x0, 0x2]:
            self.dev.fw_commit(ca=0, fs=slot)
            self.dev.fw_commit(ca=2, fs=slot)
        else:
            self.dev.fw_commit(ca=action, fs=slot)
        etime = time.time()
        time.sleep(2)
        if action in [0x0, 0x1, 0x2]:
            self.dev.reset()

        LOG.info('FW Upgrade Succeed, Download: %.3fs, Commit: %.3fs', mtime - stime, etime - mtime)

        if slot != 0:
            fw_slot_info = self.dev.get_log_fw_slot_info()
            assert fw_slot_info.AFI == slot, 'SLOT{:#x} != AFI{:#x}'.format(slot, fw_slot_info.AFI)

    def flush(self, nsid=None, **kwargs):
        LOG.info('Write Flush %s', self.args_to_str(nsid=nsid, **kwargs))
        self.dev.flush(nsid=nsid, **kwargs)

    def write_unco(self, lba, nlb, printf=True, **kwargs):
        if printf:
            LOG.info('Write Uncorrectable %s', self.args_to_str(lba=lba, nlb=nlb, **kwargs))
        self.dev.write_uncorrectable(lba, nlb, **kwargs)

    def write_zeroes(self, lba, nlb, update_map=True, printf=True, **kwargs):
        if printf:
            LOG.info("Write Zeroes %s", self.args_to_str(lba=lba, nlb=nlb, **kwargs))

        self.dev.write_zeroes(lba, nlb, deac=self.deac, prinfo=self.prinfo,
                              reftag=self.reftag, apptag=self.apptag, appmask=self.appmask, **kwargs)
        #self._update_map(lba, nlb=nlb, mode=0, pattern=0)
        if update_map:
            for i in range(lba, lba + nlb):
                self._lba_map[i] = self._lba(mode=0, pattern=0-i)

    def write_sync(self, lba, nlb, mode=0, pattern=0, bypass=0, printf=True, **kwargs):
        if printf:
            LOG.info('Write Sync %s', self.args_to_str(lba=lba, nlb=nlb, mode=mode, pattern=pattern, **kwargs))

        self._malloc_write_buffer(lba, nlb, mode, pattern, bypass)
        status = self.dev.write(lba, nlb, self._wt_data.buf, self._wt_meta.buf, prinfo=self.prinfo, dtype=self.dtype,
                       dspec=self.dspec, reftag=self.reftag, apptag=self.apptag, appmask=self.appmask, **kwargs)
        if not status:
            self._update_map(lba, nlb=nlb, mode=mode, pattern=pattern)
        return status

    def read_sync(self, lba, nlb, mode=None, pattern=None, meta=True, compare=True, printf=True, dump=True, **kwargs):
        if printf:
            LOG.info("Read Sync %s", self.args_to_str(lba=lba, nlb=nlb, mode=mode, pattern=pattern, compare=compare, **kwargs))

        self._malloc_read_buffer(nlb)
        status = self.dev.read(lba, nlb, self._rd_data.buf, self._rd_meta.buf, prinfo=self.prinfo,
                               reftag=self.reftag, apptag=self.apptag, appmask=self.appmask, **kwargs)

        if not status and compare:
            dptr_len, mptr_len = self.get_dptr_mptr_len()
            for i, _lba in enumerate(range(lba, lba + nlb)):
                if mode is None or pattern is None:
                    if _lba not in self._lba_map:
                        LOG.warning('Warning: Skip unknown LBA: 0x%x', _lba)
                        continue
                    _mode, _pattern = self._lba_map[_lba].mode, self._lba_map[_lba].pattern
                else:
                    _mode, _pattern = mode, pattern

                # if printf:
                #     LOG.info('LBA: 0x%x, Mode: %s, Pattern: %s', _lba, _mode, _pattern)
                if (meta is False) and self.is_dif:
                    self._compare(self._rd_data, _lba, _mode, _pattern, start=i * dptr_len, size=(dptr_len - self.meta_size), dump=dump)
                else:
                    self._compare(self._rd_data, _lba, _mode, _pattern, start=i * dptr_len, size=dptr_len, dump=dump)
                if meta:
                    self._compare(self._rd_meta, _lba, _mode, _pattern, start=i * mptr_len, size=mptr_len, dump=dump)
        return status

    def write_passthru(self, lba, nlb, mode=0, pattern=0, bypass=0, printf=True, **kwargs):
        if printf:
            LOG.info('Write Passthru %s', self.args_to_str(lba=lba, nlb=nlb, mode=mode, pattern=pattern, **kwargs))

        self._malloc_write_buffer(lba, nlb, mode, pattern, bypass)
        status = self.dev.write_passthru(lba, nlb, self._wt_data.buf, self._wt_meta.buf, prinfo=self.prinfo, dtype=self.dtype,
                       dspec=self.dspec, ilbrt=self.reftag, lbat=self.apptag, lbatm=self.appmask, **kwargs)
        if not status:
            self._update_map(lba, nlb=nlb, mode=mode, pattern=pattern)
        return status

    def read_passthru(self, lba, nlb, mode=None, pattern=None, meta=True, compare=True, printf=True, dump=True, **kwargs):
        if printf:
            LOG.info("Read Passthru %s", self.args_to_str(lba=lba, nlb=nlb, mode=mode, pattern=pattern,
                                                          compare=compare, **kwargs))

        self._malloc_read_buffer(nlb)
        status = self.dev.write_passthru(lba, nlb, self._rd_data.buf, self._rd_meta.buf, prinfo=self.prinfo,
                               ilbrt=self.reftag, lbat=self.apptag, lbatm=self.appmask, **kwargs)

        if not status and compare:
            dptr_len, mptr_len = self.get_dptr_mptr_len()
            for i, _lba in enumerate(range(lba, lba + nlb)):
                if mode is None or pattern is None:
                    if _lba not in self._lba_map:
                        LOG.warning('Warning: Skip unknown LBA: 0x%x', _lba)
                        continue
                    _mode, _pattern = self._lba_map[_lba].mode, self._lba_map[_lba].pattern
                else:
                    _mode, _pattern = mode, pattern

                self._compare(self._rd_data, _lba, _mode, _pattern, start=i * dptr_len, size=dptr_len, dump=dump)
                if meta:
                    self._compare(self._rd_meta, _lba, _mode, _pattern, start=i * mptr_len, size=mptr_len, dump=dump)
        return status

    def read_pi_sync(self, lba, nlb, mode=0, pattern=0, meta=True, compare=True, printf=True, dump=True,
                     **kwargs):
        if printf:
            LOG.info("Read LBA with PI %s", self.args_to_str(lba=lba, nlb=nlb, mode=mode,
                                                             pattern=pattern, compare=compare))
        self._malloc_read_buffer(nlb)
        status = self.dev.read(lba, nlb, self._rd_data.buf, self._rd_meta.buf, prinfo=self.prinfo,
                      reftag=self.reftag, apptag=self.apptag, appmask=self.appmask, **kwargs)

        if not status and compare:
            dptr_len, mptr_len = self.get_dptr_mptr_len()
            self._malloc_write_buffer(lba, nlb, mode, pattern)
            self._compare_data(lba, start=0, size=dptr_len * nlb, dump=dump)
            if meta:
                self._compare_meta(lba, start=0, size=mptr_len * nlb, dump=dump)

    def verify_pi_sync(self, lba, nlb, mode=0, pattern=0, printf=True, **kwargs):
        if printf:
            LOG.info("Read LBA with PI %s", self.args_to_str(lba=lba, nlb=nlb, mode=mode,
                                                             pattern=pattern))
        return self.dev.verify(lba, nlb, eilbrt=self.reftag, elbat=self.apptag, elbatm=self.appmask, **kwargs)

    def read_zeroes(self, lba, nlb, dlct=False, compare=True, printf=True, dump=True, **kwargs):
        # will not handle write zero pract=0 ......
        if printf:
            LOG.info("Read Zeroes %s", self.args_to_str(lba=lba, nlb=nlb, **kwargs))

        if self.dlb_bit & dlct:
            self.read_invalid(lba, nlb, compare=compare, printf=printf, dump=dump, **kwargs)
            return

        self._malloc_read_buffer(nlb)
        self.dev.read(lba, nlb, self._rd_data.buf, self._rd_meta.buf, prinfo=self.prinfo,
                      reftag=self.reftag, apptag=self.apptag, appmask=self.appmask, **kwargs)

        if compare:
            pattern = 0
            self._wt_data, self._wt_meta = self._malloc_data_meta(nlb, mode=0, pattern=pattern, fixed=True, compare=True)

            dptr_len, mptr_len = self.get_dptr_mptr_len()
            self._compare_data(lba, start=0, size=dptr_len * nlb, dump=dump)
            if not mptr_len:
                self._compare_meta(lba, start=0, size=mptr_len * nlb, dump=dump)

    def read_invalid(self, lba, nlb, compare=True, printf=True, dump=True, **kwargs):
        if printf:
            LOG.info("Read Invalid %s", self.args_to_str(lba=lba, nlb=nlb, compare=compare, **kwargs))

        self._malloc_read_buffer(nlb)
        self.dev.read(lba, nlb, self._rd_data.buf, self._rd_meta.buf, prinfo=self.prinfo,
                      reftag=self.reftag, apptag=self.apptag, appmask=self.appmask, **kwargs)

        if compare:
            pattern = 0
            if self.dlb_val == 2:
                pattern = 0xffffffff
            self._wt_data, self._wt_meta = self._malloc_data_meta(nlb, mode=0, pattern=pattern, fixed=True,
                                                                  read_trim=True, compare=True)

            dptr_len, mptr_len = self.get_dptr_mptr_len()
            self._compare_data(lba, start=0, size=dptr_len * nlb, dump=dump)
            if not mptr_len:
                self._compare_meta(lba, start=0, size=mptr_len * nlb, dump=dump)

    def read_sync_all(self, compare=True, printf=True, dump=True,nlb=1):
        for lba in self._lba_map:
            self.read_sync(lba, nlb, compare=compare, printf=printf, dump=dump)

    def _get_pattern(self):
        id_ns = self.dev.identify_ns(self.nsid)
        dlfeat = id_ns.DLFEAT
        if dlfeat & 0x7 == 1:
            return 0
        if dlfeat & 0x7 == 2:
            return 0xffffffff
        raise AssertionError("Invalid dlfeat: {:#x}".format(dlfeat))

    def dataset(self, range_num, slba, range_length, mode=0, ad=1, af=0, al=0, sr=0, sw=0,
                wp=0, cas=0, rsv0=0, rsv1=0, chk_flg=False, printf=True, **kwargs):
        assert range_num != 0, 'range num can not be set to 0'
        if printf:
            LOG.info("Dataset %s", self.args_to_str(ranges=range_num, lba=slba, length=range_length,
                                                    mode=mode, **kwargs))
        range_buf = buf.Malloc(range_num, DatasetManagementEntry)
        for i in range(range_num):
            _slba = slba + i * range_length
            if (mode == 1) & (i % 2 == 1):
                nlb = range_length + 1
            else:
                nlb = range_length

            range_buf[i].SLBA = _slba
            range_buf[i].LENGTH = nlb
            range_buf[i].DMCA.AF = af
            range_buf[i].DMCA.AL = al
            range_buf[i].DMCA.RSV0 = rsv0
            range_buf[i].DMCA.SR = sr
            range_buf[i].DMCA.SW = sw
            range_buf[i].DMCA.WP = wp
            range_buf[i].DMCA.RSV1 = rsv1
            range_buf[i].DMCA.CAS = cas
            if chk_flg:
                self._update_map(_slba, nlb, mode=0, pattern=self._get_pattern())
        return self.dev.dataset_management(range_num, range_buf.buf, ad=ad, **kwargs)

    def fill_driver(self, dev=None, interval=60):
        # vd_obj = Vdbench(dev)
        # vd_obj.set_parm('threads', 32)
        # vd_obj.set_parm("range", "(0,100)")
        # vd_obj.set_parm('xfersize', '128k')
        # vd_obj.set_parm('rdpct', 0)
        # vd_obj.set_parm('seekpct', 0)
        # vd_obj.set_parm('elapsed', 1200)
        # vd_obj.set_parm('interval', interval)
        # vd_obj.start()
        if dev is None:
            dev = self.dev.block_dev
        fio_obj = Fio()
        fio_obj.set_parm("rw", "write")
        fio_obj.set_parm("bs", "256k")
        fio_obj.set_parm("size", "100%")
        fio_obj.set_parm("numjobs", 1)
        fio_obj.set_parm("iodepth", 32)
        fio_obj.set_parm("ioengine", "libaio")
        fio_obj.set_parm('time_based', '0')
        fio_obj.set_parm('continue_on_error', 'none')
        fio_obj.set_parm('name', 'test')
        fio_obj.set_parm('eta-newline', "1")
        fio_obj.start(filename=dev)

    def init_vd(self, size=0, runt=60, seekpct=100, rdpct=0, thread='32', \
                dev=None, rang=None, interval=None, xfersize=None):
        vd_obj = Vdbench(dev)
        vd_obj.set_parm('threads', thread)
        if not rang:
            if size in [0, "0"]:
                vd_obj.set_parm('range', '(0,100)')
            else:
                vd_obj.set_parm('size', size)
        else:
            vd_obj.set_parm('range', rang)
        if xfersize is None:
            if self.data_size == 4096:
                vd_obj.set_parm('xfersize', '(4k,10,16k,10,64k,10,128k,10,256k,20,512k,20,1m,20)')
            else:
                vd_obj.set_parm('xfersize', '(512,10,2k,10,4k,10,64k,10,127k,20,256k,20,1m,20)')
        else:
            vd_obj.set_parm('xfersize', xfersize)
        vd_obj.set_parm('rdpct', rdpct)
        vd_obj.set_parm('jvms', 1)
        vd_obj.set_parm('seekpct', seekpct)
        vd_obj.set_parm('elapsed', runt)
        vd_obj.set_parm('interval', interval)
        return vd_obj

    def run_vdbench_mix(self, size=0, runt=60, seekpct=100, rdpct=0, thread='32', mode='-v', dev=None,
                        interrupt=True, rang=None, interval=None, xfersize=None):
        bs = self.data_size
        if dev is None:
            dev = self.block_dev
        name = os.path.basename(dev[0]) if isinstance(dev, list) else os.path.basename(dev)
        temp_dir = os.path.join(os.path.curdir, 'ramdisk', system.get_ip_address(), name)

        LOG.info("Run vdbench test, BS: %d", bs)
        vd_obj = self.init_vd(size, runt, seekpct, rdpct, thread, dev,
                        rang, interval, xfersize)

        if mode in ['-jnr', '-jro']:
            assert os.path.exists(temp_dir), f'Temp dir {temp_dir} is not exists!'
            LOG.info(f"Deleted contents of {vd_obj.journal}")
            shutil.rmtree(vd_obj.journal)
            LOG.info(f"Copied contents from {temp_dir} to {vd_obj.journal}")
            shutil.copytree(temp_dir, vd_obj.journal)
            LOG.info(f"Deleted temporary directory {temp_dir}")
            shutil.rmtree(temp_dir)

        vd_obj.start(mode, interrupt=interrupt)

        if mode in ['-jn']:
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
            else:
                LOG.info(f"Directory {temp_dir} already exists.")

            LOG.info(f"Deleted temporary directory {temp_dir}")
            shutil.rmtree(temp_dir)

            LOG.info(f"Copied contents from {vd_obj.journal} to {temp_dir}")
            shutil.copytree(vd_obj.journal, temp_dir)
            os.system("sync")

    def send_sanitize(self):
        is_support = (self.id_ctrl.SANICAP >> 1) & 0x1
        if is_support == 0:
            LOG.info("1. Send Block Erase Sanitize Command")
            self.dev.sanitize(sanact=0x2, status=0x2)
        else:
            timeout = self.dev.get_log_sanitize_status().ETFBE
            LOG.info("1. Send Block Erase Sanitize Command, Timeout: %s", timeout)
            self.dev.sanitize(sanact=0x2)

            time_start = time.time()
            while time.time() < time_start + timeout:
                time.sleep(5)
                temp = self.dev.get_log_sanitize_status()
                act_status = temp.SSTAT & 0x7
                LOG.info("2. Get Sanitize Status, SSTAT: 0x%x", act_status)
                if act_status == 0x1:
                    LOG.info("3. Sanitize Complete! Elapsed: %ds", time.time() - time_start)
                    return
            raise RuntimeError("3. Sanitize Timeout!")

    def format(self, lbaf, mset=0, ses=0, pif=0, pil=0):
        self.dev.format(lbaf=lbaf, mset=mset, pif=pif, pil=pil, ses=ses)
        self.reset()

    def format_as(self, lbads=512, metads=0, **kwargs):
        self.dev.format_as(lbads=lbads, metads=metads, **kwargs)
        self.reset()

    def shn_power_cycle(self, loop=1, ptype=0x1):
        regr = reg_model_nvm_14.nvm_reg_model(self.dev.char_dev)
        for _ in range(loop):
            shst = 0
            regr.write(ptype, "CC", "SHN")
            shn = regr.read("CC", "SHN")
            while shst != 0x2:
                time.sleep(1)
                shst = regr.read("CSTS", "SHST")
                LOG.info("Shutdown[note: 0x%x, status: 0x%x]", shn, shst)
            ret = self.dev.reset()
            if ret:
                raise RuntimeError("Controller reset failed!")
            time.sleep(1)

    def sync_io(self, slba, mlba, rdpct, b_rand, count):
        lba = slba
        cnt = 0
        mode = 0
        dat_pat = 0
        nlb = 1
        while cnt < count:
            if b_rand:
                lba = random.randrange(slba, mlba)
            else:
                nlb = 0
                lba = lba + nlb
                if lba >= mlba:
                    lba = slba
                dat_pat = lba + cnt
            is_read = (random.randrange(0, 100) % 100 < rdpct)

            if is_read == 1:
                self.read_sync(lba, nlb)
            else:
                self.write_sync(lba, nlb, mode, dat_pat)
            # break
            cnt = cnt + 1

    @staticmethod
    def calc_crc(frame, invert=0):
    # def calc_crc(frame, offset, length, invert=0):
        poly = 0x8BB7
        poly_length = 16
        crc_gen = 0x0000
        if invert:
            crc_gen ^= 0xFFFF
        else:
            crc_gen ^= 0x0000

        # for i in range(offset, offset + length, 2):
        for i in range(0, len(frame), 2):
            xxx = (frame[i] << 8) | frame[i + 1]
            for _ in range(0, poly_length):
                fbb = ((xxx & 0x8000) == 0x8000) ^ ((crc_gen & 0x8000) == 0x8000)
                xxx = (xxx << 1) & 0xffff
                crc_gen = (crc_gen << 1) & 0xffff
                if fbb:
                    crc_gen ^= poly
        if invert:
            crc_gen ^= 0xFFFF
        else:
            crc_gen ^= 0x0000
        return crc_gen

    @staticmethod
    def pi_byte_change(guard, apptag, reftag):
        # LOG.info("guard :0x%x, apptag: 0x%x, reftag: 0x%x" % (guard, apptag, reftag))
        pi_g = ((guard & 0xff) << 8) + (guard >> 8)
        # app_m = apptag >> 16
        # app_v = apptag & 0xffff
        # app_v = app_v & app_m
        app_v = apptag
        pi_a = ((app_v & 0xff) << 8) + (app_v >> 8)
        pi_r = ((reftag & 0xff) << 24) + (((reftag >> 8) & 0xff) << 16) + \
               (((reftag >> 16) & 0xff) << 8) + ((reftag >> 24) & 0xff)
        return (pi_r << 32) + (pi_a << 16) + pi_g


    def copy(self, sdlba, copyfmt, range_num, range_slba, range_length, mode=0, status=0, chk_flg=False):
        assert range_num != 0, 'range num can not be set to 0'
        copyfmt = CopyDescriptorFormat0h if copyfmt == 0 else CopyDescriptorFormat1h
        range_buf = buf.Malloc(range_num, copyfmt)
        for i in range(range_num):
            _slba = range_slba + i * range_length
            if (mode == 1) & (i % 2 == 1):
                nlb = range_length + 1
            else:
                nlb = range_length

            range_buf[i].SLBA = _slba
            range_buf[i].LENGTH = nlb
            if chk_flg:
                self._update_map(_slba, nlb, mode=0, pattern=self._get_pattern())
        return self.dev.copy(sdlba, range_num, copyfmt, range_buf.buf, self.nsid, status)

    def copy_by_list(self, sdlba, copyfmt, range_list, status, chk_flg=False):
        """
        eg: range_list = [{ "slba":0x46134，"nlb":1}]
        """
        descfmt = CopyDescriptorFormat0h if copyfmt == 0 else CopyDescriptorFormat1h
        range_num = len(range_list)
        range_buf = buf.Malloc(range_num, descfmt)
        for index, item in enumerate(range_list):
            slba = item['slba']
            nlb = item['nlb']
            range_buf[index].SLBA = slba
            range_buf[index].LENGTH = nlb
            if chk_flg:
                self._update_map(slba, nlb, mode=0, pattern=self._get_pattern())
        return self.dev.copy(sdlba, range_num, copyfmt, range_buf.buf, self.nsid, status)
