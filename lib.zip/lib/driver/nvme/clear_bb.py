#!/usr/bin/env python
import os
import time
import math
import logging
import random
from ctypes import c_uint32

from lib.driver.nvme import NVMe, Tahoe
from lib.driver.nvme.utility_vu import TahoeVU, BLKSTAT
from lib.driver.nvme.traffic import LBAOperate
from lib.driver.nvme.struct.memory import *
from lib.driver.utils.ctype import Ctype
from lib.driver.nvme.link import Link


LOG = logging.getLogger()

BLOCK_STATE = {
    0x00: "FREE",
    0x01: "OPEN",
    0X02: "CLOSE",
    0X06: "RECYCLE",
    0X03: "ERASE",
    0X07: "PROTECT"
}

class ClearBB:

    nor_bb_log_address = 0xc80000
    nor_bb_log_max_size = 512 * 1024
    nor_bb_invalid_value = 0xffffffff

    def __init__(self, nvme=None, vendor=None, traffic=None):
        self.mode = os.environ.get('mode', 'fw')
        self.nvme = NVMe() if nvme is None else nvme
        self.vu = TahoeVU(self.nvme) if vendor is None else vendor
        self.traffic = LBAOperate(self.nvme) if traffic is None else traffic
        self.devconfig = self.vu.get_device_config()
        self.orig_bmi_list = self.get_bmi_list()
        self.orig_nor_buf = self.read_nor()
        self.vpc = 0

    def clear_bb(self):
        LOG.info('Clear bb start...')
        self.nvme.scan_devices()
        self.traffic.reset()
        self.traffic.send_sanitize()
        current_nor_buf = self.read_nor()
        self.clear_nor(current_nor_buf)
        if (os.environ.get('quarch', None) is not None) or \
                (os.environ.get('cnextb', None) is not None):
            self.do_mcp()
        else:
            raise AssertionError("Need to do mcp to clear bb")

    def clear_bb_old(self):
        LOG.info('Clear bb start...')
        self.vpc = self.get_vpc_thrd()
        self.nvme.scan_devices()
        self.traffic.reset()
        self.traffic.send_sanitize()
        current_bmi_list = self.get_bmi_list()
        current_nor_buf = self.read_nor()
        compare_list, flag = self.compare_bmi_list(self.orig_bmi_list, current_bmi_list)
        if flag is True:
            gbb_count = len(compare_list)
            LOG.info("new badb count: %d", gbb_count)
            self.clear_nor(current_nor_buf)
            self.clear_bmi(compare_list)
            LOG.info("Clear bb complete")
        else:
            LOG.info("Manage block have bb!!")
            self.clear_nor(current_nor_buf)
            if (os.environ.get('quarch', None) is not None) or \
                    (os.environ.get('cnextb', None) is not None):
                self.do_mcp()
            else:
                raise AssertionError("Need to do mcp to clear bb")

    def do_mcp(self):
        LOG.info("Send clearspi 1 command")
        self.vu.clearspi(spi_id=1, spi_sub_id=0)
        power = Link()
        for i in range(2):
            LOG.info("Do hot plug, time: %d", i+1)
            power.hot_plug_action()
            self.scan_device()

    def scan_device(self):
        for _ in range(60):
            try:
                self.nvme.scan_devices()
                self.vu = TahoeVU(self.nvme)
                self.traffic = LBAOperate(self.nvme)
                return
            except Exception as err:
                LOG.info(err)
            time.sleep(5)
        raise AssertionError('Can not found nvme device!')

    def get_vpc_thrd(self):
        dev_conf = self.vu.get_device_config()
        ch = dev_conf.CH
        #lun = dev_conf.LUN
        lun = 4
        plane = dev_conf.PLANE
        ep = dev_conf.EP
        vpc = ch * lun * plane * ep * 3
        LOG.info("ch: %d, lun: %d, plane: %d, ep: %d, vpc_threshold: %d", ch, lun, plane, ep, vpc)
        return vpc

    def get_bmi_list(self):
        bmi_list = self.vu.get_bmi_list(self.devconfig.BLOCK)
        return bmi_list

    def get_bmi_entry(self, blk):
        bmi_entry = self.vu.get_bmi_entry(blk)
        return bmi_entry

    def compare_bmi_list(self, bmi_list_orig, bmi_list_current):
        compare_list = []
        flag = True
        for blk in range(self.devconfig.BLOCK):
            ret = self.compare_bmi_entry(blk, bmi_list_orig[blk], bmi_list_current[blk])
            if ret is False:
                compare_list.append(blk)
                if bmi_list_current[blk].blk_type != 0:
                    flag = False
                    break
        return compare_list, flag

    def compare_bmi_entry(self, blk, bmi_entry_orig, bmi_entry_current, output=False):
        ret = True
        for bb in range(16):
            if bmi_entry_orig.badb[bb] != bmi_entry_current.badb[bb]:
                ret = False
        if ret is False and output:
            LOG.info("Block%d have gbb", blk)
            Ctype(bmi_entry_orig).dump()
            Ctype(bmi_entry_current).dump()
        return ret

    def force_all_bmi_flush_gc_task(self):
        LOG.info("Before clear bb, check all block gc task state")
        bmi_list = self.get_bmi_list()
        for blk, bmi_entry in enumerate(bmi_list):
        #for blk in range(self.devconfig.BLOCK):
            if bmi_entry.bm_st == BLKSTAT.RECYCLE:
                LOG.info("Block%d is recycle", blk)
                for _ in range(30):
                    time.sleep(10)
                    bmi_entry = self.get_bmi_entry(blk)
                    if bmi_entry.vpc <= self.vpc:
                        break
                else:
                    LOG.info("Block%d gc task timeout", blk)
                    continue
                blk_state = self.get_blk_state(blk)
                if blk_state == BLKSTAT.RECYCLE:
                    LOG.info("Block%d do force flush gc task", blk)
                    self.vu.force_flush(task="gc")
                    for _ in range(30):
                        time.sleep(10)
                        blk_state = self.get_blk_state(blk)
                        if blk_state == BLKSTAT.ERASE:
                            break
                    else:
                        LOG.info("Fail to change blk%d state to erase", blk)
        LOG.info("All block is ready")

    def clear_bmi(self, clear_list):
        LOG.info("Start clear bmi table")
        if not clear_list:
            LOG.info("There is no gbb")
        else:
            for blk in clear_list:
                LOG.info("Block%d bmi table had been changed, start to clear it", blk)
                ret = self.change_blk_state(blk)
                if ret is False:
                    raise AssertionError("Fail to change Block{} state".format(blk))
                self.write_bmi_entry_badb(blk)

            current_bmi_list = self.get_bmi_list()
            compare_list, flag = self.compare_bmi_list(self.orig_bmi_list, current_bmi_list)
            if len(compare_list) != 0 or flag is False:
                raise AssertionError("Clear bmi table not complete")

            LOG.info("Clear bmi table complete")

    def get_blk_state(self, blk):
        bmi_entry = self.get_bmi_entry(blk)
        LOG.info("Block%d state: %s", blk, BLOCK_STATE[bmi_entry.bm_st])
        return bmi_entry.bm_st

    def change_blk_state(self, blk):
        blk_state = self.get_blk_state(blk)
        if blk_state == BLKSTAT.OPEN:
            self.change_open_blk_state(blk)

        blk_state = self.get_blk_state(blk)
        if blk_state == BLKSTAT.CLOSE:
            self.change_close_blk_state(blk)

        blk_state = self.get_blk_state(blk)
        if blk_state == BLKSTAT.RECYCLE:
            self.change_recycle_blk_state(blk)

        if blk_state in (BLKSTAT.FREE, BLKSTAT.ERASE):
            return True
        return False

    def change_close_blk_state(self, blk):
        LOG.info("Block%d do force gc task", blk)
        self.vu.force_gc(blk)
        time.sleep(10)

    def change_recycle_blk_state(self, blk):
        for _ in range(30):
            bmi_entry = self.get_bmi_entry(blk)
            LOG.info("Block%d bmi vpc value: %d", blk, bmi_entry.vpc)
            if bmi_entry.vpc <= 1536:
                break
            time.sleep(10)
        else:
            raise AssertionError("Fail to reduce blk{} vpc below 1536".format(blk))
        LOG.info("Block%d do force flush gc task", blk)
        self.vu.force_flush(task="gc")
        for _ in range(30):
            blk_state = self.get_blk_state(blk)
            if blk_state != BLKSTAT.RECYCLE:
                break
            time.sleep(10)
        else:
            raise AssertionError("Fail to change blk{} state from recycle to erase".format(blk))



    def write_bmi_entry_badb(self, blk):
        LOG.info("Write blk%d bmi entry badb field", blk)
        self.vu.write_bmi_entry_badb_field(blk, self.orig_bmi_list)
        ret = self.compare_bmi_entry(blk, self.orig_bmi_list[blk], self.get_bmi_entry(blk), output=True)
        assert ret is True, 'Write bmi entry fail'

    def clear_nor(self, current_nor_buf):
        LOG.info("Start clear bmi table")
        compare_ret = self.compare_nor(self.orig_nor_buf, current_nor_buf)
        if not compare_ret:
            LOG.info("Start clear nor. Erase nor, start addr: 0x%x, range: 0x%x", self.nor_bb_log_address, math.ceil(current_nor_buf.size/4096)*4096)
            self.vu.erase_nor(self.nor_bb_log_address, math.ceil(current_nor_buf.size/4096)*4096)
            if self.orig_nor_buf.size:
                LOG.info("Write nor, start addr: 0x%x, range: 0x%x", self.nor_bb_log_address, self.orig_nor_buf.size)
                self.vu.write_nor(self.nor_bb_log_address, self.orig_nor_buf.size, self.orig_nor_buf.buf)
            self.vu.adjust_nor_bb_addr()
            current_nor_buf = self.read_nor()
            assert current_nor_buf.len == self.orig_nor_buf.len, "clear nor fail"
            LOG.info("Clear nor complete")

    def read_nor(self):
        LOG.info("Nor bb info:")
        read_buf = self.vu.read_nor(self.nor_bb_log_address, self.nor_bb_log_max_size)
        offset = 0
        for offset in range(0, self.nor_bb_log_max_size, 4):
            value = read_buf.get_uint32(offset)
            if value == self.nor_bb_invalid_value:
                break
            # LOG.info("offset%d: value%d", offset, value)
        nor_buf = read_buf.set_sub_buffer(0, offset, c_uint32)
        LOG.info("Nor bb count: 0x%x", nor_buf.len)
        return nor_buf

    def compare_nor(self, orig_nor_buf, current_nor_buf):
        if orig_nor_buf.size == current_nor_buf.size:
            LOG.info("There is no new nor bb need to clear")
        elif orig_nor_buf.size > current_nor_buf.size:
            raise AssertionError("nor bb decrease!!")
        elif orig_nor_buf.size < current_nor_buf.size:
            msg = "There is new nor bb info: \n"
            for offset in range(orig_nor_buf.size, current_nor_buf.size, 4):
                value = current_nor_buf.get_uint32(offset)
                nor = BbLogEntryT()
                nor.all = value
                msg += "bb: ch {}, lun {}, blk {}, type {}, reason {}\n".format(nor.ch, nor.ln, nor.block, nor.type, nor.reason)
            LOG.warning(msg)
            return False
        return True

    def check_open_blk_cursor(self, blk):
        ret_ci0 = self.vu.get_last_write_info(cursor_id=0)
        ret_ci1 = self.vu.get_last_write_info(cursor_id=1)
        for dw in ['pre_pre_open_blk', 'pre_open_blk', 'current_open_blk', 'next_open_blk']:
            open_blk = getattr(ret_ci0, dw)
            if open_blk == blk:
                return 0
        for dw in ['pre_pre_open_blk', 'pre_open_blk', 'current_open_blk', 'next_open_blk']:
            open_blk = getattr(ret_ci1, dw)
            if open_blk == blk:
                return 1
        Ctype(ret_ci0).dump()
        Ctype(ret_ci1).dump()
        raise AssertionError("can not find open blk {} cursor".format(blk))

    def change_open_blk_state(self, blk):
        ret = self.check_open_blk_cursor(blk)
        if ret == 0:
            LOG.info("host open blk")
            self.close_host_open_blk(blk)
        elif ret == 1:
            LOG.info("gc open blk")
            self.close_gc_open_blk(blk)

    def close_host_open_blk(self, blk):
        for _ in range(10):
            LOG.info("Block%d is open, try to close it", blk)
            lba = random.randrange(200)
            self.traffic.write_sync(lba, 1)
            LOG.info("Do force flush host block task")
            self.vu.force_flush(task="host")
            blk_state = self.get_blk_state(blk)
            if blk_state != BLKSTAT.OPEN:
                break
        else:
            raise AssertionError("Block{} stil stay open state, cursor0".format(blk))

    def close_gc_open_blk(self, blk):
        for _ in range(10):
            LOG.info("Block%d is open, try to close it", blk)
            self.force_gc_close_blk()
            blk_state = self.get_blk_state(blk)
            if blk_state != BLKSTAT.OPEN:
                break
        else:
            raise AssertionError("Block{} stil stay open state, cursor1".format(blk))

    def force_gc_close_blk(self):
        ret_ci0 = self.vu.get_last_write_info(cursor_id=0)
        Ctype(ret_ci0).dump()
        for dw in ['pre_pre_open_blk', 'pre_open_blk', 'current_open_blk', 'next_open_blk']:
            blk = getattr(ret_ci0, dw)
            blk_state = self.get_blk_state(blk)
            if blk_state == BLKSTAT.OPEN:
                break
        else:
            raise AssertionError("cursor 0 open blk all not stay open state in bmi entry")
        LOG.info("select blk %d to do force_gc", blk)
        self.change_blk_state(blk)

class ClearBBVU:

    def __init__(self, dev=None):
        self.tahoe = Tahoe() if dev is None else Tahoe()
        self.orig_gbb = 0

    def enable_bypass_gbb(self):
        LOG.info("start to bypass gbb")
        self.check_mark_bb_complete()
        self.tahoe.vu_cmd.bypass_gbb(enable=True)
        #self.orig_gbb = self.tahoe.get_vendor_uniquelog_with_offset(8, 144)
        self.orig_gbb = self.tahoe.get_log_smart_health_info_extend().BUNBR
        LOG.info("original gbb count: %d", self.orig_gbb)

    def disable_bypass_gbb(self, compare=True):
        self.tahoe.scan_devices()
        try:
            LOG.info("end to bypass gbb")
            self.check_mark_bb_complete()
            #gbb = self.tahoe.get_vendor_uniquelog_with_offset(8, 144)
            gbb = self.tahoe.get_log_smart_health_info_extend().BUNBR
            LOG.info("current gbb count: %d, original gbb count: %d", gbb, self.orig_gbb)
            self.tahoe.vu_cmd.bypass_gbb(enable=False)
            if compare:
                assert self.orig_gbb == gbb, "there are new gbb!!!"
        except Exception:
            LOG.error("vu is not close, please execute command: \
                nvme admin-passthru /dev/nvme0 --opcode=0xc0 --cdw10=0x10000076 --cdw11=0 --cdw12=0x0")
            raise

    def check_mark_bb_progress(self):
        value = self.tahoe.vu_cmd.get_mark_bb_info()
        if value.tmpbb_add_cnt == value.tmpbb_rm_cnt and value.ftle_add_cnt == value.ftle_rm_cnt:
            return True, value
        return False, value

    def check_mark_bb_complete(self):
        timeout = time.time() + 2 * 60 *60
        while time.time() < timeout:
            LOG.info("waiting for fw mark bb process done")
            ret, start_value = self.check_mark_bb_progress()
            if ret is False:
                time.sleep(10)
                continue
            LOG.info("check mark bb status last 3 min")
            for _ in range(3):
                time.sleep(60)
                ret, value = self.check_mark_bb_progress()
                if ret is False:
                    LOG.info("equal last fail, break")
                    break
                if value.tmpbb_add_cnt != start_value.tmpbb_add_cnt:
                    LOG.info("tmpbb last fail, break")
                    break
                if value.ftle_add_cnt != start_value.ftle_add_cnt:
                    LOG.info("ftle last fail, break")
                    break

            else:
                LOG.info("check fw mark bb done")
                return

        raise AssertionError("mark bb last too long")
