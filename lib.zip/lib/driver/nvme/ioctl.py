#!/usr/bin/env python
# pylint: disable=invalid-name
# pylint: disable-msg=too-many-locals
"""
Created on 2019/4/26

@author: yyang
"""
import fcntl
import logging
import os
import re
import time
from ctypes import sizeof, addressof

from lib.driver.nvme.struct import *

LOG = logging.getLogger()
DUMP = logging.getLogger('dump')


def _iowr(_tp, _nr, _sz):
    return (3 << 30) + (sizeof(_sz) << 16) + (ord(_tp) << 8) + _nr


def _iow(_tp, _nr, _sz):
    return (1 << 30) + (sizeof(_sz) << 16) + (ord(_tp) << 8) + _nr


def _io(_tp, _nr):
    return (ord(_tp) << 8) + _nr


class Device:

    def __init__(self, cntid=0, nsid=1, block=None, slot=None):
        # Priority: os.environ[slot] > block > cntid
        self.__cntid = cntid
        self.__nsid = nsid
        self.__slot = slot if slot else os.environ.get('slot')
        self.__block = block if isinstance(block, str) else ''

        self.__devices = []
        self.__device = {}
        self.__node = {}

    def scan_devices(self, nsid=None, block=None):
        # Priority: self.__slot > nsid > block > self.__block > self.__nsid
        self.__devices = []
        self.__device = {}
        self.__node = {}

        if nsid is not None:
            self.__nsid = nsid
            self.__block = ''
        elif isinstance(block, str):
            self.__block = block

        time.sleep(0.1)  # Workround: make sure the linux files are updated
        self._scan_devices()

        if self.__slot:
            self._get_device_by_slot()
        elif self.__block:
            self._get_device_by_block()
        else:
            self._get_device_by_cntid()

    @property
    def devices(self):
        return self.__devices

    @property
    def device(self):
        return self.__device

    @property
    def node(self):
        return self.__node

    @property
    def nodes(self):
        return self.__device['nodes']

    @staticmethod
    def args_to_str(**kwargs):
        # return {key: val for key, val in kwargs.items() if val is not None}
        data = []
        for key, val in kwargs.items():
            if val is None:
                continue

            if isinstance(val, bool):
                pass
            elif isinstance(val, int):
                val = hex(val)
            data.append(f'{key}: {val}')
        return f"{{{', '.join(data)}}}"

    def get_node(self, nsid=None, block=None):
        # Priority: nsid > block > self.__block > self.__nsid
        for node in self.__device['nodes']:
            if nsid:
                if nsid == node['nsid']:
                    return node
            elif isinstance(block, str):
                if block in node['block']:
                    return node
            elif self.__block:
                if self.__block in node['block']:
                    return node
            elif self.__nsid:
                if self.__nsid == node['nsid']:
                    return node

        if nsid is None and block is None:
            if self.__device['nodes']:
                return self.__device['nodes'][0]

        return {}

    def _get_device_by_cntid(self):
        for device in self.__devices:
            if device['cntid'] == self.__cntid:
                self.__device = device
                self.__node = self.get_node(nsid=self.__nsid)
                return
        raise AssertionError(f'Cannot find device by cntid: {self.__cntid}')

    def _get_device_by_block(self):
        for device in self.__devices:
            for node in device['nodes']:
                if self.__block in node['block']:
                    self.__device = device
                    self.__node = self.get_node(block=self.__block)
                    return
        raise AssertionError(f'Cannot find device by block: {self.__block}')

    def _get_device_by_slot(self):
        for device in self.__devices:
            if self.__slot in device['slot']:
                self.__device = device
                self.__node = self.get_node()
                return
        raise AssertionError(f'Cannot find device by slot: {self.__slot}')

    def _scan_devices(self):
        LOG.info('Scan NVMe Devices...')
        base_path = '/sys/class/nvme'
        for c in os.listdir(base_path):
            try:
                device = {'cntid': None, 'char': f"/dev/{c}", 'slot': self.__slot, 'nodes': []}

                # if cntlid is not exists, user should get from identify
                filename = os.path.join(base_path, c, 'cntlid')
                if os.path.exists(filename):
                    with open(filename, encoding='utf-8') as file:
                        device['cntid'] = int(file.read().strip())

                # The slot information from uevent is more detailed
                filename = os.path.join(base_path, c, 'device', 'uevent')
                if os.path.exists(filename):
                    with open(filename, encoding='utf-8') as file:
                        match = re.findall(r'PCI_SLOT_NAME=([0-9a-fA-F:.]+)', file.read())
                    if match:
                        device['slot'] = match[0]

                char_path = os.path.join(base_path, c)
                for b in os.listdir(char_path):
                    if re.findall(r'nvme\d+[c\d]*n\d+', b):
                        pattern = r'c\d+'
                        node = {'nsid': None, 'block': f"/dev/{re.sub(pattern, '', b)}"}

                        # if nsid is not existed, user should get from identify
                        filename = os.path.join(char_path, b, 'nsid')
                        if os.path.exists(filename):
                            with open(filename, encoding='utf-8') as file:
                                node['nsid'] = int(file.read().strip())
                        device['nodes'].append(node)

                self.__devices.append(device)
            except Exception as exc:
                LOG.exception(exc)

        LOG.info(self.__devices)
        return self.__devices


class IOCTL(Device):
    NVME_IOCTL_ADMIN_CMD = _iowr('N', 0x41, NVMePassthruCmd)
    NVME_IOCTL_SUBMIT_IO = _iow('N', 0x42, NVMeUserIO)
    NVME_IOCTL_IO_CMD = _iowr('N', 0x43, NVMePassthruCmd)
    NVME_IOCTL_ADMIN64_CMD = _iowr('N', 0x47, NVMePassthruCmd64)
    NVME_IOCTL_IO64_CMD = _iowr('N', 0x48, NVMePassthruCmd64)
    NVME_IOCTL_RESET = _io('N', 0x44)
    NVME_IOCTL_SUBSYS_RESET = _io('N', 0x45)
    NVME_IOCTL_VU_CMD = _iowr('N', 0x80, NVMeVuCmd)

    @property
    def cntid(self):
        return self.device.get('cntid')

    @cntid.setter
    def cntid(self, cntid):
        self.device['cntid'] = cntid

    @property
    def slot_dev(self):
        return self.device.get('slot')

    @property
    def char_dev(self):
        return self.device.get('char')

    @char_dev.setter
    def char_dev(self, char):
        self.device['char'] = char

    @property
    def char_id(self):
        return re.sub(".*nvme", "", self.char_dev)

    @property
    def block_dev(self):
        return self.node.get('block')

    @property
    def nsid(self):
        return self.node.get('nsid')

    def get_int(self, *args):
        for arg in args:
            if isinstance(arg, int):
                return arg
        raise AssertionError(f'Cannot get an int value: {args}')

    def get_block_dev(self, nsid=None):
        block = self.get_node(nsid=nsid).get('block')
        assert block, f'Cannot get block device of nsid: {nsid}'
        return block

    def _ioctl(self, device, request, cmd=None, status=0, timeout=0, check_cqe=1):
        if timeout and cmd:
            cmd.TIMEOUT = timeout

        dev = os.open(device, os.O_RDWR)
        try:
            if cmd:
                result = fcntl.ioctl(dev, request, cmd)
            else:
                result = fcntl.ioctl(dev, request)
        finally:
            os.close(dev)

        if check_cqe:
            try:
                assert (result & 0x7ff) == (status & 0x7ff), "CQE Status Field Check Failed!"
            except AssertionError:
                DUMP.info("Expect Status: 0x%x, %s", status, STATUS_FIELD.get(status & 0x7ff, 'Unknown'))
                DUMP.info('Actual Status: 0x%x, %s', result, STATUS_FIELD.get(result & 0x7ff, 'Unknown'))
                if cmd:
                    cmd_set = OPCODE.ADMIN if request == self.NVME_IOCTL_ADMIN_CMD else OPCODE.IO
                    DUMP.info('Command : %s', cmd_set.get(cmd.OPCODE, 'Unknown'))
                    sqe = [(f[0], f'{getattr(cmd.BITS, f[0]):#x}') for f in getattr(cmd.BITS, '_fields_')]
                    DUMP.info('SQE : %s', dict(sqe))
                raise

        return result

    def admin_passthru(self, cmd, **kwargs):
        return self._ioctl(self.char_dev, self.NVME_IOCTL_ADMIN_CMD, cmd, **kwargs)

    def admin_passthru64(self, cmd, **kwargs):
        return self._ioctl(self.char_dev, self.NVME_IOCTL_ADMIN64_CMD, cmd, **kwargs)

    def io_passthru(self, cmd, **kwargs):
        return self._ioctl(self.block_dev, self.NVME_IOCTL_IO_CMD, cmd, **kwargs)

    def io64_passthru(self, cmd, **kwargs):
        return self._ioctl(self.block_dev, self.NVME_IOCTL_IO64_CMD, cmd, **kwargs)

    def nvme_io(self, cmd, **kwargs):
        return self._ioctl(self.block_dev, self.NVME_IOCTL_SUBMIT_IO, cmd, **kwargs)

    def reset(self, **kwargs):
        return self._ioctl(self.char_dev, self.NVME_IOCTL_RESET, **kwargs)

    def subsys_reset(self, **kwargs):
        return self._ioctl(self.char_dev, self.NVME_IOCTL_SUBSYS_RESET, **kwargs)

    def nvme_vu_cmd(self, cmd, **kwargs):
        return self._ioctl(self.char_dev, self.NVME_IOCTL_VU_CMD, cmd, **kwargs)


class ADMIN(IOCTL):
    def abort(self, sqid, cid, **kwargs):
        cdw10 = AbortDword10()
        cdw10.SQID = sqid
        cdw10.CID = cid

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.ABORT
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs), cmd.RESULT

    def create_io_cq(self, qid, qsize, pc=1, ien=1, iv=0, **kwargs):
        cdw10 = CreateIOCQDword10()
        cdw10.QID = qid
        cdw10.QSIZE = qsize - 1

        cdw11 = CreateIOCQDword11()
        cdw11.PC = pc
        cdw11.IEN = ien
        cdw11.IV = iv

        dptr = (c_uint32 * (4 * qsize))()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CREATE_IO_CQ
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs)

    def create_io_sq(self, qid, qsize, pc=1, qprio=1, cqid=0, **kwargs):
        cdw10 = CreateIOCQDword10()
        cdw10.QID = qid
        cdw10.QSIZE = qsize - 1

        cdw11 = CreateIOSQDword11()
        cdw11.PC = pc
        cdw11.QPRIO = qprio
        cdw11.CQID = cqid

        dptr = (c_uint32 * (16 * qsize))()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CREATE_IO_SQ
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs)

    def delete_io_cq(self, qid, **kwargs):
        cdw10 = DeleteIOCQDword10()
        cdw10.QID = qid

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DELETE_IO_CQ
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs)

    def delete_io_sq(self, qid, **kwargs):
        cdw10 = DeleteIOSQDword10()
        cdw10.QID = qid

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DELETE_IO_SQ
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs)

    def device_self_test(self, stc, nsid=None, **kwargs):
        cdw10 = DeviceSelfTest()
        cdw10.STC = stc

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DEVICE_SELF_TEST
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs)

    def directive_send(self, dptr, doper=0, dtype=0, dspec=0, cdw12=0, nsid=None, **kwargs):
        cdw11 = DirectiveDW11()
        cdw11.DOPER = doper
        cdw11.DTYPE = dtype
        cdw11.DSPEC = dspec

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DIRECTIVE_SEND
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = (sizeof(dptr) >> 2) - 1
        cmd.CDW[11] = cdw11.DWORD
        cmd.CDW[12] = cdw12

        return self.admin_passthru(cmd, **kwargs)

    def directive_receive(self, dptr, doper=0, dtype=0, dspec=0, cdw12=0, nsid=None, **kwargs):
        cdw11 = DirectiveDW11()
        cdw11.DOPER = doper
        cdw11.DTYPE = dtype
        cdw11.DSPEC = dspec

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DIRECTIVE_RECEIVE
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = (sizeof(dptr) >> 2) - 1
        cmd.CDW[11] = cdw11.DWORD
        cmd.CDW[12] = cdw12

        return self.admin_passthru(cmd, **kwargs)

    def fw_commit(self, ca=3, fs=1, bpid=0, **kwargs):
        cdw10 = FWCommitDW10()
        cdw10.BPID = bpid
        cdw10.CA = ca
        cdw10.FS = fs

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.FIRMWARE_COMMIT
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs)

    def fw_download(self, address, xfer=0, offset=0, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.FIRMWARE_DOWNLOAD
        cmd.CDW[10] = (xfer >> 2) - 1
        cmd.CDW[11] = offset >> 2
        cmd.DATA_LEN = xfer
        cmd.DATA = address

        return self.admin_passthru(cmd, **kwargs)

    def get_features(self, fid, sel, cdw11=0, nsid=None, **kwargs):
        cdw10 = GetFeaturesDword10()
        cdw10.FID = fid
        cdw10.SEL = sel

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.GET_FEATURES
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11

        if fid in GET_FEATURE_ENTRY:
            length = 4096 // sizeof(GET_FEATURE_ENTRY[fid])
            dptr = (GET_FEATURE_ENTRY[fid] * length)()
            cmd.DATA = addressof(dptr)
            cmd.DATA_LEN = 4096
        else:
            dptr = None

        status = self.admin_passthru(cmd, **kwargs)
        cdw0 = GET_FEATURE_ID.get(fid, CDW)()
        cdw0.DWORD = cmd.RESULT
        return status, cdw0, dptr

    def get_log(self, dptr, lid=0x1, lpol=0, lpou=0, lsp=0, xfer=4096,
                nsid=0xffffffff, rae=0, **kwargs):
        addr = addressof(dptr)
        size = sizeof(dptr)

        cdw10 = GetLogPagDword10()
        cdw11 = GetLogPagDword11()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.GET_LOG_PAGE
        cmd.NSID = self.get_int(nsid, self.nsid)

        while size > 0:
            xfer = min(xfer, size)
            numd = (xfer >> 2) - 1

            cdw10.LID = lid
            cdw10.LSP = lsp
            cdw10.RAE = rae
            cdw10.NUMDL = numd & 0xffff

            cdw11.NUMDU = numd >> 16

            cmd.CDW[10] = cdw10.DWORD
            cmd.CDW[11] = cdw11.DWORD
            cmd.CDW[12] = lpol
            cmd.CDW[13] = lpou
            cmd.DATA = addr
            cmd.DATA_LEN = xfer

            status = self.admin_passthru(cmd, **kwargs)
            if status:
                return status

            addr += xfer
            size -= xfer
            lpou, lpol = divmod(lpol + xfer, 2 ** 32)

        return 0

    def identify(self, nsid=0, cns=0, cntid=0, **kwargs):
        cdw10 = IdentifyDword10()
        cdw10.CNS = cns
        cdw10.CNTID = self.get_int(cntid, self.cntid)

        cdw11 = IdentifyDword11()
        cdw11.csi = kwargs.get('csi', 0)
        cdw11.cns = kwargs.get('cns_id', 0)

        dptr = IDENTIFY_CNS.get(cns, (c_uint8 * 4096))()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.IDENTIFY
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs), dptr

    def nvme_mi_receive(self, dptr, nmsp0, **kwargs):
        cdw10 = NVMeMIDW10()
        cdw10.NMSP0 = nmsp0

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.NVME_MI_RECEIVE
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs), cmd.RESULT

    def nvme_mi_send(self, dptr, nmsp0, **kwargs):
        cdw10 = NVMeMIDW10()
        cdw10.NMSP0 = nmsp0

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.NVME_MI_SEND
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs)

    def namespace_attachment(self, sel, cntid_list, nsid, **kwargs):
        cdw10 = AttachNSDword10()
        cdw10.SEL = sel

        dptr = ControllerList()
        dptr.NUM = len(cntid_list)
        for i, cntid in enumerate(cntid_list):
            dptr.ID[i] = cntid

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.NAMESPACE_ATTACH
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        return self.admin_passthru(cmd, **kwargs)

    def namespace_management(self, sel, nsze=0, ncap=0, flbas=0, dps=0,
                             nmic=0, nsid=0, anagid=0, nsetid=0, **kwargs):
        cdw10 = NamespaceManagementDword10()
        cdw10.SEL = sel

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.NAMESPACE_MGT
        cmd.CDW[10] = cdw10.DWORD

        if sel == 0:  # Create
            dptr = NamespaceManagementDataStructure()
            dptr.NSZE = nsze
            dptr.NCAP = ncap
            dptr.FLBAS = flbas
            dptr.DPS = dps
            dptr.NMIC = nmic
            dptr.ANAGRPID = anagid
            dptr.NVMSETID = nsetid

            cmd.DATA = addressof(dptr)
            cmd.DATA_LEN = sizeof(dptr)
        else:   # Delete
            cmd.NSID = self.get_int(nsid, self.nsid)

        return self.admin_passthru(cmd, **kwargs), cmd.RESULT

    def set_features(self, fid, save=0, cdw11=0, cdw12=0, cdw13=0, cdw14=0, cdw15=0,
                     dptr=None, nsid=0xffffffff, **kwargs):
        cdw10 = SetFeaturesDword10()
        cdw10.FID = fid
        cdw10.SV = save

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.SET_FEATURES
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11
        cmd.CDW[12] = cdw12
        cmd.CDW[13] = cdw13
        cmd.CDW[14] = cdw14
        cmd.CDW[15] = cdw15
        if dptr:
            cmd.DATA = addressof(dptr)
            cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs)

    def virtualization_management(self, cntlid, rt, act, nr=0, **kwargs):
        cdw10 = VirtualizationManagementDword10()
        cdw10.ACT = act
        cdw10.RT = rt
        cdw10.CNTLID = cntlid

        cdw11 = VirtualizationManagementDword11()
        cdw11.NR = nr

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.VIRT_MANAGEMENT
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD

        return self.admin_passthru(cmd, **kwargs)

    def format(self, nsid=None, lbaf=0, mset=0, pif=0, pil=0, ses=0, **kwargs):
        """
        Admin Command Set - Format NVM command
        :param lbaf:    LBA Format (LBAF)
        :param nsid:    NameSpace ID (NSID)
        :param mset:    Metadata Settings (MSET)
        :param pif:     Protection Information (PIF)
        :param pil:     Protection Information Location (PIL)
        :param ses:     Secure Erase Settings (SES)
        :return:        Status Field Of CQE
        """
        cdw10 = FormatDword10()
        cdw10.LBAF = lbaf
        cdw10.MSET = mset
        cdw10.PIF = pif
        cdw10.PIL = pil
        cdw10.SES = ses

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.FORMAT_NVM
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD

        return self.admin_passthru(cmd, **kwargs)

    def sanitize(self, sanact=0, ause=0, owpass=0, oipbp=0, ndas=0, ovpra=0, **kwargs):
        cdw10 = SanitizeDW10()
        cdw10.SANACT = sanact
        cdw10.AUSE = ause
        cdw10.OWPASS = owpass
        cdw10.OIPBP = oipbp
        cdw10.NDAS = ndas

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.SANITIZE
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = ovpra

        return self.admin_passthru(cmd, **kwargs)

    def security_receive(self, dptr, nsid=None, nssf=0, spsp0=0, spsp1=0, secp=0, **kwargs):
        cdw10 = SecurityReceiveDword10()
        cdw10.NSSF = nssf
        cdw10.SPSP0 = spsp0
        cdw10.SPSP1 = spsp1
        cdw10.SECP = secp

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.SECURITY_RECV
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        if dptr:
            cmd.CDW[11] = sizeof(dptr)
            cmd.DATA = addressof(dptr)
            cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs)

    def security_send(self, dptr, nsid=None, nssf=0, spsp0=0, spsp1=0, secp=0, **kwargs):
        cdw10 = SecuritySendDword10()
        cdw10.NSSF = nssf
        cdw10.SPSP0 = spsp0
        cdw10.SPSP1 = spsp1
        cdw10.SECP = secp

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.SECURITY_SEND
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        if dptr:
            cmd.CDW[11] = sizeof(dptr)
            cmd.DATA = addressof(dptr)
            cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs)


class IO(IOCTL):

    def compare(self, slba, nlb, dptr, mptr=None, prinfo=0, fua=0, lr=0,
                reftag=0, apptag=0, appmask=0, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1
        cdw12.PRINFO = prinfo
        cdw12.FUA = fua
        cdw12.LR = lr

        cmd = NVMeUserIO()
        cmd.OPCODE = OPCODE.COMPARE
        cmd.SLBA = slba
        cmd.NBLOCKS = cdw12.NBLOCKS
        cmd.CONTROL = cdw12.CONTROL
        cmd.DATA = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.REFTAG = reftag
        cmd.APPTAG = apptag
        cmd.APPMASK = appmask

        return self.nvme_io(cmd, **kwargs)

    def dataset_management(self, nr, dptr, idr=0, idw=0, ad=1, nsid=None, **kwargs):
        cdw10 = DsmDword10()
        cdw10.NR = nr - 1

        cdw11 = DsmDword11()
        cdw11.IDR = idr
        cdw11.IDW = idw
        cdw11.AD = ad

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DATASET_MGT
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.io_passthru(cmd, **kwargs)

    def flush(self, nsid=None, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.FLUSH
        cmd.NSID = self.get_int(nsid, self.nsid)

        return self.io_passthru(cmd, **kwargs)

    def read_passthru(self, lba, nlb, dptr, mptr=None, dtype=0, prinfo=0, fua=0,
                      lr=0, dsm=0, dspec=0, ilbrt=0, lbat=0, lbatm=0, nsid=None, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1
        cdw12.DTYPE = dtype
        cdw12.PRINFO = prinfo
        cdw12.FUA = fua
        cdw12.LR = lr

        cdw13 = RWDword13()
        cdw13.DSM = dsm
        cdw13.DSPEC = dspec

        cdw15 = RWDword15()
        cdw15.LBAT = lbat
        cdw15.LBATM = lbatm

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.READ
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        if mptr:
            cmd.META = addressof(mptr)
            cmd.META_LEN = sizeof(mptr)
        cmd.CDW10 = lba & 0xffffffff
        cmd.CDW11 = lba >> 32
        cmd.CDW12 = cdw12.DWORD
        cmd.CDW13 = cdw13.DWORD
        cmd.CDW14 = ilbrt
        cmd.CDW15 = cdw15.DWORD

        return self.io_passthru(cmd, **kwargs)

    def read(self, slba, nlb, dptr, mptr=None, prinfo=0, fua=0, lr=0, dsm=0,
             reftag=0, apptag=0, appmask=0, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1
        cdw12.PRINFO = prinfo
        cdw12.FUA = fua
        cdw12.LR = lr

        cmd = NVMeUserIO()
        cmd.OPCODE = OPCODE.READ
        cmd.SLBA = slba
        cmd.NBLOCKS = cdw12.NBLOCKS
        cmd.CONTROL = cdw12.CONTROL
        cmd.DATA = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.DSMGMT = dsm
        cmd.REFTAG = reftag
        cmd.APPTAG = apptag
        cmd.APPMASK = appmask

        return self.nvme_io(cmd, **kwargs)

    def reservation_acquire(self, racqa, iekey, rtype, crkey, prkey, nsid=None, **kwargs):
        cdw10 = ReservationAcquire()
        cdw10.RACQA = racqa
        cdw10.IEKEY = iekey
        cdw10.RTYPE = rtype

        dptr = ReservationAcquireDataStructure()
        dptr.CRKEY = crkey
        dptr.PRKEY = prkey

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.RESERVATION_ACQUIRE
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = cdw10.DWORD

        return self.io_passthru(cmd, **kwargs)

    def reservation_register(self, rrega, iekey, cptpl, crkey, nrkey, nsid=None, **kwargs):
        cdw10 = ReservationRegister()
        cdw10.RREGA = rrega
        cdw10.IEKEY = iekey
        cdw10.CPTPL = cptpl

        dptr = ReservationRegisterDataStructure()
        dptr.CRKEY = crkey
        dptr.NRKEY = nrkey

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.RESERVATION_REGISTER
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = cdw10.DWORD

        return self.io_passthru(cmd, **kwargs)

    def reservation_release(self, rrela, iekey, rtype, crkey, nsid=None, **kwargs):
        cdw10 = ReservationRelease()
        cdw10.RRELA = rrela
        cdw10.IEKEY = iekey
        cdw10.RTYPE = rtype

        dptr = ReservationReleaseDataStructure()
        dptr.CRKEY = crkey

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.RESERVATION_RELEASE
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = cdw10.DWORD

        return self.io_passthru(cmd, **kwargs)

    def reservation_report(self, eds, nsid=None, numd=None, **kwargs):
        if eds == 0:
            dptr = ReservationStatusDataStructure()
        else:
            dptr = ReservationStatusExtendedDataStructure()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.RESERVATION_REPORT
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        cmd.CDW[10] = (sizeof(dptr) >> 2) - 1 if numd is None else numd
        cmd.CDW[11] = eds & 0x1

        return self.io_passthru(cmd, **kwargs), dptr

    def verify(self, slba=0, lr=0, fua=0, prinfo=0, nlb=1, dtype=0, nsid=None, eilbrt=0, elbatm=0, elbat=0, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1
        cdw12.DTYPE = dtype
        cdw12.PRINFO = prinfo
        cdw12.FUA = fua
        cdw12.LR = lr
        cdw15 = RWDword15()
        cdw15.LBAT = elbat
        cdw15.LBATM = elbatm
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.VERIFY
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW10 = slba & 0xffffffff
        cmd.CDW11 = slba >> 32
        cmd.CDW12 = cdw12.DWORD
        cmd.CDW14 = eilbrt
        cmd.CDW15 = cdw15.DWORD
        return self.io_passthru(cmd, **kwargs)

    def write_passthru(self, lba, nlb, dptr, mptr=None, dtype=0, prinfo=0, fua=0,
                       lr=0, dsm=0, dspec=0, ilbrt=0, lbat=0, lbatm=0, nsid=None, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1
        cdw12.DTYPE = dtype
        cdw12.PRINFO = prinfo
        cdw12.FUA = fua
        cdw12.LR = lr

        cdw13 = RWDword13()
        cdw13.DSM = dsm
        cdw13.DSPEC = dspec

        cdw15 = RWDword15()
        cdw15.LBAT = lbat
        cdw15.LBATM = lbatm

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.WRITE
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        if mptr:
            cmd.META = addressof(mptr)
            cmd.META_LEN = sizeof(mptr)
        cmd.CDW10 = lba & 0xffffffff
        cmd.CDW11 = lba >> 32
        cmd.CDW12 = cdw12.DWORD
        cmd.CDW13 = cdw13.DWORD
        cmd.CDW14 = ilbrt
        cmd.CDW15 = cdw15.DWORD

        return self.io_passthru(cmd, **kwargs)

    def write(self, slba, nlb, dptr, mptr=None, dtype=0, prinfo=0, fua=0, lr=0, dsm=0,
              dspec=0, reftag=0, apptag=0, appmask=0, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1
        cdw12.DTYPE = dtype
        cdw12.PRINFO = prinfo
        cdw12.FUA = fua
        cdw12.LR = lr

        cdw13 = RWDword13()
        cdw13.DSM = dsm
        cdw13.DSPEC = dspec

        cmd = NVMeUserIO()
        cmd.OPCODE = OPCODE.WRITE
        cmd.SLBA = slba
        cmd.NBLOCKS = cdw12.NBLOCKS
        cmd.CONTROL = cdw12.CONTROL
        cmd.DATA = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.DSMGMT = cdw13.DWORD
        cmd.REFTAG = reftag
        cmd.APPTAG = apptag
        cmd.APPMASK = appmask

        return self.nvme_io(cmd, **kwargs)

    def write_uncorrectable(self, slba, nlb, nsid=None, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.WRITE_UNCORRECTABLE
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = slba & 0xffffffff
        cmd.CDW[11] = slba >> 32
        cmd.CDW[12] = cdw12.DWORD

        return self.io_passthru(cmd, **kwargs)

    def write_zeroes(self, slba, nlb, nsid=None, deac=0, prinfo=0, fua=0, lr=0,
                     reftag=0, apptag=0, appmask=0, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1
        cdw12.DEAC = deac
        cdw12.PRINFO = prinfo
        cdw12.FUA = fua
        cdw12.LR = lr

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.WRITE_ZEROES
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = slba & 0xffffffff
        cmd.CDW[11] = slba >> 32
        cmd.CDW[12] = cdw12.DWORD
        cmd.CDW[14] = reftag
        cmd.CDW[15] = apptag | (appmask << 16)

        return self.io_passthru(cmd, **kwargs)


class PIOCTL(IOCTL):
    NVME_IOCTL_ADMIN_CMD = _iowr('E', 0x01, NVMePassthruCmd)
    NVME_IOCTL_IO = _iowr('E', 0x02, PNVMeIOCmd)
    NVME_IOCTL_AIO = _iowr('E', 0x03, PNVMeIOCmd)
    NVME_IOCTL_ATOMIC = _iowr('E', 0x04, PNVMeIOCmd)
    NVME_IOCTL_PI = _iowr('E', 0x05, PNVMeIOCmd)
    NVME_IOCTL_SGL = _iowr('E', 0x06, PNVMeIOCmd)
    NVME_IOCTL_CRT_CQ = _iowr('E', 0x07, NVMePassthruCmd)
    NVME_IOCTL_DEL_CQ = _iowr('E', 0x08, NVMePassthruCmd)
    NVME_IOCTL_CRT_SQ = _iowr('E', 0x09, NVMePassthruCmd)
    NVME_IOCTL_DEL_SQ = _iowr('E', 0x0a, NVMePassthruCmd)
    NVME_IOCTL_DSM = _iowr('E', 0x0B, NVMePassthruCmd)
    NVME_IOCTL_LATENCY = _iowr('E', 0x0C, PNVMeLatency)

    NVME_IOCTL_SQ = _iowr('G', 0x01, c_uint32)
    NVME_IOCTL_CQ = _iowr('G', 0x02, c_uint32)
    NVME_IOCTL_DEBUG = _iowr('G', 0x03, c_uint32)

    def __init__(self, cntid=0, nsid=1):
        super().__init__(cntid, nsid)
        self.pnvme_dev = None
        self.scan_devices()

    def scan_devices(self, nsid=None, block=None):
        super().scan_devices(nsid, block)
        self.pnvme_dev = '/dev/pnvme'+self.char_id
        if not os.path.exists(self.pnvme_dev):
            raise AssertionError(f'Cannot find pnvme device: {self.pnvme_dev}')

    def io_passthru(self, cmd, **kwargs):
        assert False, 'Not support io_passthru for PIOCTL'

    def reset(self, **kwargs):
        assert False, 'Not support reset for PIOCTL'

    def subsys_reset(self, **kwargs):
        assert False, 'Not support subsys_reset for PIOCTL'

    def nvme_debug(self, cmd):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_DEBUG, cmd, check_cqe=0)

    def nvme_get_sq(self, cmd):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_SQ, cmd)

    def nvme_get_cq(self, cmd):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_CQ, cmd)

    def nvme_io(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_IO, cmd, **kwargs)

    def nvme_pi(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_PI, cmd, **kwargs)

    def nvme_sgl(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_SGL, cmd, **kwargs)

    def nvme_aio(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_AIO, cmd, **kwargs)

    def nvme_async_dsm(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_DSM, cmd, **kwargs)

    def nvme_atomic(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_ATOMIC, cmd, **kwargs)

    def nvme_get_latency(self, cmd, **kwargs):
        return self._ioctl(self.char_dev, self.NVME_IOCTL_LATENCY, cmd, **kwargs)

    def admin_passthru(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_ADMIN_CMD, cmd, **kwargs)

    def nvme_crt_cq(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_CRT_CQ, cmd, **kwargs)

    def nvme_del_cq(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_DEL_CQ, cmd, **kwargs)

    def nvme_crt_sq(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_CRT_SQ, cmd, **kwargs)

    def nvme_del_sq(self, cmd, **kwargs):
        return self._ioctl(self.pnvme_dev, self.NVME_IOCTL_DEL_SQ, cmd, **kwargs)

    def identify(self, nsid=1, cns=1, cntid=None, **kwargs):
        cdw10 = IdentifyDword10()
        cdw10.CNS = cns
        cdw10.CNTID = cntid if cntid is not None else self.cntid
        dptr = ControllerDataStructure()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.IDENTIFY
        cmd.NSID = nsid
        cmd.CDW[10] = cdw10.DWORD
        cmd.ADDR = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        return self.admin_passthru(cmd, **kwargs), dptr

    def create_io_cq(self, qid, qsize, pc=1, ien=1, iv=0, **kwargs):
        cdw10 = CreateIOCQDword10()
        cdw10.QID = qid
        cdw10.QSIZE = qsize - 1

        cdw11 = CreateIOCQDword11()
        cdw11.PC = pc
        cdw11.IEN = ien
        cdw11.IV = iv

        dptr = (c_uint32 * (4 * qsize))()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CREATE_IO_CQ
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.nvme_crt_cq(cmd, **kwargs)

    def create_io_sq(self, qid, qsize, pc=1, qprio=1, cqid=0, **kwargs):
        cdw10 = CreateIOCQDword10()
        cdw10.QID = qid
        cdw10.QSIZE = qsize - 1

        cdw11 = CreateIOSQDword11()
        cdw11.PC = pc
        cdw11.QPRIO = qprio
        cdw11.CQID = cqid

        dptr = (c_uint32 * (16 * qsize))()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CREATE_IO_SQ
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.nvme_crt_sq(cmd, **kwargs)

    def delete_io_cq(self, qid, **kwargs):
        cdw10 = DeleteIOCQDword10()
        cdw10.QID = qid

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DELETE_IO_CQ
        cmd.CDW[10] = cdw10.DWORD

        return self.nvme_del_cq(cmd, **kwargs)

    def delete_io_sq(self, qid, **kwargs):
        cdw10 = DeleteIOSQDword10()
        cdw10.QID = qid

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DELETE_IO_SQ
        cmd.CDW[10] = cdw10.DWORD

        return self.nvme_del_sq(cmd, **kwargs)

    def write(self, slba, nlb, dptr, mptr=None, qid=1, nsid=1, dsm=0, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.WRITE
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        cmd.PRP1 = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.DSMGMT = dsm
        return self.nvme_io(cmd, **kwargs)

    def read(self, slba, nlb, dptr, mptr=None, qid=1, nsid=1, dsm=0, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.READ
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        cmd.PRP1 = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.DSMGMT = dsm
        return self.nvme_io(cmd, **kwargs)

    def write_sgl(self, slba, nlb, d_num, m_num, dptr, dsglptr, mptr=None, msglptr=None, qid=1, nsid=1, ctrl=0,
                  flags=0x40, doff=0, moff=0, **kwargs):
        cmd = NVMeSGLIO()
        cmd.OPCODE = OPCODE.WRITE
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        cmd.PRP1 = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.CTRL = ctrl
        cmd.FLAGS = flags
        cmd.DATA_OFF = doff
        cmd.META_OFF = moff
        cmd.DATA_DES_NUM = d_num if d_num >= 1 else 1
        cmd.META_DES_NUM = m_num
        cmd.SGL_DATA_PTR = addressof(dsglptr)
        cmd.SGL_META_PTR = addressof(msglptr) if mptr else 0
        return self.nvme_sgl(cmd, **kwargs)

    def read_sgl(self, slba, nlb, d_num, m_num, dptr, dsglptr, mptr=None, msglptr=None, qid=1, nsid=1, ctrl=0,
                 flags=0x40, doff=0, moff=0, **kwargs):
        cmd = NVMeSGLIO()
        cmd.OPCODE = OPCODE.READ
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        cmd.PRP1 = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.CTRL = ctrl
        cmd.FLAGS = flags
        cmd.DATA_OFF = doff
        cmd.META_OFF = moff
        cmd.DATA_DES_NUM = d_num if d_num >= 1 else 1
        cmd.META_DES_NUM = m_num
        cmd.SGL_DATA_PTR = addressof(dsglptr)
        cmd.SGL_META_PTR = addressof(msglptr) if mptr else 0
        return self.nvme_sgl(cmd, **kwargs)

    def write_async(self, slba, nlb, qid=1, nsid=1, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.WRITE
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        return self.nvme_aio(cmd, **kwargs)

    def read_async(self, slba, nlb, qid=1, nsid=1, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.READ
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        return self.nvme_aio(cmd, **kwargs)

    def write_atomic(self, slba, nlb, qid=1, nsid=1, pat=0, stream_id=None, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.WRITE
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        cmd.REFTAG = pat
        cmd.DIR = 0
        if stream_id is not None:
            cmd.DTYPE = 1
            cmd.DIR = stream_id
        return self.nvme_atomic(cmd, **kwargs)

    def read_atomic(self, slba, nlb, qid=1, nsid=1, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.READ
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        return self.nvme_atomic(cmd, **kwargs)

    def get_latency(self, clear, **kwargs):
        cmd = PNVMeLatency()
        cmd.CLEAR = clear
        self.nvme_get_latency(cmd, **kwargs)
        return cmd

    def async_trace(self):
        dptr = AsyncTrace()
        cmd = PNVMeDebug()
        cmd.OPCODE = DebugOPCODE.ASYNC_TRACE
        cmd.DATA = addressof(dptr)
        ret = self.nvme_debug(cmd)
        return ret, dptr

    def format_up(self):
        cmd = PNVMeDebug()
        cmd.OPCODE = DebugOPCODE.FORMAT_UP
        ret = self.nvme_debug(cmd)
        return ret

    def get_qid(self):
        cmd = PNVMeDebug()
        cmd.OPCODE = DebugOPCODE.GET_QID
        ret = self.nvme_debug(cmd)
        return ret

    def get_cq(self, qid=0):
        return self.nvme_get_cq(qid)

    def get_sq(self, qid=0):
        return self.nvme_get_sq(qid)

    def write_pi(self, slba, nlb, dptr, mptr=None, qid=1, nsid=1, ctrl=0, reftag=0, apptag=0, appmask=0, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.WRITE
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        cmd.CTRL = ctrl
        cmd.PRP1 = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.REFTAG = reftag
        cmd.APPTAG = apptag
        cmd.APPMASK = appmask
        return self.nvme_pi(cmd, **kwargs)

    def read_pi(self, slba, nlb, dptr, mptr=None, qid=1, nsid=1, ctrl=0, reftag=0, apptag=0, appmask=0, **kwargs):
        cmd = PNVMeIOCmd()
        cmd.OPCODE = OPCODE.READ
        cmd.SLBA = slba
        cmd.NLB = nlb - 1
        cmd.QID = qid
        cmd.NSID = nsid
        cmd.CTRL = ctrl
        cmd.PRP1 = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.REFTAG = reftag
        cmd.APPTAG = apptag
        cmd.APPMASK = appmask
        return self.nvme_pi(cmd, **kwargs)

    def copy(self, sdlba, nr, df, dptr, mptr=None, prinfor=0, dtype=0, stcw=0, prinfow=0, fua=0, lr=0, dspec=0,
             reftag=0, apptag=0, appmask=0, **kwargs):
        cdw12 = CopyDword12()
        cdw12.NR = nr - 1
        cdw12.DF = df
        cdw12.PRINFOR = prinfor
        cdw12.DTYPE = dtype
        cdw12.STCW = stcw
        cdw12.PRINFOW = prinfow
        cdw12.FUA = fua
        cdw12.LR = lr

        cdw13 = CopyDword13()
        cdw13.DSPEC = dspec

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.COPY
        cmd.NSID = 1
        cmd.DATA = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.CDW[10] = sdlba & 0xffffffff
        cmd.CDW[11] = sdlba >> 32
        cmd.CDW[12] = cdw12.DWORD
        cmd.CDW[13] = cdw13.DWORD
        cmd.REFTAG = reftag
        cmd.APPTAG = apptag
        cmd.APPMASK = appmask

        return self.io_passthru(cmd, **kwargs)

    def dataset_management(self, nr, dptr, idr=0, idw=0, ad=1, qid=1, nsid=1, **kwargs):
        cdw10 = DsmDword10()
        cdw10.NR = nr - 1

        cdw11 = DsmDword11()
        cdw11.IDR = idr
        cdw11.IDW = idw
        cdw11.AD = ad

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.DATASET_MGT
        cmd.NSID = nsid
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[11] = cdw11.DWORD
        cmd.CDW[13] = qid << 8
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.nvme_async_dsm(cmd, **kwargs)
