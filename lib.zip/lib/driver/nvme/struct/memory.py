#!/usr/bin/env python
# pylint: disable=superfluous-parens,missing-docstring,too-few-public-methods
"""
Created on Apr 19, 2019

@author: yyang
"""
from ctypes import Structure, c_uint32, c_uint64, Union


class BLKSTAT:
    FREE = 0x00
    OPEN = 0x01
    CLOSE = 0x02
    RECYCLE = 0x06
    ERASE = 0x03
    PROTECT = 0x07


class TahoeBMIEntry(Structure):
    """bmi format"""
    _pack_ = 1
    _fields_ = [
        ('bm_st', c_uint32, 3),
        ('blk_type', c_uint32, 3),
        ('bad', c_uint32, 1),
        ('rsv0', c_uint32, 1),
        ('ecc_lvl', c_uint32, 4),
        ('repl_flag', c_uint32, 1),
        ('all_good', c_uint32, 1),
        ('xlc', c_uint32, 2),
        ('gc_class', c_uint32, 8),
        ('wf_flg', c_uint32, 1),
        ('rf_flg', c_uint32, 1),
        ('ecc_hi', c_uint32, 1),
        ('ecc_un', c_uint32, 1),
        ('dr_flg', c_uint32, 1),
        ('wl_flg', c_uint32, 1),
        ('rdist', c_uint32, 1),
        ('gc_soft', c_uint32, 1),
        ('nex_ptr', c_uint32, 16),
        ('mbu_cnt', c_uint32, 10),
        ('rsv1', c_uint32, 6),
        ('cr_tm', c_uint32),
        ('vpc', c_uint32),
        ('rd_cnt', c_uint32),
        ('seq_num', c_uint32),
        ('pe_cyc', c_uint32, 20),
        ('rsv2', c_uint32, 12),
        ('strem_id', c_uint32, 9),
        ('rsv3', c_uint32, 7),
        ('ext_lrb', c_uint32, 16),
        ('wfb0', c_uint32, 16),
        ('wfb1', c_uint32, 16),
        ('rfb0', c_uint32, 16),
        ('rfb1', c_uint32, 16),
        ('thr_cfg', c_uint32),
        ('rsv4', c_uint32),
        ('badb', c_uint32 * 16),
        ('rsv5', c_uint32),
        ('rsv6', c_uint64),
        ('rsv7', c_uint32, 16),
        ('hamming_ecc', c_uint32, 16),
    ]


class TahoeVUPower(Structure):
    """bmi format"""
    _pack_ = 1
    _fields_ = [
        ('vol', c_uint32, 16),
        ('cur', c_uint32, 16),
        ('pw_int', c_uint32, 16),
        ('pw_float', c_uint32, 16),
        ('max_credit', c_uint32),
        ('min_credit', c_uint32),
        ('avg_credit', c_uint32),
        ('max_rd_die', c_uint32),
        ('min_rd_die', c_uint32),
        ('avg_rd_die', c_uint32),
        ('max_wr_die', c_uint32),
        ('min_wr_die', c_uint32),
        ('avg_wr_die', c_uint32),
        ('max_ers_die', c_uint32),
        ('min_ers_die', c_uint32),
        ('avg_ers_die', c_uint32),
    ]

class TahoeDeviceConfig(Structure):
    _pack_ = 1
    _fields_ = [
        ('CH', c_uint32),
        ('EP', c_uint32),
        ('PLANE', c_uint32),
        ('LUN', c_uint32),
        ('PAGE', c_uint32),
        ('BLOCK', c_uint32),
        ('SB', c_uint32),
        ('MAX_PE', c_uint32),
        ('RSE', c_uint32 * 1016)
    ]

class PBlkT(Structure):
    _fields_ = [("ch", c_uint32, 4),
                ("ln", c_uint32, 5),
                ("block", c_uint32, 13),
                ("type", c_uint32, 2),
                ("reason", c_uint32, 3),
                ("rsv", c_uint32, 5)]

class SBlkT(Structure):
    _fields_ = [("rsv1", c_uint32, 9),
                ("pl", c_uint32, 1),
                ("bl", c_uint32, 12),
                ("rsv2", c_uint32, 10)]

class BbLogEntryT(Union):
    _anonymous_ = ("pblk", "sblk")
    _fields_ = [("all", c_uint32),
                ("pblk", PBlkT),
                ("sblk", SBlkT)]


class BadBlockInfo(Structure):
    _fields_ = [
        ("SYS_MCP_AVAL", c_uint32),
        ("SYS_CUR_AVAL", c_uint32),
        ("SYS_MCP_COUNT", c_uint32),
        ("USR_MCP_COUNT", c_uint32),
        ("RSV", c_uint32 * 124),
    ]

class LastWriteInfo(Structure):
    _pack_ = 1
    _fields_ = [
        ('next_ppa', c_uint32),
        ('cfg_nand_channel_num', c_uint32),
        ('cfg_nand_lun_num', c_uint32),
        ('cfg_nand_block_num', c_uint32),
        ('cfg_nand_page_num', c_uint32),
        ('cfg_nand_plane_num', c_uint32),
        ('cfg_nand_ep_num', c_uint32),
        ('ch_bits', c_uint32),
        ('ln_bits', c_uint32),
        ('bl_bits', c_uint32),
        ('pg_bits', c_uint32),
        ('pl_bits', c_uint32),
        ('ep_bits', c_uint32),
        ('sb_num', c_uint32),
        ('sb_bits', c_uint32),
        ('pre_pre_open_blk', c_uint32),
        ('pre_open_blk', c_uint32),
        ('current_open_blk', c_uint32),
        ('next_open_blk', c_uint32),
    ]

class MarkBBInfo(Structure):
    _pack_ = 1
    _fields_ = [
        ('tmpbb_add_cnt', c_uint32),
        ('tmpbb_rm_cnt', c_uint32),
        ('ftle_add_cnt', c_uint32),
        ('ftle_rm_cnt', c_uint32),
    ]
