from ctypes import Structure, c_uint8, c_uint16, c_uint32, c_uint64
from lib.driver.utils.ctype import Byte
from lib.driver.nvme.struct.log_page import SmartHealthInformation


expected_event_type_revision = {
    # Event Type: Event Type Revision,
    0x1: 0x1,
    0x2: 0x1,
    0x3: 0x1,
    0x4: 0x1,
    0x5: 0x1,
    0x6: 0x1,
    0x7: 0x1,
    0x8: 0x1,
    0x9: 0x1,
    0xa: 0x1,
    0xb: 0x1,
    0xc: 0x1,
    0xd: 0x1,
    0xde: 0x1,
}


SmartHealthLogSnapshotEvent = SmartHealthInformation


class NvmeFwCommitEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("old_fw_rev", c_uint64),
        ("new_fw_rev", c_uint64),
        ("fw_commit_action", c_uint8),
        ("fw_slot", c_uint8),
        ("sct_fw", c_uint8),
        ("sc_fw", c_uint8),
        ("vndr_assign_fw_commit_rc", c_uint16),
    ]


class NvmeTimestamp(Structure):
    _pack_ = 1
    _fields_ = [
        ("timestamp", c_uint8 * 6),
        ("attr", c_uint8),
        ("rsvd", c_uint8),
    ]


class NvmeTimestampChangeEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("previous_timestamp", NvmeTimestamp),
        ("ml_secs_since_reset", c_uint64),
    ]


class NvmePowerOnResetInfoList(Structure):
    _pack_ = 1
    _fields_ = [
        ("cid", c_uint16),
        ("fw_act", c_uint8),
        ("op_in_prog", c_uint8),
        ("rsvd4", c_uint8 * 12),
        ("ctrl_power_cycle", c_uint32),
        ("power_on_ml_seconds", c_uint64),
        ("ctrl_time_stamp", c_uint64),
    ]


class NvmeNssHwErrEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("nss_hw_err_event_code", c_uint16),
        ("rsvd2", c_uint8 * 2),
        ("add_hw_err_info", c_uint8),
    ]


class NvmeChangeNsEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("nsmgt_cdw10", c_uint32),
        ("rsvd4", c_uint8 * 4),
        ("nsze", c_uint64),
        ("rsvd16", c_uint8 * 8),
        ("nscap", c_uint64),
        ("flbas", c_uint8),
        ("dps", c_uint8),
        ("nmic", c_uint8),
        ("rsvd35", c_uint8),
        ("ana_grp_id", c_uint32),
        ("nvmset_id", c_uint16),
        ("rsvd42", c_uint16),
        ("nsid", c_uint32),
    ]


class NvmeFormatNvmStartEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("nsid", c_uint32),
        ("fna", c_uint8),
        ("rsvd5", c_uint8 * 3),
        ("format_nvm_cdw10", c_uint32),
    ]


class NvmeFormatNvmComplnEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("nsid", c_uint32),
        ("smallest_fpi", c_uint8),
        ("format_nvm_status", c_uint8),
        ("compln_info", c_uint16),
        ("status_field", c_uint32),
    ]


class NvmeSanitizeStartEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("sani_cap", c_uint32),
        ("sani_cdw10", c_uint32),
        ("sani_cdw11", c_uint32),
    ]


class NvmeSanitizeComplnEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("sani_prog", c_uint16),
        ("sani_status", c_uint16),
        ("cmpln_info", c_uint16),
        ("rsvd6", c_uint8 * 2),
    ]


class NvmeSetFeatureEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("layout", c_uint32),
        ("cdw_mem", c_uint32 * 2),
    ]


class NvmePelTelementryCrt(Structure):
    _pack_ = 1
    _fields_ = [
        ("til", Byte * 512)
    ]


class NvmeThermalExcEvent(Structure):
    _pack_ = 1
    _fields_ = [
        ("over_temp", c_uint8),
        ("threshold", c_uint8),
    ]
