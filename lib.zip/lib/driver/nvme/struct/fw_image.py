#!/usr/bin/env python
# pylint: disable=invalid-name
import random
import logging
from ctypes import c_uint32, Structure, c_uint8, c_uint64, Union, sizeof, addressof, memmove


class DESC_FMT_T(Structure):
    _fields_ = [
        ("offset", c_uint32),
        ("size", c_uint32)
    ]


class CLK_FMT_T(Structure):
    _fields_ = [
        ("divider", c_uint32),
        ("flag", c_uint32)
    ]


class CAP_HDR_PROT_T(Structure):
    _fields_ = [
        ("crc32", c_uint32),
    ]


class RSA_FMT_T(Structure):
    _fields_ = [
        ("key0_cert_desc", DESC_FMT_T),
        ("key1_cert_desc", DESC_FMT_T),
        ("cont_cert_desc", DESC_FMT_T),
        ("cap_hdr_prot", CAP_HDR_PROT_T),
    ]


class HMAC_FMT_T(Structure):
    _fields_ = [
        ("image_hmac_desc", DESC_FMT_T),
        ("nonce_desc", DESC_FMT_T),
        ("cap_hdr_prot", CAP_HDR_PROT_T),
    ]


class UNSECURE_FMT_T(Structure):
    _fields_ = [
        ("image_crc32_desc", DESC_FMT_T),
        ("manifest_desc", DESC_FMT_T),
        ("crc32", c_uint32),
    ]


class PROT_FMT_T(Union):
    _fields_ = [
        ("unsecure", UNSECURE_FMT_T),
        ("hmac", HMAC_FMT_T),
        ("rsa", RSA_FMT_T),
    ]


class CAPSULE_HDR_FMT_T(Structure):
    _fields_ = [
        ("cap_prot", c_uint32),
        ("cap_hdr_prot_size", c_uint32),
        ("img_cap_tot_size", c_uint32),
        ("code_desc", DESC_FMT_T),
        ("img_desc", DESC_FMT_T),
        ("clock", CLK_FMT_T),
        ("prot", PROT_FMT_T),
    ]


class FW_DESCRIPTOR_T(Structure):
    _fields_ = [
        ("type", c_uint32),
        ("format_ver", c_uint32),
        ("fw_rev", c_uint64),
        ("offset",  c_uint32),
        ("size",  c_uint32),
        ("reserved", c_uint32 * 2)
    ]


class DOWNLOAD_FILE_MANIFEST_T(Structure):
    _fields_ = [
        ("magicword", c_uint32),       # "RTDF" 0x46445452
        ("format_ver", c_uint32),
        ("num_of_fw", c_uint32),
        ("total_size", c_uint32),
        ("header_crc", c_uint32),
        ("reserved", c_uint32 * 7)
    ]


class IMAGE_DESCRIPTOR_T(Structure):
    _fields_ = [
        ("type", c_uint32),
        ("format_ver", c_uint32),
        ("image_rev", c_uint8 * 8),
        ("data_format", c_uint32, 8),
        ("need_capsule", c_uint32, 1),
        ("rsv_bits", c_uint32, 23),
        ("offset", c_uint32),
        ("size", c_uint32),
        ("crc", c_uint32),
        ("default_location", c_uint32 * 2),
        ("reserved", c_uint32 * 6)
    ]

class IMAGE_PACKAGE_MANIFEST_T(Structure):
    _fields_ = [
        ("magicword", c_uint32),        # "IPKG" 0x474B5049
        ("format_ver", c_uint32),
        ("firmware_rev", c_uint8 * 8),
        ("fw_type", c_uint32),
        ("secure_ver", c_uint32),
        ("num_image",  c_uint32),
        ("total_size", c_uint32),
        ("header_crc", c_uint32),
        ("reserved", c_uint32 * 7)
    ]


class FirmwareImageInfo:
    def __init__(self, image=None):
        self.logger = logging.getLogger()
        self.image = image
        self.image_bytes = None
        self.image_list = []
        self.capsule_list = []

    def get_inject_list(self):
        image_buf = (c_uint8 * len(self.image_bytes))()
        memmove(image_buf, self.image_bytes, sizeof(image_buf))
        image_address = addressof(image_buf)

        image_header = DOWNLOAD_FILE_MANIFEST_T.from_address(image_address)
        self.image_list = list(range(sizeof(image_header)))
        self.logger.info('FW header: 0, %d', sizeof(image_header))

        self.capsule_list = []
        for i in range(image_header.num_of_fw):
            desc_offset = sizeof(DOWNLOAD_FILE_MANIFEST_T) + i * sizeof(FW_DESCRIPTOR_T)
            fw_desc = FW_DESCRIPTOR_T.from_address(image_address + desc_offset)
            self.image_list.extend(list(range(desc_offset, desc_offset + sizeof(fw_desc))))
            self.logger.info('FW desc %d: %d, %d', i, desc_offset, sizeof(fw_desc))
            self.logger.info('FW capsule %d: %d, %d', i, fw_desc.offset, fw_desc.size)

            cap_header = CAPSULE_HDR_FMT_T.from_address(image_address + fw_desc.offset)
            capsule = list(range(fw_desc.offset, fw_desc.offset + sizeof(cap_header)))
            self.logger.info('FW capsule %d header: %d, %d', i, fw_desc.offset, sizeof(cap_header))

            code_offset = fw_desc.offset + cap_header.code_desc.offset
            capsule.extend(list(range(code_offset, code_offset + cap_header.code_desc.size)))
            self.logger.info('FW capsule %d code: %d, %d', i, code_offset, cap_header.code_desc.size)
            # package_header = IMAGE_PACKAGE_MANIFEST_T.from_address(image_address + code_offset)
            # index_list.extend([list(range(code_offset, code_offset + sizeof(package_header)))])
            # self.logger.info('FW package header {i}: {code_offset, sizeof(package_header)}')

            # for j in range(package_header.num_image):
            #     package_offset = code_offset + sizeof(package_header) + j * sizeof(IMAGE_DESCRIPTOR_T)
            #     package_desc = IMAGE_DESCRIPTOR_T.from_address(image_address + package_offset)
            #     index_list.extend([list(range(package_offset, package_offset + sizeof(package_desc)))])
            #     self.logger.info('FW package desc {i}.{j} {package_offset, sizeof(package_desc)}')

            #     package_code_offset = code_offset + package_desc.offset
            #     index_list.extend([list(range(package_code_offset, package_code_offset + package_desc.size))])
            #     self.logger.info('FW package code {i}.{j} {package_code_offset, package_desc.size}')

            if cap_header.cap_prot & 0x3 == 1:      # UNSECURE
                key_desc = cap_header.prot.unsecure.image_crc32_desc
                key_offset = fw_desc.offset + key_desc.offset
            elif cap_header.cap_prot & 0x3 == 2:    # RSA
                key_desc = cap_header.prot.rsa.key0_cert_desc
                key_offset = fw_desc.offset + key_desc.offset
            elif cap_header.cap_prot & 0x3 == 3:    # HMAC
                key_desc = cap_header.prot.hmac.image_hmac_desc
                key_offset = fw_desc.offset + key_desc.offset
            capsule.extend(list(range(key_offset, key_offset + key_desc.size)))
            self.logger.info('FW capsule %d key: %d, %d', i, key_offset, key_desc.size)
            self.capsule_list.append(capsule)

    def init_image(self):
        assert self.image, f'Invalid image: {self.image}'
        with open(self.image, 'rb') as file:
            self.image_bytes = file.read()
        self.get_inject_list()

    def get_inject_image(self):
        image_buf = (c_uint8 * len(self.image_bytes))()
        memmove(image_buf, bytes(self.image_bytes), sizeof(image_buf))

        if random.randint(0, 1):
            address_list = [random.choice(self.image_list)]
            self.logger.info('inject fw image: %s', address_list)
        else:
            address_list = [random.choice(capsule) for capsule in self.capsule_list]
            self.logger.info('inject fw capsule: %s', address_list)

        for address in address_list:
            image_buf[address] = ~image_buf[address]

        return image_buf
