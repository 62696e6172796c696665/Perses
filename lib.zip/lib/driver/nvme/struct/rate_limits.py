#!/usr/bin/env python
# pylint: disable=superfluous-parens,missing-docstring,too-few-public-methods
"""
Created on 20/1, 2021

@author: wwang
"""
from ctypes import Structure, c_uint8, c_uint16, c_uint32


class RateLimitEntry(Structure):
    _pack_ = 1
    _fields_ = [
        ('LIMITER_OP', c_uint8),
        ('LIMITER_ID', c_uint8),
        ('RSVD0', c_uint16),
        ('IOW_VAL', c_uint32, 16),
        ('IOR_VAL', c_uint32, 16),
        ('CTRL_MASK', c_uint8 * 10),
        ('RSVD1', c_uint16),
        ('IOW_STA', c_uint32, 32),
        ('IOR_STA', c_uint32, 32),
        ('IOW_CTR_VAL', c_uint32, 32),
        ('IOR_CTR_VAL', c_uint32, 32),
        ('IOW_OVERFLOW_CTR_VAL', c_uint32, 32),
        ('IOR_OVERFLOW_CTR_VAL', c_uint32, 32),
        ('STATUS', c_uint8),
        ('RSVD3', c_uint8 * 19)

    ]
    desc = {
        'LIMITER_OP': 'Opcode for the limiter',
        'LIMITER_ID': 'LIMITER_ID',
        'IOW_VAL': 'write throttled rate',
        'IOR_VAL': 'read throttled rate',
        'CTRL_MASK': 'Bitmap of all controller ID  to be controlled by the limite',
        'IOW_STA': 'Saturation value for IOW credits in sectors (4Kib)',
        'IOR_STA': 'Saturation value for IOR credits in sectors (4Kib)',
        'IOW_CTR_VAL': 'Amount of sector (4KiB) credits to add to limiter Write counter',
        'IOR_CTR_VAL': 'Amount of sector (4KiB) credits to add to limiter Read counter',
        'IOW_OVERFLO W_CTR_VAL': 'Write overflow counter',
        'IOR_OVERFLO W_CTR_VAL': 'Read overflow counter',
        'STATUS': 'command status'
    }


class RateLimit(Structure):
    """Rate Limit"""
    _pack_ = 1
    _fields_ = [
        ('Designator', RateLimitEntry * 64)  # rate limit data structure
    ]
    desc = {
        'Designator': 'Limiter Descriptors'
    }
