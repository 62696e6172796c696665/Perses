#!/usr/bin/env python
# pylint: disable=superfluous-parens,missing-docstring,too-few-public-methods
"""
Created on Apr 19, 2019

@author: yyang
"""
from ctypes import Structure, c_uint8, c_uint16, c_uint32, c_uint64, Union

from lib.driver.utils.ctype import Uint128, Byte


class LogPageData(Structure):
    _pack_ = 1
    _fields_ = [("BYTES", c_uint8 * 512)]


class ErrorInformation(Structure):
    """Get Log Page - Error Information (Log Identifier 01h)"""
    _pack_ = 1
    _fields_ = [
        ("COUNT", c_uint64),  # Error Count
        ("SQID", c_uint16),  # Submission Queue ID
        ("CID", c_uint16),  # Command ID
        ("STATUS", c_uint16),  # Status Field
        ("PEL", c_uint16),  # Parameter Error Location
        ("LBA", c_uint64),  # LBA
        ("NSID", c_uint32),  # Namespace
        ("VSIA", c_uint8),  # Vendor Specific Information Available
        ("TRTYPE", c_uint8),  # Transport Type
        ("CSI", c_uint8),  # Command Set Indicator
        ("OPCODE", c_uint8),  # Opcode
        ("CS", c_uint64),  # Command Specific Information
        ("TRTYPE_SPEC_INFO", c_uint16),  # Transport Type Specific Information
        ("RSVD", c_uint8 * 21),  # Reserved: [62:42]
        ("LOG_PAGE_VERSION", c_uint8),  # If set to 1h, csi and opcode will have valid values.
    ]
    desc = {
        'COUNT': 'Error Count', 'SQID': 'Submission Queue ID', 'CID': 'Command ID', 'STATUS': 'Status Field',
        'PEL': 'Parameter Error Location', 'LBA': 'LBA', 'NSID': 'Namespace',
        'VSIA': 'Vendor Specific Information Available',
        'TRTYPE': 'Transport Type', 'CSI': 'Command Set Indicator',
        'CS': 'Command Specific Information'
    }


class SmartHealthInformation(Structure):
    """Get Log Page - SMART/Health Information (Log Identifier 02h)"""
    _pack_ = 1
    _fields_ = [
        ('CW', c_uint8),  # Critical Warning
        ('CT', c_uint16),  # Composite Temperature
        ('AS', c_uint8),  # Available Spare
        ('AST', c_uint8),  # Available Spare Threshold
        ('PU', c_uint8),  # Percentage Used
        ('EGCWS', c_uint8),  # Endurance Group Critical Warning Summary
        ('RSV0', c_uint8 * 25),
        ('DUR', Uint128),  # Data Units Read
        ('DUW', Uint128),  # Data Units Write
        ('HRC', Uint128),  # Host Read Commands
        ('HWC', Uint128),  # Host Write Commands
        ('CBT', Uint128),  # Controller Busy Time
        ('PC', Uint128),  # Power Cycles
        ('POH', Uint128),  # Power On Hours
        ('US', Uint128),  # Unsafe Shutdowns
        ('MDIE', Uint128),  # Media and Data Integrity Errors
        ('NEILE', Uint128),  # Number of Error Information Log Entries
        ('WCTT', c_uint32),  # Warning Composite Temperature Time
        ('CCTT', c_uint32),  # Critical Composite Temperature Time
        ('TS', c_uint16 * 8),  # Temperature Sensor 1 ~ 8
        ('TMT1TC', c_uint32),  # Thermal Management Temperature 1 Transition Count
        ('TMT2TC', c_uint32),  # Thermal Management Temperature 2 Transition Count
        ('TTFTMT1', c_uint32),  # Total Time For Thermal Management Temperature 1
        ('TTFTMT2', c_uint32),  # Total Time For Thermal Management Temperature 2
        ('RSV1', c_uint8 * 280),
    ]
    desc = {
        'CW': 'Critical Warning', 'CT': 'Composite Temperature', 'AS': 'Available Spare',
        'AST': 'Available Spare Threshold', 'PU': 'Percentage Used',
        'EGCWS': 'Endurance Group Critical Warning Summary', 'DUR': 'Data Units Read',
        'DUW': 'Data Units Write', 'HRC': 'Host Read Commands', 'HWC': 'Host Write Commands',
        'CBT': 'Controller Busy Time', 'PC': 'Power Cycles', 'POH': 'Power On Hours',
        'US': 'Unsafe Shutdowns', 'MDIE': 'Media and Data Integrity Errors',
        'NEILE': 'Number of Error Information Log Entries', 'WCTT': 'Warning Composite Temperature Time',
        'CCTT': 'Critical Composite Temperature Time', 'TS': 'Temperature Sensor',
        'TMT1TC': 'Thermal Management Temperature 1 Transition Count',
        'TMT2TC': 'Thermal Management Temperature 2 Transition Count',
        'TTFTMT1': 'Total Time For Thermal Management Temperature 1',
        'TTFTMT2': 'Total Time For Thermal Management Temperature 2',
    }


class OPCSetValue(Structure):
    _pack_ = 1
    _fields_ = [
        ('TYPE', c_uint32),
        ('VALUE', Uint128),
        ('RSV', c_uint8 * 492),
    ]


class OCPSmartHealthExtend(Structure):
    _pack_ = 1
    _fields_ = [
        ('PMUW', Uint128),  # Physical Media Units Written
        ('PMUR', Uint128),  # Physical Media Units Read
        ('BUNBR', c_uint64, 48), # Bad User NAND Blocks (Raw count)
        ('BUNBN', c_uint64, 16), # Bad User NAND Blocks (Normalized Value)
        ('BSNBR', c_uint64, 48), # Bad System NAND Blocks (Raw count)
        ('BSNBN', c_uint64, 16), # Bad System NAND Blocks (Normalized Value)
        ('XOR', c_uint64),  # XOR Recovery Count
        ('UECC', c_uint64), # Uncorrectable Read Error Count
        ('ECC', c_uint64),  # Soft ECC Error Count
        ('E2ED', c_uint64, 32), # End to End Correction Counts (Detected Errors)
        ('E2EC', c_uint64, 32), # End to End Correction Counts (Corrected Errors)
        ('SDU', c_uint64, 8),   # System Data Used
        ('RFC', c_uint64, 56),  # Refresh Counts
        ('UDECMIN', c_uint64, 32),     # User Data Erase Counts (Min)
        ('UDECMAX', c_uint64, 32),     # User Data Erase Counts (Max)
        ('TTC', c_uint64, 8),   # Number Of Thermal Throttling Events
        ('TTS', c_uint64, 8),   # Current Thermal Throttling Status
        ('DSSDSV', c_uint64, 48),   # DSSD Specification Version
        ('PCEC', c_uint64),         # PCIe Correctable Error Count
        ('IS', c_uint32),           # Incomplete Shutdowns
        ('RSV0', c_uint32),
        ('POFB', c_uint64, 8),      # % Free Blocks
        ('RSV1', c_uint64, 56),
        ('CH', c_uint64, 16),       # Capacitor Health
        ('NVMEV', c_uint64, 8),     # NVMe Errata Version
        ('RSV2', c_uint64, 40),
        ('UIO', c_uint64),          # Unaligned I/O
        ('SVN', c_uint64),          # Security Version Number
        ('NUSE', c_uint64),         # Total NUSE
        ('PLP', Uint128),           # PLP Start Count
        ('EE', Uint128),            # Endurance Estimate
        ('PLRC', c_uint64),         # PCIe Link Retraining Count
        ('PSCC', c_uint64),         # Power State Change Count
        ('RSV3', c_uint8 * 286),
        ('LPV', c_uint16),          # Log Page Version
        ('LPG', Uint128),           # Log Page GUID
    ]


class FirmwareSlotInformation(Structure):
    """Get Log Page - Firmware Slot Information (Log Identifier 03h)"""
    _pack_ = 1
    _fields_ = [
        ('AFI', c_uint8),  # Active Firmware Info (AFI)
        ('RSV0', c_uint8 * 7),
        ('FRS', (Byte * 8) * 7),  # Firmware Revision for Slot
        ('RSV1', c_uint8 * 4032)
    ]
    desc = {
        'AFI': 'Active Firmware Info', 'FRS': 'Firmware Revision for Slot',
    }


class DellEMCUniqueLogPage(Structure):
    """Get Log Page - Firmware Slot Information (Log Identifier 03h)"""
    _pack_ = 1
    _fields_ = [
        ('lpr', c_uint8 * 2),  # Active Firmware Info (AFI)
        ('sau', c_uint8),
        ('mdo', c_uint8),  # Firmware Revision for Slot 1 (FRS1)
        ('mts', c_uint8),  # Firmware Revision for Slot 2 (FRS2)
        ('rsv0', c_uint8 * 27),  # Firmware Revision for Slot 3 (FRS3)
        ('mtbw', c_uint32 * 4),  # Firmware Revision for Slot 4 (FRS4)
        ('mtbr', c_uint32 * 4),  # Firmware Revision for Slot 5 (FRS5)
        ('htbr', c_uint32 * 4),
        ('htbw', c_uint32 * 4),
        ('nminec', c_uint32 * 2),
        ('navgec', c_uint32 * 2),
        ('nmaxec', c_uint32 * 2),
        ('pecycle', c_uint32 * 2),
        ('sra', c_uint32 * 2),
        ('srf', c_uint32 * 2),
        ('gbb', c_uint32 * 2),
        ('pbb', c_uint32 * 2),
        ('drc', c_uint32),
        ('tuc', c_uint32),
        ('endurance', c_uint32),
        ('pfc', c_uint32 * 2),
        ('efc', c_uint32 * 2),
        ('rfc', c_uint32 * 2),
        ('ct', c_uint32 * 2),
        ('buferror', c_uint32 * 2),
        ('ttc', c_uint32 * 2),
        ('tts', c_uint8 * 1),
        ('rsv1', c_uint8 * 7),
        ('sapfc', c_uint32 * 2),
        ('sarfc', c_uint32 * 2),
        ('saefc', c_uint32 * 2),
        ('pcec', c_uint32 * 4),
        ('ngsc', c_uint32 * 2),
        ('rfrsc', c_uint32 * 2),
        ('stwa', c_uint32 * 2),
        ('ltwa', c_uint32 * 2),
        ('rc', c_uint32 * 2),
        ('bss', c_uint8 * 1),
        ('rsv2', c_uint8 * 3),
        ('bsc', c_uint32),
        ('bpsc', c_uint32 * 2),
        ('bphc', c_uint32 * 2),
        ('bod', c_uint32 * 2),
        ('ac', c_uint32),
        ('erc', c_uint32),
        ('vtmc', c_uint32),
        ('vtmcslp', c_uint32),
        ('hwver', c_uint32),
        ('shrc', c_uint32 * 4),
        ('shwc', c_uint32 * 4),
        ('sbt', c_uint32 * 4),
        ('dcc', c_uint32 * 4),
        ('dudc', c_uint32 * 4),
        ('rsv3', c_uint32 * 20)
    ]
    desc = {
        'lpr': 'Log Page Revision',
        'sau':'System Area % Used',
        'mdo':'Media Dies Offline ',
        'mts':'Max Temperature Seen',
        'mtbw':'Media Total Bytes Written',
        'mtbr':'Media Total Bytes Read',
        'htbr':'Host Total Bytes Read',
        'htbw':'Host Total Bytes Written',
        'nminec':'NAND Min. Erase Count',
        'navgec':'NAND Avg. Erase Count',
        'nmaxec':'NAND Max. Erase Count',
        'pecycle':'Media EOL PE Cycle Count',
        'sra':'SSD Rebuild Activates',
        'srf':'SSD Rebuild Fails',
        'gbb':'Count of Grown Defects',
        'pbb':'Count of Primary Defects',
        'drc':'Device Raw Capacity ',
        'tuc':'Total User Capacity ',
        'endurance':'SSD Endurance',
        'pfc':'Program Fail Count',
        'efc':'Erase Fail Count',
        'rfc':'Erase Fail Count',
        'ct':'Erase Fail Count',
        'buferror':'Buffer (SRAM/DRAM) Errors ',
        'ttc':'Thermal Throttle Count',
        'tts':'Thermal Throttle Status',
        'sapfc':'System Area Program Fail Count',
        'sarfc':'System Area Read Fail Count',
        'saefc':'System Area Erase Fail Count',
        'pcec':'PCIe Correctable Error Count',
        'ngsc':'Non-Graceful Shutdown Count',
        'rfrsc':'Read Fail Recovery Step Count ',
        'stwa':'Short Term Write Amplification',
        'ltwa':'Long Term Write Amplification',
        'rc':'Refresh Count',
        'bss':'Refresh Count',
        'bsc':'Background Scan Count',
        'bpsc':'Background Process Soft Count',
        'bphc':'Background Process Hard Count',
        'bod':'Born on Date',
        'ac':'Assert Count ',
        'erc':'Assert Count ',
        'vtmc':'V2P Table Metadata Corruptions',
        'vtmcslp':'V2P Table Metadata Corruptions Since Last Power on',
        'hwver':'Supplier firmware-visible hardware revision',
        'shrc':'Subsystem Host Read Commands',
        'shwc':'Subsystem Host Write Commands',
        'sbt':'Subsystem Busy Time',
        'dcc':'Deallocate Command Counter',
        'dudc':'Data Units Deallocated Counter',
    }


class ChangedNamespaceList(Structure):
    """Get Log Page - Changed Namespace list data structure"""
    _pack_ = 1
    _fields_ = [
        ('ID', c_uint64 * 1024)
    ]
    desc = {
        'ID': 'Identifier Index',
    }


class CommandEffectDataStructure(Structure):
    """Get Log Page - Command Effect Data Structure (Log Identifier 05h)"""
    _pack_ = 1
    _fields_ = [
        ('CSUPP', c_uint32, 1),
        ('LBCC', c_uint32, 1),
        ('NCC', c_uint32, 1),
        ('NIC', c_uint32, 1),
        ('CCC', c_uint32, 1),
        ('RSV0', c_uint32, 11),
        ('CSE', c_uint32, 3),
        ('UUIDSS', c_uint32, 1),
        ('RSV1', c_uint32, 12)
    ]


class CommandsSupportAndEffects(Structure):
    _pack_ = 1
    _fields_ = [
        ('ACS', CommandEffectDataStructure * 256),
        ('IOCS', CommandEffectDataStructure * 256),
        ('RSV', c_uint8 * 2048),
    ]
    desc = {
        'ACS': 'Admin Command Supported', 'IOCS': 'I/O Command Supported',
    }


class SelfTestResult(Structure):
    """Get Log Page - Device Self-test data structure"""
    _pack_ = 1
    _fields_ = [
        ('DSTS', c_uint8),
        ('SN', c_uint8),
        ('VDI', c_uint8),
        ('RSV', c_uint8),
        ('POH', c_uint64),
        ('NSID', c_uint32),
        ('FLBA', c_uint64),
        ('SCT', c_uint8),
        ('SC', c_uint8),
        ('VS', c_uint16)
    ]
    desc = {
        'DSTS': 'device selt-test status', 'SN': 'segment number', 'VDI': 'valid diagnostic information',
        'POH': 'power on hours', 'NSID': 'namespace identifier', 'FLBA': 'failing lba',
        'SCT': 'status code type', 'SC': 'status code', 'VS': 'vendor specific',
    }


class SelfTestLog(Structure):
    """Get Log Page - Device Self-test (Log Identifier 06h)"""
    _pack_ = 1
    _fields_ = [
        ('CDSTO', c_uint8),  # current device self-test operation
        ('CDSTC', c_uint8),  # current device self-test completion
        ('RSV', c_uint16),
        ('RESULT', SelfTestResult * 20)  # self test result data structure
    ]
    desc = {
        'CDSTO': 'current device self-test operation', 'CDSTC': 'current device self-test completion',
        'RESULT': 'self test result data structure',
    }


class TelemetryDataBlock(Structure):
    """Get Log Page - Telemetry Data Block Structure"""
    _pack_ = 1
    _fields_ = [
        ('DATA', c_uint8 * 512),  # Telemetry Data Block
    ]
    desc = {
        'DATA': 'Telemetry Data Block',
    }


class TelemetryHostInitiated(Structure):
    """Get Log Page - Telemetry Host-Initiated Log(Log Identifier 07h)"""
    _pack_ = 1
    _fields_ = [
        ('LID', c_uint8),  # Log Identifier, This field shall be set to 07h.
        ('RSV0', c_uint32),  # Reserved 0
        ('IEEE', c_uint8 * 3),  # IEEE OUI Identifier
        ('THIDA1LB', c_uint16),  # Telemetry Host-Initiated Data Area 1 Last Block
        ('THIDA2LB', c_uint16),  # Telemetry Host-Initiated Data Area 2 Last Block
        ('THIDA3LB', c_uint16),  # Telemetry Host-Initiated Data Area 3 Last Block
        ('RSV1', c_uint8 * 368),  # Reserved 1
        ('TCIDA', c_uint8),  # Telemetry Controller-Initiated Data Available
        ('TCIDGN', c_uint8),  # Telemetry Controller-Initiated Data Generation Number
        ('RID', c_uint8 * 128),  # Reason Identifier
        ('THIDB', TelemetryDataBlock * 7),  # Telemetry Host-Initiated Data Block 1 - n
    ]
    desc = {
        'LID': 'Log Identifier', 'IEEE': 'IEEE OUI Identifier',
        'THIDA1LB': 'Telemetry Host-Initiated Data Area 1 Last Block',
        'THIDA2LB': 'Telemetry Host-Initiated Data Area 2 Last Block',
        'THIDA3LB': 'Telemetry Host-Initiated Data Area 3 Last Block',
        'TCIDA': 'Telemetry Controller-Initiated Data Available',
        'TCIDGN': 'Telemetry Controller-Initiated Data Generation Number',
        'RID': 'Reason Identifier', 'THIDB': 'Telemetry Host-Initiated Data Block',
    }


class TelemetryControllerInitiated(Structure):
    """Get Log Page - Telemetry Controller-Initiated Log(Log Identifier 08h)"""
    _pack_ = 1
    _fields_ = [
        ('LID', c_uint8),  # Log Identifier, This field shall be set to 08h.
        ('RSV0', c_uint32),  # Reserved 0
        ('IEEE', c_uint8 * 3),  # IEEE OUI Identifier
        ('TCIDA1LB', c_uint16),  # Telemetry Controller-Initiated Data Area 1 Last Block
        ('TCIDA2LB', c_uint16),  # Telemetry Controller-Initiated Data Area 2 Last Block
        ('TCIDA3LB', c_uint16),  # Telemetry Controller-Initiated Data Area 3 Last Block
        ('RSV1', c_uint8 * 368),  # Reserved 1
        ('TCIDA', c_uint8),  # Telemetry Controller-Initiated Data Available
        ('TCIDGN', c_uint8),  # Telemetry Controller-Initiated Data Generation Number
        ('RID', c_uint8 * 128),  # Reason Identifier
        ('TCIDB', TelemetryDataBlock * 7),  # Telemetry Host-Initiated Data Block 1 - n
    ]
    desc = {
        'LID': 'Log Identifier', 'IEEE': 'IEEE OUI Identifier',
        'TCIDA1LB': 'Telemetry Controller-Initiated Data Area 1 Last Block',
        'TCIDA2LB': 'Telemetry Controller-Initiated Data Area 2 Last Block',
        'TCIDA3LB': 'Telemetry Controller-Initiated Data Area 3 Last Block',
        'TCIDA': 'Telemetry Controller-Initiated Data Available',
        'TCIDGN': 'Telemetry Controller-Initiated Data Generation Number',
        'RID': 'Reason Identifier', 'TCIDB': 'Telemetry Controller-Initiated Data Block',
    }


class PersistentEventLog(Structure):
    _pack_ = 1
    _fields_ = [
        ('lid', c_uint8),               # Log Identifier
        ('rsvd1', c_uint8 * 3),         # Reserved
        ('tnev', c_uint32),             # Total Number of Events
        ('tll', c_uint64),              # Total Log Length
        ('rv', c_uint8),                # Log Revision
        ('rsvd17', c_uint8),            # Reserved
        ('lhl', c_uint16),              # Log Header Length
        ('ts', c_uint64),               # Timestamp
        ('poh', Uint128),               # Power on Hours
        ('pcc', c_uint64),              # Power Cycle Count
        ('vid', c_uint16),              # PCI Vendor ID
        ('ssvid', c_uint16),            # PCI Subsystem Vendor ID
        ('sn', Byte * 20),              # Serial Number
        ('mn', Byte * 40),              # Model Number
        ('subnqn', Byte * 256),         # NVM Subsystem NVMe Qualified Name
        ('gen_number', c_uint16),       # Generation Number
        ('rci', c_uint32),              # Reporting Context Information
        ('rsvd378', c_uint8 * 102),     # Reserved
        ('seb', Uint128 * 2),           # Supported Events Bitmap
    ]


class PersistentEventEntry(Structure):
    _pack_ = 1
    _fields_ = [
        ('etype', c_uint8),
        ('etype_rev', c_uint8),
        ('ehl', c_uint8),
        ('ehai', c_uint8),
        ('cntlid', c_uint16),
        ('ets', c_uint64),
        ('pelpid', c_uint16),
        ('rsvd16', c_uint8 * 4),
        ('vsil', c_uint16),
        ('el', c_uint16),
    ]


class ReservationNotificationLog(Structure):
    """Get Log Page - Reservation Notification (Log Identifier 80h)"""
    _pack_ = 1
    _fields_ = [
        ('LPC', c_uint64),
        ('RNLPT', c_uint8),
        ('NALP', c_uint8),
        ('RSV0', c_uint8 * 2),
        ('NSID', c_uint32),
        ('RSV1', c_uint8 * 48),
    ]
    desc = {
        'LPC': 'Log Page Count', 'RNLPT': 'Reservation Notification Log Page Type',
        'NALP': 'Number of Available Log Pages', 'NSID': 'Namespace ID:',
    }


class SanitizeStatusLog(Structure):
    """Get Log Page - Reservation Notification (Log Identifier 81h)"""
    _pack_ = 1
    _fields_ = [
        ('SPROG', c_uint16),
        ('SSTAT', c_uint16),
        ('SCDW10', c_uint32),
        ('ETFO', c_uint32),
        ('ETFBE', c_uint32),
        ('ETFCE', c_uint32),
        ('ETFOWND', c_uint32),
        ('ETFBEWND', c_uint32),
        ('ETFCEWND', c_uint32),
        ('RAV0', c_uint8 * 480),
    ]
    desc = {
        'SPROG': 'Sanitize Progress', 'SSTAT': 'Sanitize Status',
        'SCDW10': 'Sanitize Command Dword 10 Information', 'ETFO': 'Estimated Time For Overwrite',
        'ETFBE': 'Estimated Time For Block Erase', 'ETFCE': 'Estimated Time For Crypto Erase:',
        'ETFOWND': 'Estimated Time For Overwrite With No-Deallocate Media Modification',
        'ETFBEWND': 'Estimated Time For Block Erase With No-Deallocate Media Modification',
        'ETFCEWND': 'Estimated Time For Crypto Erase With No-Deallocate Media Modification',
    }


class BadBlockHeader(Structure):
    """Get Log Page - CNEX Bad Block (Log Identifier CBh)"""
    _pack_ = 1
    _fields_ = [
        ('SN', Byte * 20),  # Serial Number
        ('RN', c_uint32),  # Revision Number
        ('NE', c_uint32),  # NAND Entities
        ('NOF', c_uint32),  # Number Of FBB
        ('NOM', c_uint32),  # Number Of MBB
        ('NOG', c_uint32),  # Number Of GBB
        ('FBS', c_uint32),  # FBB Bitmap Start
        ('MBS', c_uint32),  # MBB Bitmap Start
        ('GBS', c_uint32),  # GBB Bitmap Start
        ('BDS', c_uint32),  # BB Details Start
        ('TL', c_uint32),  # Total Length
        ('UUID', Uint128 * 128),  # UUIDs
        ('RSV', c_uint8 * 1988),
    ]
    desc = {
        'SN': 'Serial Number', 'RN': 'Revision Number', 'NE': 'NAND Entities', 'NOF': 'Number Of FBB',
        'NOM': 'Number Of MBB', 'NOG': 'Number Of GBB', 'FBS': 'FBB Bitmap Start', 'MBS': 'MBB Bitmap Start',
        'GBS': 'GBB Bitmap Start', 'BDS': 'BB Details Start', 'TL': 'Total Length',
    }


class BadBlockDetails(Union):
    """Get Log Page - CNEX Bad Block (Log Identifier CBh)"""

    class BITS(Structure):
        _pack_ = 1
        _fields_ = [
            ('TYPE', c_uint64, 3),  # 0: Erase Error, 1: Write Error, 2: Read Error
            ('POT', c_uint64, 13),  # Power On Time
            ('PC', c_uint64, 16),  # PE Cycle
            ('BL', c_uint64, 13),
            ('PL', c_uint64, 3),
            ('LN', c_uint64, 4),
            ('CH', c_uint64, 4),
            ('RSV', c_uint64, 8),
        ]
        desc = {
            'POT': 'Power On Time', 'PC': 'PE Cycle', 'BL': 'Block', 'PL': 'Plane',
            'LN': 'Lun', 'CH': 'Channel'
        }

    _anonymous_ = ('BITS',)
    _fields_ = [
        ('QWORD', c_uint64),
        ('DWORD', c_uint32 * 2),
        ('BITS', BITS),
    ]


class VendorUniqueLog(Structure):
    _pack_ = 1
    _fields_ = [
        ('RSV0', c_uint8 * 212),
        ('THERMAL_COUNT', c_uint64),
        ('THERMAL_STATUS', c_uint8),
        ('RSV1', c_uint8 * 291),
    ]
