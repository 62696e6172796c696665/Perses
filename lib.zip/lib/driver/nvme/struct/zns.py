#!/usr/bin/env python
"""
Created on Apr 19, 2019

@author: yyang
"""
from ctypes import Structure, c_uint8, c_uint16, c_uint32, c_uint64, Union
from enum import IntEnum

class ZoneAction(IntEnum):
    CLOSE_ZONE = 1
    FINISH_ZONE = 2
    OPEN_ZONE = 3
    RESET_ZONE = 4
    OFFLINE_ZONE = 5
    SET_ZONE_DESCRIPTOR = 0x10

# Zone namespace related structure
class ZNSMgmtSendDW13(Union):
    class BITS(Structure):
        _pack_ = 1
        _fields_ = [
            ('ZSA', c_uint32, 8),
            ('SELALL', c_uint32, 1),
            ('RSV', c_uint32, 23),
        ]

    _anonymous_ = ('BITS',)
    _fields_ = [
        ('DWORD', c_uint32),
        ('BITS', BITS),
    ]

class ZNSMgmtReceiveDW13(Union):
    class BITS(Structure):
        _pack_ = 1
        _fields_ = [
            ('ZRA', c_uint8),
            ('ZRASF', c_uint8),
            ('ZRASFEA', c_uint16, 1),
            ('RSV', c_uint16, 15),
        ]

    _anonymous_ = ('BITS',)
    _fields_ = [
        ('DWORD', c_uint32),
        ('BITS', BITS),
    ]

class ZoneAttr(Structure):
    _pack_ = 1
    _fields_ = [
        ('ZFC', c_uint8, 1),
        ('FZR', c_uint8, 1),
        ('RZR', c_uint8, 1),
        ('RSV', c_uint8, 4),
        ('ZDEV', c_uint8, 1),
    ]

class ZoneAttrInfo(Structure):
    _pack_ = 1
    _fields_ = [
        ('FZRTL', c_uint8, 2),
        ('RZRTL', c_uint8, 2),
        ('RSV', c_uint8, 4),
    ]

class ZoneDescriptor(Structure):
    _pack_ = 1
    _fields_ = [
        ('ZT', c_uint8, 4),
        ('RSV1', c_uint8, 4),
        ('RSV2', c_uint8, 4),
        ('ZS', c_uint8, 4),
        ('ZA', ZoneAttr),
        ('ZAI', ZoneAttrInfo),
        ('RSV3', c_uint8*4),
        ('ZCAP', c_uint64),
        ('ZSLBA', c_uint64),
        ('WP', c_uint64),  # Descriptor Type Specific
        ('RSV4', c_uint8*32)  # SGL Descriptor Type
    ]

class ReportZonesDataStructure(Structure):
    _pack_ = 1
    _fields_ = [
        ('NZ', c_uint64),
        ('RSV', c_uint8*56),
        ('ZD', ZoneDescriptor*63),
    ]

def dynamic_extended_zones_data(zdes):
    class ExtendedZonesData(Structure):
        _pack_ = 1
        _fields_ = [
            ('ZD', ZoneDescriptor),
            ('ZDE', c_uint64*int(zdes)),
        ]
    class ExtendedReportZonesDataStructure(Structure):
        _pack_ = 1
        _fields_ = [
            ('NZ', c_uint64),
            ('RSV', c_uint8*56),
            ('EZD', ExtendedZonesData*63),
        ]
    return ExtendedReportZonesDataStructure()
