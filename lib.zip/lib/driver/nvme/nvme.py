#!/usr/bin/env python
# pylint: disable=invalid-name,too-many-locals,arguments-differ,arguments-renamed,redefined-argument-from-local,keyword-arg-before-vararg
"""
Created on 2019/4/26

@author: yyang
"""
import math
import time
import struct
from time import sleep

from lib.driver.utils import buf
from lib.driver.nvme.ioctl import IO, ADMIN
from lib.driver.utils.ctype import byte_array_to_string
from lib.driver.nvme.struct.hmb import HMB
from lib.driver.nvme.struct.zns import ZNSMgmtSendDW13, ZoneAction, ZNSMgmtReceiveDW13, dynamic_extended_zones_data
from lib.driver.nvme.utility_vu import *
from lib.driver.utils.pcie import PCIe

LOG = logging.getLogger()


class NVMe(IO, ADMIN):
    def __init__(self, cntid=0, nsid=1, block=None, slot=None):
        super().__init__(cntid, nsid, block, slot)
        self.__pcie = None
        self.__id_ns = None
        self.__id_ctrl = None
        self.__active_nsid_list = None

        self.scan_devices()

    @property
    def pcie(self):
        return self.__pcie

    @property
    def id_ns(self):
        return self.__id_ns

    @property
    def id_ctrl(self):
        return self.__id_ctrl

    @property
    def active_nsid_list(self):
        return self.__active_nsid_list

    @property
    def max_valid_nsid(self):
        return self.id_ctrl.NN

    @property
    def max_lba(self):
        return self.id_ns.NCAP - 1

    @property
    def flbas(self):
        return self.id_ns.FLBAS

    @property
    def is_dif(self):
        return self.flbas & 0x10

    @property
    def lbaf(self):
        return self.id_ns.LBAF[self.flbas & 0xF]

    @property
    def lbads(self):
        return 2 ** self.lbaf.LBADS

    @property
    def lbams(self):
        return self.lbaf.MS

    @property
    def lbaf_list(self):
        return [{"LBAF": i, "LBADS": 2 ** f.LBADS, "LBAMS": f.MS} for i, f in enumerate(self.id_ns.LBAF) if f.LBADS]

    @property
    def mpsmin(self):
        return (self.pcie.uint32(0x4) >> 16) & 0xF  # Memory Page Size Minimum

    @property
    def mdts(self):
        return (2 ** (12 + self.mpsmin)) * (2 ** self.id_ctrl.MDTS)

    def scan_devices(self, nsid=None, block=None):
        super().scan_devices(nsid=nsid, block=block)
        # LOG.info(self.node)     # Default node info

        # Check CSTS.Ready
        self.__pcie = PCIe(self.char_dev)
        csts_rdy = self.__pcie.uint32(0x1C) & 0x1
        assert csts_rdy == 1, f'CSTS.Ready = {csts_rdy}'

        # Identify Ctrl & Update cntid
        self.__id_ctrl = self.identify_ctrl()
        if self.cntid is None:
            self.cntid = self.__id_ctrl.CNTLID

        # Show device & node
        LOG.info(self.device)   # Show device
        LOG.info(self.node)     # Show node

        # Identify Active Namespace & Check nsid/block ready
        self.__active_nsid_list = [i for i in self.identify_active_ns_list().ID if i != 0]
        for ns_id in self.__active_nsid_list:
            for node in self.nodes:
                if node['nsid'] == ns_id and node['block']:
                    break
            else:
                raise AssertionError(f'NSID({ns_id}) or block deivce is not ready!')

        # Identify Namespace if self.nsid is existed
        self.__id_ns = None if self.nsid is None else self.identify_ns()

    def waiting_device_ready(self, timeout=300, interval=5, nsid=None, block=None):
        timeout += time.time()
        while time.time() < timeout:
            try:
                return self.scan_devices(nsid=nsid, block=block)
            except BaseException as err:
                LOG.info(err)
            time.sleep(interval)

        raise AssertionError('Waiting device ready timeout!')

    def self_test(self, stc, nsid=0, **kwargs):
        return self.device_self_test(stc, nsid=nsid, **kwargs)

    def fw_update(self, ca, fs, stream=None, xfer=0x1000, disorder=False):
        # FW Download
        if stream:
            self.fw_download(stream, xfer=xfer, disorder=disorder)

        # FW Commit
        if ca in [0x0, 0x2]:
            self.fw_commit(ca=0, fs=fs)
            self.fw_commit(ca=2, fs=fs)
            self.reset()
        elif ca in [0x1]:
            self.fw_commit(ca=1, fs=fs)
            self.reset()
        elif ca in [0x3]:
            self.fw_commit(ca=3, fs=fs)
        else:
            raise RuntimeError(f'Not support action: {ca:#x}', )

        # FW Check
        slot_info = self.get_log_fw_slot_info()
        version = byte_array_to_string(slot_info.FRS[slot_info.AFI - 1])
        LOG.info('FS %s, Version: %s', slot_info.AFI, version)
        if fs != 0:
            assert slot_info.AFI == fs, 'FW update slot check failed!'

    def fw_commit(self, ca=3, fs=1, bpid=0, **kwargs):
        LOG.info('NVMe FW Commit %s', self.args_to_str(ca=ca, fs=fs, bpid=bpid, **kwargs))
        stime = time.time()
        try:
            return super().fw_commit(ca=ca, fs=fs, bpid=bpid, **kwargs)
        finally:
            if self.id_ctrl.MTFA:
                etime = time.time()
                assert etime - stime <= self.id_ctrl.MTFA * 0.1, \
                    f'NVMe FW Commit timeout, {etime - stime:.3f} > {self.id_ctrl.MTFA * 0.1:.3f}'

    def fw_download(self, stream, xfer=4096, offset=0, size=0, align=4, disorder=False, **kwargs):
        LOG.info('NVMe FW Download %s', self.args_to_str(xfer=xfer, offset=offset, size=size, **kwargs))
        if isinstance(stream, str):
            with open(stream, 'rb') as file:
                data = file.read()
        elif isinstance(stream, (bytearray, bytes)):
            data = stream
        else:
            data = bytes(stream)

        length = len(data)
        size = size if size > 0 else length - offset
        assert length - offset >= size > 0 and size % 4 == 0, f'Invalid size: {size}'
        assert xfer % align == 0, f'Invalid xfer: {xfer}'

        dptr = (c_uint8 * length)()
        memmove(dptr, data, length)

        image_pieces = [(i, min(xfer, length - i)) for i in range(offset, offset + size, xfer)]
        if disorder:
            random.shuffle(image_pieces)

        for offset, xfer in image_pieces:
            status = super().fw_download(addressof(dptr) + offset, xfer=xfer, offset=offset, **kwargs)
            if status:
                return status
        return 0

    def fw_download_single(self, filename, xfer=0, offset=0, **kwargs):
        file_size = os.path.getsize(filename)
        length = math.ceil(file_size / 4096) * 4096
        dptr = (c_uint8 * length)()
        with open(filename, 'rb') as fd:
            memmove(dptr, fd.read(), file_size)
        addr = addressof(dptr)

        return super().fw_download(addr, xfer=(xfer + 1) << 2, offset=offset << 2, **kwargs)

    def get_features_arbitration(self, sel=0):
        return self.get_features(FeatureID.Arbitration, sel)[1]

    def get_features_power_management(self, sel=0, **kwargs):
        return self.get_features(FeatureID.PowerManagement, sel, **kwargs)[1]

    def get_features_lba_range_type(self, sel=0, nsid=None, **kwargs):
        return self.get_features(FeatureID.LBARangeType, sel, nsid=nsid, **kwargs)[1]

    def get_features_temperature_threshold(self, sel=0, tmpsel=0, thsel=0, **kwargs):
        cdw11 = ((tmpsel & 0xf) << 16) | ((thsel & 0b11) << 20)
        return self.get_features(FeatureID.TemperatureThreshold, sel, cdw11=cdw11, **kwargs)[1]

    def get_features_host_memory_buffer(self, sel=0, **kwargs):
        return self.get_features(FeatureID.HostMemoryBuffer, sel, **kwargs)[2]

    def get_features_non_operational_power_state_config(self, sel=0, **kwargs):
        return self.get_features(FeatureID.NonOperationalPowerStateConfig, sel, **kwargs)[2]

    def get_features_error_recovery(self, sel=0, nsid=None, **kwargs):
        return self.get_features(FeatureID.ErrorRecovery, sel, nsid=nsid, **kwargs)[1]

    def get_features_volatile_write_cache(self, sel=0, **kwargs):
        return self.get_features(FeatureID.VolatileWriteCache, sel, **kwargs)[1]

    def get_features_number_of_queues(self, sel=0, **kwargs):
        return self.get_features(FeatureID.NumberOfQueues, sel, **kwargs)[1]

    def get_features_interrupt_coalescing(self, sel=0, **kwargs):
        return self.get_features(FeatureID.InterruptCoalescing, sel, **kwargs)[1]

    def get_features_interrupt_vector_configuration(self, sel=0, iv=1, **kwargs):
        cdw11 = InterruptVectorConfiguration()
        cdw11.IV = iv
        return self.get_features(FeatureID.InterruptVectorConfiguration, sel, cdw11=cdw11.DWORD, **kwargs)[1]

    def get_features_write_atomicity_normal(self, sel=0, **kwargs):
        return self.get_features(FeatureID.WriteAtomicityNormal, sel, **kwargs)[1]

    def get_features_asynchronous_event_configuration(self, sel=0, **kwargs):
        return self.get_features(FeatureID.AsynchronousEventConfiguration, sel, **kwargs)[1]

    def get_features_autonomous_power_state_transition(self, sel=0, **kwargs):
        return self.get_features(FeatureID.AutonomousPowerStateTransition, sel, **kwargs)[1]

    def get_features_software_progress_marker(self, sel=0, **kwargs):
        return self.get_features(FeatureID.SoftwareProgressMarker, sel, **kwargs)[2]

    def get_features_host_identifier(self, exhid=0, sel=0, **kwargs):
        cdw11 = HostIdentifier()
        cdw11.EXHID = exhid
        return self.get_features(FeatureID.HostIdentifier, sel, cdw11=cdw11.DWORD, **kwargs)[2]

    def get_features_reservation_notification_mask(self, sel=0, nsid=None, **kwargs):
        return self.get_features(FeatureID.ReservationNotificationMask, sel, nsid=nsid, **kwargs)[1]

    def get_features_reservation_persistence(self, sel=0, nsid=None, **kwargs):
        return self.get_features(FeatureID.ReservationPersistence, sel, nsid=nsid, **kwargs)[1]

    def get_features_host_controlled_thermal_management(self, sel=0, **kwargs):
        return self.get_features(FeatureID.HostControlledThermalManagement, sel, **kwargs)[2]

    def get_features_timestamp(self, sel=0, **kwargs):
        return self.get_features(FeatureID.Timestamp, sel, **kwargs)[2]

    def get_features_sanitize_config(self, sel=0, **kwargs):
        return self.get_features(FeatureID.SanitizeConfig, sel, **kwargs)[2]

    def get_features_nonoperational_power_state_config(self, sel=0, **kwargs):
        return self.get_features(FeatureID.NonOperationalPowerStateConfig, sel, **kwargs)[2]

    def get_log_error_info(self, *args, **kwargs):
        dptr = (ErrorInformation * (self.id_ctrl.ELPE + 1))()
        self.get_log(dptr, lid=0x1, *args, **kwargs)
        return dptr

    def get_log_smart_health_info(self, *args, **kwargs):
        dptr = SmartHealthInformation()
        self.get_log(dptr, lid=0x2, *args, **kwargs)
        return dptr

    def get_log_smart_health_info_extend(self):
        dptr = OCPSmartHealthExtend()
        self.get_log(dptr, lid=0xC0)
        return dptr

    def get_log_fw_slot_info(self, *args, **kwargs):
        dptr = FirmwareSlotInformation()
        self.get_log(dptr, lid=0x3, *args, **kwargs)
        return dptr

    def get_log_change_ns_list(self, *args, **kwargs):
        dptr = DeviceSelfTest()
        self.get_log(dptr, lid=0x4, *args, **kwargs)
        return dptr

    def get_log_cmd_supported_effects(self, *args, **kwargs):
        dptr = CommandsSupportAndEffects()
        self.get_log(dptr, lid=0x5, *args, **kwargs)
        return dptr

    def get_log_thermal_throttling_status_count(self):
        dptr = VendorUniqueLog()
        self.get_log(dptr, lid=0xDE, rae=1)
        return dptr.THERMAL_STATUS, dptr.THERMAL_COUNT

    def get_log_device_self_test(self, *args, **kwargs):
        dptr = SelfTestLog()
        self.get_log(dptr, lid=0x6, *args, **kwargs)
        return dptr

    def get_log_telemetry_host_init_log(self, lsp=0x0, *args, **kwargs):
        dptr = TelemetryHostInitiated()
        self.get_log(dptr, lid=0x7, lsp=lsp, *args, **kwargs)
        return dptr

    def get_log_telemetry_ctrl_init_log(self, *args, **kwargs):
        dptr = TelemetryControllerInitiated()
        self.get_log(dptr, lid=0x8, *args, **kwargs)
        return dptr

    def get_log_persistent_log(self, action: int, **kwargs):
        event_log = PersistentEventLog()
        status = self.get_log(event_log, lid=0xd, lsp=action, **kwargs)
        if status:
            return status
        if action == 0:
            log_len = event_log.tll
            pevent_log_info = buf.Malloc(log_len)
            pevent_log_info.memset(0)
            self.get_log(dptr=pevent_log_info.buf, lid=0xd, lsp=action)
            return pevent_log_info
        return 0

    def get_log_reservation_notification(self, *args, **kwargs):
        dptr = ReservationNotificationLog()
        self.get_log(dptr, lid=0x80, *args, **kwargs)
        return dptr

    def get_log_sanitize_status(self, *args, **kwargs):
        dptr = SanitizeStatusLog()
        self.get_log(dptr, lid=0x81, *args, **kwargs)
        return dptr

    def wait_sanitize_completed(self, timeout: int):
        assert timeout > 0, f"unexpected timout value: {timeout}"
        if timeout < 0xFFFFFFFF:
            while self.get_log_sanitize_status().SSTAT & 0b111 == 0b10 and timeout > 0:
                sanitize_progress = self.get_log_sanitize_status().SPROG * 100 // 0xffff
                LOG.info("sanitize in progressing: %d%%, wait complete, timeout: %d", sanitize_progress, timeout)
                timeout -= 1
                time.sleep(1)
            assert timeout > 0, "sanitize timeout"
        else:
            LOG.info("no time period is reported".upper())
            while self.get_log_sanitize_status().SSTAT & 0b111 == 0b10:
                sanitize_progress = self.get_log_sanitize_status().SPROG
                LOG.info("sanitize in progressing: %d, wait complete", sanitize_progress)
                time.sleep(10)
        assert (self.get_log_sanitize_status().SSTAT & 0b111) in [0, 1], "sanitize complete failed"
        sanitize_progress = self.get_log_sanitize_status().SPROG * 100 // 0xffff
        LOG.info("sanitize in progressing: %d%%", sanitize_progress)
        assert self.get_log_sanitize_status().SPROG == 0xffff, "sanitize not completed"

    def identify_ns(self, nsid=None):
        return self.identify(nsid=nsid, cns=0x0)[1]

    def identify_ctrl(self):
        return self.identify(cns=0x1)[1]

    def identify_active_ns_list(self, nsid=0):
        return self.identify(nsid=nsid, cns=0x2)[1]

    def identify_allocated_ns_list(self, nsid=0):
        return self.identify(nsid=nsid, cns=0x10)[1]

    def identify_attached_ctrl_list(self, nsid=None, cntid=None):
        return self.identify(nsid=nsid, cns=0x12, cntid=cntid)[1]

    def identify_existed_ctrl_list(self, cntid=None):
        return self.identify(cns=0x13, cntid=cntid)[1]

    def identify_primary_ctrl_cap(self, cntid=None):
        return self.identify(cns=0x14, cntid=cntid)[1]

    def identify_secondary_ctrl_list(self, cntid=None):
        return self.identify(cns=0x15, cntid=cntid)[1]

    def attach_ns(self, cntid, nsid, reset=True, wait_ready=True, **kwargs):
        status = self.namespace_attachment(0, cntid, nsid, **kwargs)
        if status:
            return status

        sleep(2)
        if reset:
            LOG.info('NVMe Namespace Attachment, do ctrl reset to sync up with driver')
            self.reset()

        # Rescan devices after namespace attachment
        if wait_ready:
            self.waiting_device_ready(timeout=10, interval=1)

        return status

    def detach_ns(self, cntid, nsid=None, reset=True, wait_ready=True, **kwargs):
        status = self.namespace_attachment(1, cntid, nsid, **kwargs)
        if status:
            return status

        sleep(2)
        if reset:
            LOG.info('NVMe Namespace Detachment, do ctrl reset to sync up with driver')
            self.reset()

        # Rescan devices after namespace attachment
        if wait_ready:
            self.waiting_device_ready(timeout=10, interval=1)

        return status

    def create_ns(self, nsze=0, ncap=0, flbas=0, dps=0, nmic=0, anagid=0, nsetid=0, **kwargs):
        return self.namespace_management(0, nsze=nsze, ncap=ncap, flbas=flbas, dps=dps, nmic=nmic,anagid=anagid, nsetid=nsetid, **kwargs)

    def delete_ns(self, nsid=None, **kwargs):
        return self.namespace_management(1, nsid=nsid, **kwargs)

    def set_features_arbitration(self, save=0, ab=0, lpw=0, mpw=0, hpw=0, **kwargs):
        cdw11 = Arbitration()
        cdw11.AB = ab
        cdw11.LPW = lpw
        cdw11.MPW = mpw
        cdw11.HPW = hpw
        return self.set_features(0x1, save, cdw11.DWORD, **kwargs)

    def set_features_power_management(self, save=0, ps=0, wh=0, **kwargs):
        cdw11 = PowerManagement()
        cdw11.PS = ps
        cdw11.WH = wh
        return self.set_features(0x2, save, cdw11.DWORD, **kwargs)

    def set_features_lba_range_type(self, lrt, save=0, nsid=None, **kwargs):
        cdw11 = LBARangeType()
        cdw11.NUM = len(lrt) - 1

        dptr = (LBARangeTypeEntry * 64)()
        for i, _lrt in enumerate(lrt):
            if isinstance(_lrt, dict):
                for key, val in _lrt.items():
                    if key == 'GUID':
                        setattr(dptr[i].GUID, 'LOW', val & 0xffffffffffffffff)
                        setattr(dptr[i].GUID, 'HIGH', val >> 64)
                    else:
                        setattr(dptr[i], key, val)
            else:
                for key, _ in getattr(_lrt, '_fields_'):
                    setattr(dptr[i], key, getattr(_lrt, key))
        return self.set_features(FeatureID.LBARangeType, save, cdw11.DWORD, dptr=dptr, nsid=nsid, **kwargs)

    def set_features_temperature_threshold(self, save=0, tmpth=0, tmpsel=0, thsel=0, **kwargs):
        cdw11 = TemperatureThreshold()
        cdw11.TMPTH = tmpth
        cdw11.TMPSEL = tmpsel
        cdw11.THSEL = thsel
        return self.set_features(FeatureID.TemperatureThreshold, save, cdw11.DWORD, **kwargs)

    def set_features_temperature_smart_log(self, temperature: int):
        smart_log = SmartHealthInformation()
        setattr(smart_log, "CT", temperature)
        try:
            self.set_features(fid=0xde, cdw11=0x203, nsid=0xffffffff, dptr=smart_log)
        except:
            logging.error("set temperature faild")
        smart_log_get = self.get_log_smart_health_info()
        return smart_log_get.CT

    def set_features_host_memory_buffer(self, save=0, ehm=0, mr=0, esize=0, hdmlec=0, **kwargs):
        cdw11 = HostMemoryBuffer()
        cdw11.EHM = ehm
        cdw11.MR = mr
        # get CC.MPS and init HMB size
        ccmps = 4096
        hsize = 0
        # config Descriptor List
        dptr = HostMemoryBufferDescriptorList()
        for i in range(hdmlec):
            # set entry
            dptr.ENTRY[i].BSIZE = esize
            dptr.ENTRY[i].BADD = addressof
            # cal HMB size
            hsize += (esize * ccmps)
        # get dwords info
        hmdlla = addressof(dptr) & 0xffffffff
        hmdlua = (addressof(dptr) >> 32) & 0xffffffff

        return self.set_features(FeatureID.HostMemoryBuffer, save, cdw11.DWORD, cdw12=hsize, cdw13=hmdlla,
                                 cdw14=hmdlua, cdw15=hdmlec, **kwargs)

    def set_features_unique_smart_error(self, dptr, **kwargs):
        return self.set_features(fid=0xde, cdw11=0x203, dptr=dptr, **kwargs)

    def set_features_non_operational_power_state_config(self, nopsc, save=0, **kwargs):
        dptr = NonOperationalPowerStateConfig()
        dptr.NonOperationalPowerStateConfig = nopsc
        return self.set_features(FeatureID.NonOperationalPowerStateConfig, save, 0, dptr=dptr, **kwargs)

    def set_features_error_recovery(self, save=0, tler=0, dulbe=0, nsid=0, **kwargs):
        cdw11 = ErrorRecovery()
        cdw11.TLER = tler
        cdw11.DULBE = dulbe
        return self.set_features(FeatureID.ErrorRecovery, save, cdw11.DWORD, nsid=nsid, **kwargs)

    def set_features_volatile_write_cache(self, save=0, wce=0, **kwargs):
        cdw11 = VolatileWriteCache()
        cdw11.WCE = wce
        return self.set_features(FeatureID.VolatileWriteCache, save, cdw11.DWORD, **kwargs)

    def set_features_number_of_queues(self, nsqr=0, ncqr=0, save=0, **kwargs):
        cdw11 = NumberOfQueues()
        cdw11.NSQR = nsqr
        cdw11.NCQR = ncqr
        return self.set_features(FeatureID.NumberOfQueues, save, cdw11.DWORD, **kwargs)

    def set_features_interrupt_coalescing(self, save=0, agg_thr=0, agg_time=0, **kwargs):
        cdw11 = InterruptCoalescing()
        cdw11.THR = agg_thr
        cdw11.TIME = agg_time
        return self.set_features(FeatureID.InterruptCoalescing, save, cdw11.DWORD, **kwargs)

    def set_features_interrupt_vector_configuration(self, save=0, iv=0, cd=0, **kwargs):
        cdw11 = InterruptVectorConfiguration()
        cdw11.IV = iv
        cdw11.CD = cd
        return self.set_features(FeatureID.InterruptVectorConfiguration, save, cdw11.DWORD, **kwargs)

    def set_features_write_atomicity_normal(self, save=0, dn=0, **kwargs):
        cdw11 = WriteAtomicityNormal()
        cdw11.DN = dn
        return self.set_features(FeatureID.WriteAtomicityNormal, save, cdw11.DWORD, **kwargs)

    def set_features_ReservationNotificationMask(self, save=0, REGPRE=0, RESREL=0, RESPRE=0, **kwargs):
        cdw11 = ReservationNotificationMask()
        cdw11.REGPRE = REGPRE
        cdw11.RESREL = RESREL
        cdw11.RESPRE = RESPRE
        return self.set_features(FeatureID.ReservationNotificationMask, save, cdw11=cdw11.DWORD, **kwargs)

    def set_features_ReservationPersistence(self, save=0, PTPL=0, **kwargs):
        cdw11 = ReservationPersistence()
        cdw11.PTPL = PTPL
        return self.set_features(FeatureID.ReservationPersistence, save, cdw11=cdw11.DWORD, **kwargs)

    def set_features_asynchronous_event_configuration(self, save=0, shcw=0, nan=0, fan=0, tln=0, **kwargs):
        cdw11 = AsynchronousEventConfiguration()
        cdw11.SHCW = shcw
        cdw11.NAN = nan
        cdw11.FAN = fan
        cdw11.TLN = tln
        return self.set_features(FeatureID.AsynchronousEventConfiguration, save, cdw11.DWORD, **kwargs)

    def set_features_autonomous_power_state_transition(self, save=0, apste=0, **kwargs):
        cdw11 = AutonomousPowerStateTransition()
        cdw11.APSTE = apste
        return self.set_features(FeatureID.AutonomousPowerStateTransition, save, cdw11.DWORD, **kwargs)

    def set_features_software_progress_marker(self, save=0, pbslc=0, **kwargs):
        cdw11 = SoftwareProgressMarker()
        cdw11.PBSLC = pbslc
        return self.set_features(FeatureID.SoftwareProgressMarker, save, cdw11.DWORD, **kwargs)

    def set_features_host_identifier(self, exhid, hostidl, hostidh, save=0, **kwargs):
        cdw11 = HostIdentifier()
        cdw11.EXHID = exhid
        dptr = HostIdentifierEntry()
        dptr.HOSTIDL = hostidl
        dptr.HOSTIDH = hostidh
        return self.set_features(FeatureID.HostIdentifier, save, cdw11.DWORD, dptr=dptr, **kwargs)

    def set_features_reservation_notification_mask(self, save=0, regpre=0, resrel=0, respre=0, nsid=None, **kwargs):
        cdw11 = ReservationNotificationMask()
        cdw11.REGPRE = regpre
        cdw11.RESREL = resrel
        cdw11.RESPRE = respre
        return self.set_features(FeatureID.ReservationNotificationMask, save, cdw11=cdw11.DWORD, nsid=nsid, **kwargs)

    def set_features_reservation_persistence(self, save=0, ptpl=0, nsid=None, **kwargs):
        cdw11 = ReservationPersistence()
        cdw11.PTPL = ptpl
        return self.set_features(FeatureID.ReservationPersistence, save, cdw11=cdw11.DWORD, nsid=nsid, **kwargs)

    def set_features_host_controlled_thermal_management(self, save=0, tmt2=0, tmt1=0, **kwargs):
        cdw11 = HostControlledThermalManagement()
        cdw11.TMT2 = tmt2
        cdw11.TMT1 = tmt1
        return self.set_features(FeatureID.HostControlledThermalManagement, save, **kwargs)

    def set_features_timestamp(self, timestamp, save=0, **kwargs):
        dptr = Timestamp()
        dptr.TIMESTAMP = timestamp
        return self.set_features(FeatureID.Timestamp, save, 0, dptr=dptr, **kwargs)

    def set_features_sanitize_config(self, save=0, nodrm=0, **kwargs):
        cdw11 = SanitizeConfig()
        cdw11.NODRM = nodrm
        return self.set_features(FeatureID.SanitizeConfig, save, cdw11=cdw11, **kwargs)

    def set_features_nonoperational_power_state_config(self, save=0, noppme=0, **kwargs):
        cdw11 = NonOperationalPowerStateConfig()
        cdw11.NOPPME = noppme
        return self.set_features(FeatureID.NonOperationalPowerStateConfig, save, **kwargs)

    def set_features_clean_up_unique_error_buffer(self, **kwargs):
        dptr = SmartHealthInformation()
        return self.set_features(fid=FeatureID.CleanUpUniqueErrorBuffer, cdw11=3, dptr=dptr, status=0x2, **kwargs)

    def format(self, nsid=None, lbaf=0, mset=0, pif=0, pil=0, ses=0, reset=True, wait_ready=True, **kwargs):
        LOG.info('NVMe Format %s', self.args_to_str(lbaf=lbaf, mset=mset, pif=pif, pil=pil, ses=ses, nsid=nsid, **kwargs))
        status = super().format(nsid=nsid, lbaf=lbaf, mset=mset, pif=pif, pil=pil, ses=ses, **kwargs)
        if status:
            return status

        if reset:
            LOG.info('NVMe Format, do ctrl reset to sync up with driver')
            self.reset()

        if wait_ready:
            LOG.info('wait device ready')
            self.waiting_device_ready(timeout=10, interval=1)

        return 0

    def format_as(self, lbads=512, metads=0, **kwargs):
        for i, lbaf in enumerate(self.lbaf_list):
            if lbads == lbaf['LBADS'] and metads == lbaf['LBAMS']:
                return self.format(lbaf=i, **kwargs)

        raise AssertionError(f'Invalid lbaf! lbads: {lbads}, metads: {metads}')


class CNEX(NVMe):
    def fw_inject_uecc_start(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x1
        cmd.CDW[15] = 0x14
        return self.admin_passthru(cmd)

    def fw_inject_uecc_stop(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x0
        cmd.CDW[15] = 0x14
        return self.admin_passthru(cmd)

    def read_register(self, addr):
        dptr = (c_uint32 * 1024)()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x2
        cmd.CDW[11] = addr
        cmd.CDW[15] = 0x14
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)
        self.admin_passthru(cmd)
        return dptr[0]

    def write_register(self, addr, value):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x3
        cmd.CDW[11] = addr
        cmd.CDW[12] = value
        cmd.CDW[15] = 0x14
        return self.admin_passthru(cmd)

    def rdma_read_list(self, offset, ndw=1, nsid=None):
        length = math.ceil(ndw / 1024) * 1024
        data = (c_uint32 * length)()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CNEX_READ_MEM
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = offset & 0xffffffff
        cmd.CDW[11] = offset >> 32
        cmd.CDW[12] = ndw - 1
        cmd.DATA = addressof(data)
        cmd.DATA_LEN = length * 4

        return self.io_passthru(cmd), data[0:ndw]

    def rdma_write_list(self, offset, array, nsid=None):
        ndw = len(array)
        length = math.ceil(ndw / 1024) * 1024
        data = (c_uint32 * length)(*array)

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CNEX_WRITE_MEM
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = offset & 0xffffffff
        cmd.CDW[11] = offset >> 32
        cmd.CDW[12] = ndw - 1
        cmd.DATA = addressof(data)
        cmd.DATA_LEN = length * 4

        return self.io_passthru(cmd)

    def rdma_read(self, offset, nsid=None):
        _, value = self.rdma_read_list(offset, ndw=1, nsid=nsid)
        return value[0]

    def rdma_write(self, offset, value, nsid=None):
        return self.rdma_write_list(offset, [value], nsid=nsid)

    def get_bad_block(self, dptr, lpol=0, lpou=0):
        return self.get_log(dptr, lid=0xcb, lpol=lpol, lpou=lpou)

    def clear_gbb(self, gbb, nsid=0xffffffff):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CNEX_CLEAR_GBB
        cmd.NSID = nsid
        cmd.CDW[10] = gbb
        cmd.CDW[12] = 0x84

        return self.admin_passthru(cmd)

    def aging_era_nand(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.AGING_MF
        cmd.CDW[12] = 0x4
        return self.admin_passthru(cmd)

    def aging_scan_fbb(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.AGING_MF
        cmd.CDW[12] = 0x3
        return self.admin_passthru(cmd)

    def aging_era_dirty(self):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.AGING_MF
        cmd.CDW[12] = 0xb
        return self.admin_passthru(cmd)

    def read_retry_ram(self, mode=0):
        tmp = mode % 2
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.CNEX_VU_COMMAND
        cmd.CDW[15] = 0x2 + tmp
        return self.admin_passthru(cmd)


class Raven(NVMe):
    def identify(self, nsid=0, cns=0, cntid=0, **kwargs):
        cdw10 = IdentifyDword10()
        cdw10.CNS = cns
        cdw10.CNTID = cntid

        dptr = IDENTIFY_CNS.get(cns, (c_uint8 * 4096))()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_GET
        cmd.NSID = nsid
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[15] = 0x1
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs), dptr

    def identify_vu(self, ptr, nsid=0, cns=0, cntid=0, **kwargs):
        cdw10 = IdentifyDword10()
        cdw10.CNS = cns
        cdw10.CNTID = cntid

        dptr = ptr

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_GET
        cmd.NSID = nsid
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[15] = 0x1
        cmd.DATA = dptr
        cmd.DATA_LEN = 4096

        return self.admin_passthru(cmd, **kwargs), dptr

    def get_log(self, dptr, lid=0x1, lpol=0, lpou=0, lsp=0, xfer=4096, nsid=0xffffffff, rae=0, **kwargs):
        addr = addressof(dptr)
        size = sizeof(dptr)

        cdw10 = GetLogPagDword10()
        cdw11 = GetLogPagDword11()

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_GET
        cmd.NSID = nsid

        while size > 0:
            xfer = min(xfer, size)
            numd = (xfer >> 2) - 1

            cdw10.LID = lid
            cdw10.LSP = lsp
            cdw10.RAE = rae
            cdw10.NUMDL = numd & 0xffff
            cdw11.NUMDU = numd >> 16

            cmd.CDW[10] = cdw10.DWORD
            cmd.CDW[11] = cdw11.DWORD
            cmd.CDW[12] = lpol
            cmd.CDW[13] = lpou
            cmd.CDW[15] = 0x2
            cmd.DATA = addr
            cmd.DATA_LEN = xfer

            status = self.admin_passthru(cmd, **kwargs)
            if status:
                return status

            addr += xfer
            size -= xfer
            lpou, lpol = divmod(lpol + xfer, 2 ** 32)

        return 0

    def get_log_smart_health_info(self):
        dptr = SmartHealthInformation()
        self.get_log(dptr, lid=0x2)
        return dptr

    def get_log_fw_slot_info(self):
        dptr = FirmwareSlotInformation()
        self.get_log(dptr, lid=0x3)
        return dptr

    def get_log_device_self_test(self):
        dptr = SelfTestLog()
        self.get_log(dptr, lid=0x6)
        return dptr

    def device_self_test(self, stc, nsid=None, **kwargs):
        cdw10 = DeviceSelfTest()
        cdw10.STC = stc

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_SUM
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[15] = 0x2

        return self.admin_passthru(cmd, **kwargs)

    def hmb_write(self, dptr, nsid, numd=1, ofsd=0, tid=0, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_WR
        cmd.NSID = nsid
        cmd.CDW[10] = numd - 1
        cmd.CDW[11] = ofsd
        cmd.CDW[12] = tid
        cmd.CDW[15] = 0x3
        cmd.DATA = dptr
        cmd.DATA_LEN = numd * 4
        status = self.admin_passthru(cmd, **kwargs)
        return status

    def hmb_read(self, dptr, nsid, numd=1, ofsd=0, tid=0, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_RD
        cmd.NSID = nsid
        cmd.CDW[10] = numd - 1
        cmd.CDW[11] = ofsd
        cmd.CDW[12] = tid
        cmd.CDW[15] = 0x5
        cmd.DATA = dptr
        cmd.DATA_LEN = numd * 4
        status = self.admin_passthru(cmd, **kwargs)
        return status

    def hmb_info(self, nsid, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_RD
        cmd.NSID = nsid
        cmd.CDW[15] = 0x4
        dptr = HMB()
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = 4096
        status = self.admin_passthru(cmd, **kwargs)
        return status, dptr

    def hmb_get_prp_list(self, teneat_id, nprps, start_prp=0, **kwargs):
        prp_buf = Malloc(nprps + 1, c_uint64)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_RD
        cmd.CDW[15] = 0x6
        cmd.CDW[11] = start_prp
        cmd.CDW[12] = nprps
        cmd.CDW[10] = teneat_id
        cmd.DATA = prp_buf.address
        cmd.DATA_LEN = (nprps + 1) * 8
        status = self.admin_passthru(cmd, **kwargs)
        return status, prp_buf

    def fw_download(self, filename, xfer=0, offset=0, align=4096, **kwargs):
        file_size = os.path.getsize(filename)
        length = math.ceil(file_size / 4096) * 4096
        dptr = (c_uint8 * length)()
        with open(filename, "rb") as fd:
            memmove(dptr, fd.read(), file_size)
        addr = addressof(dptr)

        offset <<= 2
        if xfer == 0 or xfer % align:
            xfer = 4096

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_FW

        while file_size > 0:
            xfer = min(xfer, file_size)

            cmd.CDW[10] = (xfer >> 2) - 1
            cmd.CDW[11] = offset >> 2
            cmd.CDW[15] = 0x1
            cmd.DATA_LEN = xfer
            cmd.DATA = addr

            status = self.admin_passthru(cmd, **kwargs)
            if status:
                return status

            addr += xfer
            file_size -= xfer
            offset += xfer

        return 0

    def fw_commit(self, ca=3, fs=1, bpid=0, **kwargs):
        cdw10 = FWCommitDW10()
        cdw10.BPID = bpid
        cdw10.CA = ca
        cdw10.FS = fs

        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_SUM
        cmd.CDW[10] = cdw10.DWORD
        cmd.CDW[15] = 0x1

        return self.admin_passthru(cmd, **kwargs)

    def namespace_stream(self, action, dtype, strmid, nsid=0, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_SUM
        cmd.NSID = nsid
        cmd.CDW[10] = action
        cmd.CDW[11] = (dtype << 16) + strmid
        cmd.CDW[15] = 0x4

        return self.admin_passthru(cmd, **kwargs), cmd.RESULT

    def rate_limits_wr(self, prp, ndt=0, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_WR
        cdw0 = RateLimitsDword0()
        cdw0.FUSE = 0
        cdw0.PSDT = 0
        cmd.CDW[10] = ndt
        cmd.CDW[15] = 0x7

        cmd.DATA = prp
        cmd.DATA_LEN = (ndt + 1) * 4

        return self.admin_passthru(cmd, **kwargs), cmd.RESULT

    def rate_limits_rd(self, prp, ndt=0, ior_ctr=0, iow_ctr=0, lid=0xFF, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.KNUCKLE_VU_RD
        cdw0 = RateLimitsDword0()
        cdw0.FUSE = 0
        cdw0.PSDT = 0
        cmd.CDW[10] = ndt
        cdw11 = RateLimitsDword11()
        cdw11.IOR_OVERFLOW_CTR = ior_ctr
        cdw11.IOW_OVERFLOW_CTR = iow_ctr
        cmd.CDW[12] = lid
        cmd.CDW[15] = 0x7

        cmd.DATA = prp
        cmd.DATA_LEN = (ndt + 1) * 4

        return self.admin_passthru(cmd, **kwargs), prp


class Tahoe(NVMe):
    OFFSET_REGISTER = 0x100000

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        vu_class = VUProjectType.from_name(self.__class__.__name__ + "VU")
        self.vu_cmd = vu_class(self)

    def read_register(self, addr):
        return self.vu_cmd.get_memory(addr + self.OFFSET_REGISTER)[0]

    def write_register(self, addr, value):
        dptr = (c_uint32 * 128)(value)
        self.vu_cmd.set_memory(addr + self.OFFSET_REGISTER, dptr, length=1)

    def read_ctrl_register(self, addr):
        return self.vu_cmd.get_memory(addr)[0]

    def set_comp_temp(self, value=0xffffffff):
        return self.vu_cmd.set_compsite_temp(value)

    def get_average_power_consumption(self, duration=60, delay=1):
        pc = 0
        max_cre = 0
        min_cre = 0
        avg_cre = 0
        temp = self.get_log_smart_health_info()
        for i in range(duration):
            data = self.vu_cmd.get_power_consumption()
            pc += data[0]
            max_cre += data[1]
            min_cre += data[2]
            avg_cre += data[3]
            #temp = self.get_log_smart_health_info()
            LOG.info("[PowerData] [%d] [Power: %f, temp: %d] [max:%d, min:%d, avg:%d].", i,\
                      data[0], temp.CT, max_cre, min_cre, avg_cre)
            sleep(delay)
        return pc / duration, max_cre / duration, min_cre / duration, avg_cre / duration

    def check_security(self, offset, length):
        tmp = self.vu_cmd.get_drive_security_state()
        if length == 1:
            return tmp[offset]
        security_sum = 0
        a = tmp[offset:(offset+length)]
        for i in range(length):
            security_sum = security_sum + (a[i] << (i * 8))
        return security_sum

    def get_vendor_uniquelog(self):
        dptr = DellEMCUniqueLogPage()
        #Ctype(dptr).dump()
        return self.get_log(dptr, lid=0xDE), dptr

    def get_vendor_uniquelog_with_offset(self, length, offset):
        dptr = (c_uint8 * 512)()
        self.get_log(dptr, lid=0xDE)
        a = dptr[offset:(offset + length)]
        ret = 0
        for i in range(length):
            ret = ret + (a[i] << (i * 8))
        return ret

    def check_int_type(self):
        return self.vu_cmd.get_int_type()

    @staticmethod
    def check_data(val):
        if val:
            return val
        return None

    def get_info(self):
        id_ctrl_buffer = Ctype(self.identify_ctrl())
        dev_info, ssd_config_dic, drive_life_info_dic, test_fw_config_dic = {}, {}, {}, {}
        temp1 = re.findall(r'http\S+git', id_ctrl_buffer.get('VS'))
        fw_repo = self.check_data(temp1[0])if temp1 else ""
        temp2 = re.findall(".*git(.*)commit.*", id_ctrl_buffer.get('VS'))
        fw_branch_name = self.check_data(temp2[0]) if temp2 else ""
        temp3 = re.findall(r'commit (\w+)', id_ctrl_buffer.get('VS'))
        fw_private_revision = self.check_data(temp3[0]) if temp3 else ""
        tnvmecap = self.check_data(id_ctrl_buffer.get('TNVMCAP'))
        fw_public_revision = self.check_data(id_ctrl_buffer.get('FR'))
        vid = self.check_data(id_ctrl_buffer.get('VID'))
        drive_sn = self.check_data(id_ctrl_buffer.get('SN'))
        drive_pn = self.check_data(id_ctrl_buffer.get('MN'))
        security_type = "ISE" if self.check_security(2, 1) else "SED"
        security_status = "security enable" if self.check_security(3, 1) else "security disable"
        int_type = self.check_data(self.check_int_type())
        life_cycle_state = self.check_security(16, 4)
        count_grown_defects = self.get_log_smart_health_info_extend().BUNBR
        nand_max_erase_count = self.get_log_smart_health_info_extend().UDECMAX
        nand_min_erase_count = self.get_log_smart_health_info_extend().UDECMIN
        ssd_config_dic['drive_sn'] = drive_sn
        ssd_config_dic['drive_pn'] = drive_pn
        ssd_config_dic['vid'] = vid
        ssd_config_dic['drive_tnvmcap'] = tnvmecap
        ssd_config_dic['security_status'] = security_status
        ssd_config_dic['security_type'] = security_type
        ssd_config_dic['int_type'] = int_type
        drive_life_info_dic['life_cycle_state'] = life_cycle_state
        drive_life_info_dic['count_grown_defects'] = count_grown_defects
        drive_life_info_dic['nand_max_erase_count'] = nand_max_erase_count
        drive_life_info_dic['nand_min_erase_count'] = nand_min_erase_count
        test_fw_config_dic['fw_public_revision'] = fw_public_revision
        test_fw_config_dic['fw_repo'] = fw_repo
        test_fw_config_dic['fw_private_revision'] = fw_private_revision
        test_fw_config_dic['fw_branch_name'] = fw_branch_name
        dev_info['ssd_config_dic'] = ssd_config_dic
        dev_info['drive_life_info_dic'] = drive_life_info_dic
        dev_info['test_fw_config_dic'] = test_fw_config_dic
        return dev_info

    def set_plp_task_timer(self, vu_type, inj_user_id=None, inj_case_id=None, inj_delay=None):
        """
          Domain    DW10       DW11         DW12             DW13    DW14   DW15   DW0(CQE)
        | Media | 0x2000002e| None | Combination of args |  None  | None | None  | None

        This is VU command set plp task timer
        Args:    vu_type, inj_user_id, inj_case_id, inj_delay
        Returns: command status
        Raises:  send VU cmd fail
        """
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW[10] = 0x2000002e if vu_type == 0 else 0x20000034

        inj_user_id = (inj_user_id & 0xFF) if inj_user_id else inj_user_id
        inj_case_id = (inj_case_id & 0xFF) if inj_case_id else inj_case_id

        if inj_user_id is not None:
            if inj_case_id is None:
                cmd.CDW[12] = inj_delay << 11 | inj_user_id << 3 | 2
            elif inj_delay is None:
                cmd.CDW[12] = inj_case_id << 11 | inj_user_id << 3 | 0
            else:
                cmd.CDW[12] = inj_delay << 19 | inj_case_id << 11 | inj_user_id << 3 | 1
        else:
            cmd.CDW[12] = inj_delay << 3 | 3

        LOG.info('Set plp task timer, vu type: %d, CDW10: 0x%x, CDW12: 0x%x', vu_type, cmd.CDW[10], cmd.CDW[12])
        return self.admin_passthru(cmd)

    def clear_slot(self, slot=1):
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xC0
        cmd.CDW10 = 0x10000088
        cmd.CDW12 = slot

        LOG.info('Clear Slot: %d', slot)
        return self.admin_passthru(cmd)

    def set_stream(self, count=0, mode=0, lba=0):
        cmd = NVMeVuCmd()
        cmd.OPCODE = 0x1
        cmd.STREAMS.COUNT = count
        cmd.STREAMS.MODE = mode
        cmd.STREAMS.LBA = lba

        LOG.info('Set streams count: %d, mode: %d, lba: 0x%x', count, mode, lba)
        return self.nvme_vu_cmd(cmd)


class R5TEST(NVMe):
    def __init__(self):
        super().__init__()
        self.fid = 0xc1

    def trigger_test(self, val, save=0):
        return self.set_features(self.fid, save, val)

    def get_result(self, val, sel=0):
        _, result, _ = self.get_features(self.fid, sel, val)
        return result.DWORD >> 16


class CYTEST(NVMe):
    def __init__(self):
        super().__init__()
        self.fid = 0xc3

    def trigger_test(self, cdw11, stream, length, cdw12=0, save=0):
        prp = Malloc(length=length)
        prp.memcopy(stream)
        return self.set_features(self.fid, save, cdw11, cdw12, dptr=prp.buf)

    def get_result(self, val, sel=0):
        status, result, _ = self.get_features(self.fid, sel, val)
        return status, result.DWORD


class VUBMI(NVMe):
    def __init__(self, file_name):
        super().__init__()
        self.total_size = 512 * 1024
        self.xfer_length = 4 * 1024
        self.cdw12 = 0xA9
        self.cdw15 = 0x00
        self.opcode = 0xEE
        self.bmi_table = Malloc(self.total_size)
        self.filename = file_name

    def save_file(self):
        return os.path.join("/home", "nvme", "public", "G+", "Badb", "%s" % self.filename)

    def write_bin_file(self, pdata):
        with open(self.save_file(), "wb") as file_des:
            for i in range(pdata.size):
                dat = pdata.get_uint8(i)
                bdat = struct.pack("B", dat)
                file_des.write(bdat)

    def dump_bmi(self):
        for piece in range(self.total_size // self.xfer_length):
            cmd = NVMePassthruCmd()
            cmd.OPCODE = self.opcode
            cmd.CDW[12] = self.cdw12
            cmd.CDW[13] = piece * self.xfer_length
            cmd.CDW[14] = self.xfer_length
            prp = Malloc(self.xfer_length)
            cmd.DATA = prp.address
            cmd.DATA_LEN = self.xfer_length
            self.admin_passthru(cmd)
            self.bmi_table.memmove(cmd.CDW[13], prp, 0, self.xfer_length)
        self.write_bin_file(self.bmi_table)
        return self.bmi_table


class ZNS(NVMe):

    def zns_identify_ns(self, nsid):
        return self.identify(nsid=nsid, cntid=self.cntid, cns=0x5, csi=2)[1]

    def zns_identify_ctrl(self):
        return self.identify(nsid=0, cntid=self.cntid, cns=0x6, csi=2)[1]

    def zns_mgmt_send(self, zsa, nsid=None, slba=0, select_all=0, dptr=None, **kwargs):
        cdw13 = ZNSMgmtSendDW13()
        cdw13.ZSA = zsa
        cdw13.SELALL = select_all
        if dptr is None:
            dptr = (c_uint8 * 4096)()
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.ZONE_MANAGEMENT_SEND
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = slba & 0xffffffff
        cmd.CDW[11] = slba >> 32
        cmd.CDW[13] = cdw13.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs)

    def zns_mgmt_receive(self, zra, zrasf, zrasfea, nsid=None, slba=0, select_all=0, **kwargs):
        cdw13 = ZNSMgmtReceiveDW13()
        cdw13.ZRA = zra
        cdw13.ZRASF = zrasf
        cdw13.ZRASFEA = zrasfea
        lbaf = self.identify_ns(nsid).FLBAS
        zns_id_ns = self.zns_identify_ns(nsid).LBAFE[lbaf]
        dptr = dynamic_extended_zones_data(zns_id_ns.ZDES)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = OPCODE.ZONE_MANAGEMENT_RECEIVE
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = slba & 0xffffffff
        cmd.CDW[11] = slba >> 32
        cmd.CDW[12] = ((sizeof(dptr)) >> 2) -1
        cmd.CDW[13] = cdw13.DWORD
        cmd.DATA = addressof(dptr)
        cmd.DATA_LEN = sizeof(dptr)

        return self.admin_passthru(cmd, **kwargs), dptr

    def close_zone(self, slba=0, nsid=None, select_all=0):
        self.zns_mgmt_send(ZoneAction.CLOSE_ZONE, nsid=nsid, slba=slba, select_all=select_all)

    def open_zone(self, slba=0, nsid=None, select_all=0):
        self.zns_mgmt_send(ZoneAction.OPEN_ZONE, nsid=nsid, slba=slba, select_all=select_all)

    def finish_zone(self, slba=0, nsid=None, select_all=0):
        self.zns_mgmt_send(ZoneAction.FINISH_ZONE, nsid=nsid, slba=slba, select_all=select_all)

    def reset_zone(self, slba=0, nsid=None, select_all=0):
        self.zns_mgmt_send(ZoneAction.RESET_ZONE, nsid=nsid, slba=slba, select_all=select_all)

    def offline_zone(self, slba=0, nsid=None, select_all=0):
        self.zns_mgmt_send(ZoneAction.OFFLINE_ZONE, nsid=nsid, slba=slba, select_all=select_all)

    def set_zone_desc(self, dptr, slba=0, nsid=None, select_all=0):
        self.zns_mgmt_send(ZoneAction.OFFLINE_ZONE, nsid=nsid, slba=slba, select_all=select_all, dptr=dptr)

    def zone_append(self, slba, nlb, dptr, mptr=None, nsid=None, **kwargs):
        cdw12 = RWDword12()
        cdw12.NLB = nlb - 1

        cmd = NVMePassthruCmd64()
        cmd.OPCODE = OPCODE.ZONE_APPEND
        cmd.NSID = self.get_int(nsid, self.nsid)
        cmd.CDW[10] = slba & 0xffffffff
        cmd.CDW[11] = slba >> 32
        cmd.DATA = addressof(dptr)
        cmd.META = addressof(mptr) if mptr else 0
        cmd.DATA_LEN = sizeof(dptr)
        cmd.META_len = sizeof(mptr) if mptr else 0
        return self.io64_passthru(cmd, **kwargs)
