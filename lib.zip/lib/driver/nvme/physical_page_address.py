#!/usr/bin/evn python
# -*- coding: utf-8 -*-
# pylint: disable=invalid-name


from lib.driver.utils import buf

PPA_SIZE = 64
INVALID_PPA = 0xFFFFFFFF
DIRTY_PPA_MASK = 0xFF000000


def parse_ppa(target_ppa, ppa_struct_dict):
    """
    bit offset: |0   block_size-1|.............................................63|
                |block_size|page_size|lun_size|plane_size|ep_size|ch_size|reserved|
    target_ppa: |block     |page     |lun     |plane     |ep     |channel| 0x00   |
    Args:
        target_ppa:      ppa returned from FW
        ppa_struct_dict: ppa structure dictionary
    Returns:
        channel, ep, plane, lun, page, block value after parsed
    """
    ppa_buffer = buf.Malloc(PPA_SIZE)
    ppa_buffer.set_uint64(0, target_ppa)
    start_bit_index = 0
    ch = ppa_buffer.get_uint64_bits(0, start_bit_index, ppa_struct_dict["ch_size"])
    start_bit_index += ppa_struct_dict["ch_size"]
    ep = ppa_buffer.get_uint64_bits(0, start_bit_index, ppa_struct_dict["ep_size"])
    start_bit_index += ppa_struct_dict["ep_size"]
    pl = ppa_buffer.get_uint64_bits(0, start_bit_index, ppa_struct_dict["plane_size"])
    start_bit_index += ppa_struct_dict["plane_size"]
    lun = ppa_buffer.get_uint64_bits(0, start_bit_index, ppa_struct_dict["lun_size"])
    start_bit_index += ppa_struct_dict["lun_size"]
    pg = ppa_buffer.get_uint64_bits(0, start_bit_index, ppa_struct_dict["page_size"])
    start_bit_index += ppa_struct_dict["page_size"]
    bl = ppa_buffer.get_uint64_bits(0, start_bit_index, ppa_struct_dict["block_size"])
    return ch, ep, pl, lun, pg, bl


def combined_to_ppa(ch, ep, pl, lun, pg, bl, ppa_struct_dict):
    """
    Combine nand address into ppa address
    Args:
        ch: channel location
        ep: ep location
        pl: plane location
        lun: lun location
        pg: page location
        bl: block location
        ppa_struct_dict:
            bit offset: |0   block_size-1|.............................................63|
                        |block_size|page_size|lun_size|plane_size|ep_size|ch_size|reserved|
            target_ppa: |block     |page     |lun     |plane     |ep     |channel| 0x00   |

    Returns:
        combined ppa value
    """
    ppa_buffer = buf.Malloc(64)
    for i in range(64):
        ppa_buffer.set_uint8(offset=i, value=0)
    start_bit_index = 0
    ppa_buffer.set_uint64_bits(0, start_bit_index, ppa_struct_dict["ch_size"], ch)
    start_bit_index += ppa_struct_dict["ch_size"]
    ppa_buffer.set_uint64_bits(0, start_bit_index, ppa_struct_dict["ep_size"], ep)
    start_bit_index += ppa_struct_dict["ep_size"]
    ppa_buffer.set_uint64_bits(0, start_bit_index, ppa_struct_dict["plane_size"], pl)
    start_bit_index += ppa_struct_dict["plane_size"]
    ppa_buffer.set_uint64_bits(0, start_bit_index, ppa_struct_dict["lun_size"], lun)
    start_bit_index += ppa_struct_dict["lun_size"]
    ppa_buffer.set_uint64_bits(0, start_bit_index, ppa_struct_dict["page_size"], pg)
    start_bit_index += ppa_struct_dict["page_size"]
    ppa_buffer.set_uint64_bits(0, start_bit_index, ppa_struct_dict["block_size"], bl)
    target_ppa = ppa_buffer.get_uint64(0)
    return target_ppa
