import os
from ctypes import windll

from lib.driver.nvme.struct import SmartHealthInformation
from lib.driver.utils.buf import Malloc


class NVMe:

    def __init__(self, dev_index):
        self.dev_index = dev_index
        path = os.path.realpath(os.path.join(os.path.dirname(__file__), "nvme_ioctl.dll"))
        self.__dll = windll.LoadLibrary(path)

    def get_log(self, lid=0x01, numd=100, numdu=0, lpol=0, lpou=0, nsid=0, type_=SmartHealthInformation):
        ret, prp = None, None
        if lid == 0x02:
            ret, prp = self.get_smart_log()
        return ret, prp

    def get_smart_log(self):
        prp = Malloc(types=SmartHealthInformation)
        ret = self.__dll.get_smartlog(self.dev_index, prp.buf)
        if ret != 0:
            print("get smart log failed")
        return ret, prp

    def identify(self, cns, cntid, nsid, types):
        prp = Malloc(types=types)
        ret = -1
        if cns == 0x1:
            ret = self.__dll.identify_controller(self.dev_index, prp.buf)
        elif cns == 0x11:
            ret = self.__dll.identify_namespace(self.dev_index, prp.buf)
        return ret, prp

# dll = windll.LoadLibrary("nvme_ioctl.dll")
# print(dll.add(1,2))
#
#
# a = dll.get_temperature(1)
# print(a)
#
# prp = Malloc(types=SmartHealth)
#
# b = dll.get_smartlog(1, prp.buf)
# smart_health = prp.convert(SmartHealth)
# print(smart_health.aspare)
# print(b)
#
