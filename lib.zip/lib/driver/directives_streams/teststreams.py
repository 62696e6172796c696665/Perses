#!/usr/bin/env python
# coding=utf-8
# pylint: disable=superfluous-parens,missing-docstring,too-many-public-methods
import multiprocessing
import os
import time
import json
from ctypes import sizeof, addressof
import psutil
from nose.tools import assert_equal, assert_not_equal
from lib.driver import TestCase
from lib.driver.nvme.traffic import LBAOperate
from lib.driver.utils.system import execute
from lib.driver.utils import buf
from lib.driver.nvme.struct.command import NVMePassthruCmd
from lib.tool.vdbench import Vdbench
from lib.tool.fio.fio_linux import Fio


root_path = os.path.realpath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


class TestStreams(TestCase):
    def __init__(self):
        super().__init__()
        data = buf.Malloc(32)
        self.nvme.directive_receive(dptr=data.buf, doper=1, dtype=1, dspec=0, cdw12=0)
        self.id_ns = self.nvme.identify_ns()
        self.nsize = self.id_ns.NSIZE
        self.lbads = self.id_ns.LBAF[self.id_ns.FLBAS].LBADS
        self.msl = data.get_uint16(0)
        self.streams_lbas = self.nsize // (self.msl + 1)
        self.runtime = 600
        self.operate = LBAOperate(self.nvme)
        self.dev_name = self.operate.block_dev
        self.fio = Fio()
        self.obj = Vdbench(self.dev_name)
        self.obj.set_parm("threads", "32")
        self.obj.set_parm("size", "5g")
        self.obj.set_parm("rdpct", "0")
        self.obj.set_parm("elapsed", self.runtime)
        self.obj.set_parm("interval", "1")

        self.forrdpct = "(0,50,99)"
        self.forsz = "(4k,16k,64k,256k,1m)"
        self.mixsz = "(4k,20,8k,20,16k,10,32k,10,64k,10,128k,10,1m,20)"
        self.reg_list = {}
        _, self.setup_streams_wr_count = self.get_streams_write_count()

    def setup(self):
        super().setup()
        self.log.info("SETUP: streams write count:\n%s", json.dumps(self.setup_streams_wr_count, indent=4))

    def teardown(self):
        super().teardown()
        try:
            self.set_streams()
        except:
            self.log.info("set stream id to default failed")

    def write_reg(self, addr, val, printf=True):
        ret = self.read_reg(addr)
        if addr not in self.reg_list:
            self.reg_list[addr] = ret
        self.nvme.write_register(addr, val)
        if printf:
            self.log.info("Update register[addr:0x%x, val: 0x%x]", addr, val)
        time.sleep(0.5)

    def read_reg(self, addr):
        return self.nvme.read_register(addr)

    def get_streams_write_count(self):
        # nvme admin-passthru /dev/nvme0 -o 0xc0 -l 64 --cdw10 0x2000206f --cdw11 64 -r
        s_count = buf.Malloc(64)
        cmd = NVMePassthruCmd()
        cmd.OPCODE = 0xc0
        cmd.CDW10 = 0x2000206f
        cmd.CDW11 = 64
        cmd.DATA = addressof(s_count.buf)
        cmd.DATA_LEN = sizeof(s_count.buf)
        status = self.nvme.admin_passthru(cmd=cmd)
        data_dict = {"non_stream": s_count.get_uint64(0),
                     "gc_queue": s_count.get_uint64((self.msl + 1) * 8),
                     "ftl_cursor": s_count.get_uint64((self.msl + 2) * 8)}
        for i in range(1, self.msl + 1):
            data_dict[f"stream_{i}"] = s_count.get_uint64(i * 8)
        return status, data_dict

    def streams_count_check(self, streams_count=1, streams_mode=1):
        _, streams_wr_count = self.get_streams_write_count()
        self.log.info("streams write count:\n%s", json.dumps(streams_wr_count, indent=4))
        if streams_mode == 2:
            assert_not_equal(streams_wr_count["non_stream"], self.setup_streams_wr_count["non_stream"])
            self.log.info("Non Stream count check pass")
        num_stream = streams_count if streams_count < self.msl else self.msl
        if num_stream < self.msl:
            for i in range(streams_count + 1, self.msl + 1):
                assert_equal(streams_wr_count[f"stream_{i}"], self.setup_streams_wr_count[f"stream_{i}"])
        for i in range(1, num_stream):
            assert_not_equal(streams_wr_count[f"stream_{i}"], self.setup_streams_wr_count[f"stream_{i}"])
        self.log.info("streams_count=%s, streams_mode=%s; check count pass", streams_count, streams_mode)

    def run_vdbench_fix(self, seekpct="0", compratio="15", mode="-v"):
        self.obj.set_parm("seekpct", seekpct)
        self.obj.set_parm("compratio", compratio)
        self.obj.set_parm("forxfersize", self.forsz)
        self.obj.set_parm("forrdpct", self.forrdpct)
        self.obj.run(option=mode)

    def keyword_args_fio(self, kwargs: dict, process=True, outfile=None, fio_log=None, mp_queue=None):
        self.fio.clear_parm()
        self.fio.clear_args()
        self.fio.outfile = outfile
        self.fio.set_parm("log_avg_msec", 500)
        for key, value in kwargs.items():
            self.fio.set_parm(key, value)
        self.fio.set_parm("write_bw_log", fio_log)
        self.fio.set_parm("write_lat_log", fio_log)
        self.fio.set_parm("write_iops_log", fio_log)
        self.fio.set_parm("direct", 1)
        self.fio.set_parm('name', f'test_{time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))}')
        if process:
            self.fio.run()
            return None
        _, output_file = self.fio.start()
        if isinstance(mp_queue, multiprocessing.queues.Queue):
            mp_queue.put(output_file)
        return output_file

    def insmod_stream(self, streams_lbas=0, streams_count=0, streams_mode=0):
        """
        streams_count: supported number of streams, default: 0 (non-streams)
        streams_mode:
            - 1: without non-streams,
            - 2: use all streams id(e.g. 0,1,2,3),
            - default: 0 (non-streams)
        streams_lbas:
            - 0: drv assign streams id randomly,
            - over 0: drv assign streams id by lba
        """
        driver_path = os.path.join(root_path, "lib", "driver", "directives_streams")
        nvme_core_ko = os.path.join(driver_path, "nvme-core.ko")
        nvme_ko = os.path.join(driver_path, "nvme.ko")
        execute("rmmod nvme; rmmod nvme-core")
        insmod_core = f"insmod {nvme_core_ko} streams_lbas={streams_lbas} " \
                      f"streams_count={streams_count} " \
                      f"streams_mode={streams_mode}"
        execute(insmod_core)
        time.sleep(3)
        execute(f"insmod {nvme_ko}")
        for _ in range(100):
            time.sleep(3)
            try:
                self.nvme.scan_devices()
                if self.nvme.block_dev is None:
                    continue
            except BaseException:
                self.log.info("No match device,searching...")
                continue
            else:
                self.log.info("found device!")
                time.sleep(5)
                return

    def set_streams(self, streams_lbas=0, streams_count=0, streams_mode=0):
        self.log.info("Set Streams: streams_lbas: %s, streams_count: %s, streams_mode: %s",
                      streams_lbas, streams_count, streams_mode)
        self.nvme.set_stream(count=streams_count, mode=streams_mode, lba=streams_lbas)

    def bandwidth_monitor(self, disk_name="nvme0n1", time_to_monitor=0):
        last_read_bytes = 0
        last_write_bytes = 0
        if time_to_monitor is None:
            time_to_monitor = 0
        self.log.info("monitor %s", disk_name)
        start_listening = time.perf_counter() if time_to_monitor > 0 else 0
        current_time = time.perf_counter() if time_to_monitor > 0 else 0
        while (current_time - start_listening) <= time_to_monitor:
            current_time = time.perf_counter() if time_to_monitor > 0 else 0
        # for i in range(time_to_monitor):
            disk_io_counters = psutil.disk_io_counters(perdisk=True)[disk_name]
            read_bytes = disk_io_counters.read_bytes
            write_bytes = disk_io_counters.write_bytes
            read_speed = read_bytes - last_read_bytes
            write_speed = write_bytes - last_write_bytes
            self.log.info(f"[R bw: {read_speed / 1024 / 1024:.2f} MB/s]"
                          f"[W bw: {write_speed / 1024 / 1024:.2f} MB/s]")
            last_read_bytes = read_bytes
            last_write_bytes = write_bytes
            time.sleep(1)

    def write_streams(self, lba, nlb, dspec, **kwargs):
        self.operate.dtype = 1
        self.operate.dspec = dspec  # stream identifier
        self.operate.write_sync(lba=lba, nlb=nlb, **kwargs)
