#!/usr/bin/env python
"""
This is system commands

@author: Yingjun Yang
"""
import glob
import logging
import os
import re
import shutil
import socket
import sys
import time
from subprocess import Popen, PIPE, STDOUT
from threading import Thread

import yaml

LOG = logging.getLogger()
DUMP = logging.getLogger('dump')

def get_bits(off, wid, val):
    mask = (2 ** wid - 1)
    value = (val >> off) & (mask)
    return value

def set_bits(off, wid, value, setv):
    mask = 0xffffffff - ((2 ** wid - 1) << off)
    set_mask = setv << off
    val = ((value & mask) | set_mask) & 0xffffffff
    return val

class Threads(Thread):
    def __init__(self, target=None, args=()):
        super().__init__()
        self.target = target
        self.args = args
        self.output = None, None

    def run(self):
        self.output = self.target(*self.args)

    def get_result(self):
        return self.output


def execute(cmd, cmdline=True, console=True, interrupt=True):
    cmd = " ".join(cmd) if isinstance(cmd, list) else cmd
    if cmdline:
        LOG.info("# %s", cmd)

    output = ""
    args = {'close_fds': True} if 'linux' in sys.platform else {}
    with Popen(cmd, stdout=PIPE, stderr=STDOUT, shell=True, **args) as proc:
        while True:
            line = proc.stdout.readline().decode("utf-8", "ignore")
            if line:
                if console:
                    DUMP.info(line.strip('\n'))
                output += line

            if proc.poll() is not None and line == "":
                break
        status = proc.returncode

    if status and interrupt:
        raise RuntimeError("{} failed! Status: {:#x}".format(cmd, status))

    return status, output


def remove(path):
    if os.path.exists(path):
        os.remove(path)


def rmfiles(path):
    for item in glob.glob(path):
        os.remove(item)


def mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def cptree(src, dst, symlinks=False):
    if not os.path.exists(dst):
        shutil.copytree(src, dst, symlinks)


def rmtree(path):
    if os.path.exists(path):
        shutil.rmtree(path)


def tmpfs(path, size):
    if not os.path.ismount(path):
        cmd = "mount -t tmpfs tmpfs {}".format(path)
        if size:
            cmd += " -o size={}".format(size)
        execute(cmd)


def delfs(path):
    if os.path.ismount(path):
        execute("umount {}".format(path))


def mktmpfs(mnt="/ramdisk", size=None):
    mkdir(mnt)
    tmpfs(mnt, size)


def get_disk_size(dev, unit="G"):
    cmd = "fdisk -l /dev/{} | grep 'Disk /dev/'".format(dev)
    status, output = execute(cmd)
    if status:
        raise RuntimeError("fdisk failed!")

    size = int(re.findall(r"([\d+]+) bytes", output)[0])
    if "g" in unit.lower():
        return size / (1024 ** 3)
    if "m" in unit.lower():
        return size / (1024 ** 2)
    if "k" in unit.lower():
        return size / 1024
    return size


def get_ip_address():
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(('8.8.8.8', 80))
        ip_address = sock.getsockname()[0]
    finally:
        if sock:
            sock.close()
    return ip_address


def get_root_path():
    root_path = os.path.realpath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    return root_path


def get_expect_version(tool_name):
    conf = os.path.join(get_root_path(), "configuration", "version.yaml")
    with open(conf, encoding='utf-8') as file_:
        cont = file_.read()
    cf_ = yaml.load(cont)
    version_ = cf_[tool_name]
    return version_


def version_check(tool):
    act_version = tool.get_version()
    exp_version = get_expect_version(tool.name)
    LOG.info("%s actual version:%s , expect version:%s", tool.name, act_version, exp_version)
    return act_version == exp_version


def get_time_stamp():
    return time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime(time.time()))


def get_linux_nvme_devs():
    dev_list = list()
    cmd = "lsblk"
    _, outs = execute(cmd)
    rets = re.findall("((nexus|nvme)\w+)", outs, re.DOTALL)
    if rets:
        for item in rets:
            ret_index = re.findall("(nexus|nvme)(\d+)n", item[0])
            if ret_index:
                dev_index = ret_index[0][1]
                dev = {"index": dev_index, "name": item[0]}
                dev_list.append(dev)
    return dev_list


def get_vendor_name(vendor_id):
    vendor_id = hex(int(vendor_id)).replace("0x", "")
    vendor_name = ""
    pci_ids_file = os.path.join(get_root_path(), "configuration", "pci.ids")
    with open(pci_ids_file, encoding='UTF-8') as pci_file:
        while True:
            line = pci_file.readline()
            if line:
                if not line.startswith("\t"):
                    if vendor_id.lower() in line.lower():
                        vendor_name = line.split(vendor_id)[1].strip()
                        break
            else:
                break
    return vendor_name


ROOT_PATH = get_root_path()
