#!/usr/bin/env python
# pylint: disable=attribute-defined-outside-init
"""
Created on 2020/06/06

@author: yyang
"""
import logging
import re
from ctypes import Structure, c_uint8, c_uint64, Union, string_at, addressof, sizeof, Array

DUMP = logging.getLogger('dump')


class Uint128(Structure):
    _pack_ = 1
    _fields_ = [
        ('LOW', c_uint64),
        ('HIGH', c_uint64),
    ]

    def __init__(self, value=0, **kwargs):
        super().__init__(**kwargs)
        self.value = value

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.value == other.value
        if isinstance(other, int):
            return self.value == other
        raise Exception("{!r} is not {} instance or int type".format(other, self.__class__))

    def __gt__(self, other):
        if isinstance(other, self.__class__):
            return self.value > other.value
        if isinstance(other, int):
            return self.value > other
        raise Exception("{!r} is not {} instance or int type".format(other, self.__class__))

    def __add__(self, other):
        if isinstance(other, self.__class__):
            return self.value + other.value
        if isinstance(other, int):
            return self.value + other
        raise Exception("{!r} is not {} instance or int type".format(other, self.__class__))

    def __sub__(self, other):
        if isinstance(other, self.__class__):
            return self.value - other.value
        if isinstance(other, int):
            return self.value - other
        raise Exception("{!r} is not {} instance or int type".format(other, self.__class__))

    def __format__(self, format_spec):
        return format(self.value, format_spec)

    def __str__(self):
        return str(self.value)

    def _get_(self):
        return (self.HIGH << 64) | self.LOW

    def _set_(self, value):
        self.HIGH = value >> 64
        self.LOW = value & ((1 << 64) - 1)

    def _del_(self):
        self.LOW = 0
        self.HIGH = 0

    value = property(_get_, _set_, _del_, 'value operation')


class Byte(Structure):
    _pack_ = 1
    _fields_ = [
        ('BYTE', c_uint8),
    ]


class Ascii(Structure):
    _pack_ = 1
    _fields_ = [
        ('ASCII', c_uint8),
    ]


def byte_array_to_string(array):
    if isinstance(array, Array):
        string = string_at(addressof(array), sizeof(array)).decode('utf-8', errors='ignore')
        return re.sub(r'[\x00-\x1f]', '', string).strip()
    return ''


class Ctype:
    def __init__(self, ctype, name='NAME'):
        self._name = name
        self._ctype = ctype
        self._lines = list()
        self._skip = list()

    @staticmethod
    def _format(indent, name, index=None):
        if index is None:
            return '{}{}'.format(' ' * indent, name)
        return '{}{}[{}]'.format(' ' * indent, name, index)

    @staticmethod
    def _desc(ctype, name):
        try:
            name = getattr(ctype, 'desc').get(name, name)
        except:
            pass
        return name

    def _parser(self, ctype, skip, indent=0, name=''):
        if isinstance(ctype, (Union, Structure)):
            if isinstance(ctype, Uint128):
                self._lines.append([self._format(indent, self._desc(ctype, name)), ctype.value])
                return

            string = name if name else type(ctype)
            if isinstance(string, (str, )):
                self._lines.append([self._format(indent, string), ''])

            for field in getattr(ctype, '_fields_'):
                name = field[0]
                if [i for i in skip if i in name]:
                    continue
                _ctype = getattr(ctype, name)

                if isinstance(string, (str, )):
                    self._parser(_ctype, skip, indent + 2, self._desc(ctype, name))
                else:
                    self._parser(_ctype, skip, indent, self._desc(ctype, name))
        elif isinstance(ctype, (Array,)):
            if isinstance(ctype[0], (Byte, )):
                string = byte_array_to_string(ctype)
                if string:
                    self._lines.append([self._format(indent, name), string])
            elif isinstance(ctype[0], (Ascii, )):
                string = "".join(["{:02x}".format(i.ASCII) for i in ctype])
                self._lines.append([self._format(indent, name), string])
            elif isinstance(ctype[0], (Union, Structure, Array)):
                self._lines.append([self._format(indent, name), ' '])
                for i, value in enumerate(ctype):
                    self._lines.append([self._format(indent + 2, name, i), ' '])
                    self._parser(value, skip, indent + 4)
            else:
                self._lines.append([self._format(indent, name), ' '])
                for i, value in enumerate(ctype):
                    self._lines.append([self._format(indent + 2, name, i), value])
        else:
            self._lines.append([self._format(indent, name), ctype])

    def _parser_dict(self, ctype, data, name=''):
        if isinstance(ctype, (Union, Structure)):
            if isinstance(ctype, Uint128):
                data[name] = ctype.value
                return

            name = name if name else type(ctype)
            if isinstance(name, (str, )):
                data[name] = {}
                _data = data[name]
            else:
                _data = data

            for field in getattr(ctype, '_fields_'):
                name = field[0]
                if [i for i in self._skip if i in name]:
                    continue
                _ctype = getattr(ctype, name)

                self._parser_dict(_ctype, _data, name)
        elif isinstance(ctype, (Array,)):
            if isinstance(ctype[0], (Byte, )):
                string = byte_array_to_string(ctype)
                if string:
                    data[name] = string
            elif isinstance(ctype[0], (Ascii, )):
                string = "".join(["{:02x}".format(i.ASCII) for i in ctype])
                data[name] = string
            elif isinstance(ctype[0], (Union, Structure, Array)):
                data[name] = list()
                for _, value in enumerate(ctype):
                    data[name].append({})
                    self._parser_dict(value, data[name][-1])
            else:
                data[name] = list()
                for _, value in enumerate(ctype):
                    data[name].append(value)
        else:
            data[name] = ctype

    def write(self, path):
        with open(path, 'wb') as fd:
            fd.write(self._ctype)

    def get(self, name):
        ctype = getattr(self._ctype, name)
        if isinstance(ctype, Uint128):
            return ctype.value
        if isinstance(ctype, (Array,)):
            if isinstance(ctype[0], Byte):
                string = string_at(addressof(ctype), sizeof(ctype)).decode('utf-8', errors='ignore')
                return re.sub(r'[\x00-\x1f]', '', string).strip()
        return ctype

    def dump(self, skip=None, no_rsv=True, only_values=False):
        self._lines = list()
        skip = skip if skip else list()
        if no_rsv:
            skip += ['rsv', 'RSV', 'Reserved']
        none_list = (0x0, '', None)

        self._parser(self._ctype, skip)

        name_list = [len(n) for n, v in self._lines if not only_values or v not in none_list] + [len(self._name)]
        max_name_len = max(name_list)
        f_title = '| {{:<{}}} | {{:<34}} | {{:<39}} |'.format(max_name_len)
        f_name = '{{:<{}}}'.format(max_name_len)

        title = f_title.format(self._name, 'HEX', 'DEC')
        DUMP.info(title)
        DUMP.info('-' * (83 + max_name_len))
        for name, value in self._lines:
            if only_values and value in none_list:
                continue

            line = list()
            line.append(f_name.format(name))
            if isinstance(value, (bool, int, float)):
                line.append("{:<#34x}".format(value))
                line.append("{:<39}".format(value))
            else:
                line.append("{:76}".format(value))

            line = "| {} |".format(" | ".join(line))
            DUMP.info(line)
        DUMP.info('-' * (83 + max_name_len))

    def dictionary(self, no_rsv=False):
        data = dict()
        if no_rsv:
            self._skip += ['rsv', 'RSV', 'Reserved']
        self._parser_dict(self._ctype, data)
        return data
