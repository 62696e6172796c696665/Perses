#!/usr/bin/env python
# pylint: disable=attribute-defined-outside-init
"""
Created on 2020/04/17

@author: yyang
"""
import fcntl
import math
import mmap
import os
import random
import re
import subprocess
import time
from ctypes import c_uint8, c_uint16, c_uint32, c_uint64, Structure, Union, sizeof, addressof

STATUS_FIELD = {
    0x0: 'Successful Completion',
    0x1: 'Invalid Command Opcode',
    0x2: 'Invalid Field in Command',
    0x3: 'Command ID Conflict',
    0x4: 'Data Transfer Error',
    0x5: 'Commands Aborted due to Power Loss Notification',
    0x6: 'Internal Error',
    0x7: 'Command Abort Requested',
    0x8: 'Command Aborted due to SQ Deletion',
    0x9: 'Command Aborted due to Failed Fused Command',
    0xa: 'Command Aborted due to Missing Fused Command',
    0xb: 'Invalid Namespace or Format',
    0xc: 'Command Sequence Error',
    0xd: 'Invalid SGL Segment Descriptor',
    0xe: 'Invalid Number of SGL Descriptors',
    0xf: 'Data SGL Length Invalid',
    0x10: 'Metadata SGL Length Invalid',
    0x11: 'SGL Descriptor Type Invalid',
    0x12: 'Invalid Use of Controller Memory Buffer',
    0x13: 'PRP Offset Invalid',
    0x14: 'Atomic Write Unit Exceeded',
    0x15: 'Operation Denied',
    0x16: 'SGL Offset Invalid',
    0x18: 'Host Identifier Inconsistent Format',
    0x19: 'Keep Alive Timeout Expired',
    0x1a: 'Keep Alive Timeout Invalid',
    0x1b: 'Command Aborted due to Preempt and Abort',
    0x1c: 'Sanitize Failed',
    0x1d: 'Sanitize In Progress',
    0x1e: 'SGL Data Block Granularity Invalid',
    0x1f: 'Command Not Supported for Queue in CMB',
    0x80: 'LBA Out of Range',
    0x81: 'Capacity Exceeded',
    0x82: 'Namespace Not Ready',
    0x83: 'Reservation Conflict',
    0x84: 'Format In Progress',

    0x100: 'Completion Queue Invalid',
    0x101: 'Invalid Queue Identifier',
    0x102: 'Invalid Queue Size',
    0x103: 'Abort Command Limit Exceeded',
    0x105: 'Asynchronous Event Request Limit Exceeded',
    0x106: 'Invalid Firmware Slot',
    0x107: 'Invalid Firmware Image',
    0x108: 'Invalid Interrupt Vector',
    0x109: 'Invalid Log Page',
    0x10a: 'Invalid Format',
    0x10b: 'Firmware Activation Requires Conventional Reset',
    0x10c: 'Invalid Queue Deletion',
    0x10d: 'Feature Identifier Not Saveable',
    0x10e: 'Feature Not Changeable',
    0x10f: 'Feature Not Namespace Specific',
    0x110: 'Firmware Activation Requires NVM Subsystem Reset',
    0x111: 'Firmware Activation Requires Controller Level Reset',
    0x112: 'Firmware Activation Requires Maximum Time Violation',
    0x113: 'Firmware Activation Prohibited',
    0x114: 'Overlapping Range',
    0x115: 'Namespace Insufficient Capacity',
    0x116: 'Namespace Identifier Unavailable',
    0x118: 'Namespace Already Attached',
    0x119: 'Namespace Is Private',
    0x11a: 'Namespace Not Attached',
    0x11b: 'Thin Provisioning Not Supported',
    0x11c: 'Controller List Invalid',
    0x11d: 'Device Self-test In Progress',
    0x11e: 'Boot Partition Write Prohibited',
    0x11f: 'Invalid Controller Identifier',
    0x120: 'Invalid Secondary Controller State',
    0x121: 'Invalid Number of Controller Resources',
    0x122: 'Invalid Resource Identifier',
    0x180: 'Conflicting Attributes',
    0x181: 'Invalid Protection Information',
    0x182: 'Attempted Write to Read Only Range',

    0x280: 'Write Fault',
    0x281: 'Unrecovered Read Error',
    0x282: 'End-to-end Guard Check Error',
    0x283: 'End-to-end Application Tag Check Error',
    0x284: 'End-to-end Reference Tag Check Error',
    0x285: 'Compare Failure',
    0x286: 'Access Denied',
    0x287: 'Deallocated or Unwritten Logical Block',
}


class Opcode:
    DELETE_IO_SQ = 0x00
    CREATE_IO_SQ = 0x01
    GET_LOG_PAGE = 0x02
    DELETE_IO_CQ = 0x04
    CREATE_IO_CQ = 0x05
    IDENTIFY = 0x06
    ABORT = 0x08
    SET_FEATURES = 0x09
    GET_FEATURES = 0x0A
    ASYNC_EVENT_REQUEST = 0x0C
    NAMESPACE_MGT = 0x0D
    FIRMWARE_COMMIT = 0x10
    FIRMWARE_DOWNLOAD = 0x11
    NAMESPACE_ATTACH = 0x15
    VIRT_MANAGEMENT = 0x1C
    FORMAT_NVM = 0x80
    SECURITY_SEND = 0x81
    SECURITY_RECV = 0x82

    FLUSH = 0x00
    WRITE = 0x01
    READ = 0x02
    WRITE_UNCORRECTABLE = 0x04
    COMPARE = 0x05
    WRITE_ZEROES = 0x08
    DATASET_MGT = 0x09
    RESERVATION_REGISTER = 0x0D
    RESERVATION_REPORT = 0x0E
    RESERVATION_ACQUIRE = 0x11
    RESERVATION_RELEASE = 0x15

    CNEX_WRITE_MEM = 0x99
    CNEX_READ_MEM = 0x9A

    ADMIN = {
        0x0: 'Delete IO SQ',
        0x1: 'Create IO SQ',
        0x2: 'Get Log Page',
        0x4: 'Delete IO CQ',
        0x5: 'Create IO CQ',
        0x6: 'Identify',
        0x8: 'Abort',
        0x9: 'Set Features',
        0xa: 'Get Features',
        0xc: 'Asynchronous Event Request',
        0xd: 'Namespace Management',
        0x10: 'Firmware_Commit',
        0x11: 'Firmware Image_Download',
        0x14: 'Device Self-test',
        0x15: 'Namespace Attachment',
        0x18: 'Keep Alive',
        0x19: 'Directive Send',
        0x1a: 'Directive Receive',
        0x1c: 'Virtualization Management',
        0x1d: 'NVMe-MI Send',
        0x1e: 'NVMe-MI Receive',
        0x7c: 'Doorbell Buffer Config',
        0x80: 'Format NVM',
        0x81: 'Security Send',
        0x82: 'Security Receive',
        0x84: 'Sanitize',
    }

    IO = {
        0x0: 'Flush',
        0x1: 'Write',
        0x2: 'Read',
        0x4: 'Write Uncorrectable',
        0x5: 'Compare',
        0x8: 'Write Zeroes',
        0x9: 'Dataset Management',
        0xd: 'Reservation Register',
        0xe: 'Reservation Report',
        0x11: 'Reservation Acquire',
        0x15: 'Reservation Release',

        0x99: 'CNEX Write Memory',
        0x9a: 'CNEX Read Memory'
    }


class NVMeUserIO(Union):
    class Bits(Structure):
        _pack_ = 1
        _fields_ = [
            ('opcode', c_uint8),
            ('flags', c_uint8),
            ('control', c_uint16),
            ('nblocks', c_uint16),
            ('rsvd', c_uint16),
            ('meta', c_uint64),
            ('data', c_uint64),
            ('slba', c_uint64),
            ('dsmgmt', c_uint32),
            ('reftag', c_uint32),
            ('apptag', c_uint16),
            ('appmask', c_uint16),
        ]

    class Cdws(Structure):
        _pack_ = 1
        _fields_ = [
            ('cdw', c_uint32 * 12),
        ]

    _anonymous_ = ('cdws', 'bits')
    _fields_ = [
        ('cdws', Cdws),
        ('bits', Bits),
    ]


class NVMePassthruCmd(Union):
    """
    Take Care: different with SQE!
    cdw8 is metadata_len and cdw9 is data_len
    Add cdw16: timeout
    Add cdw17: dword0 of CQE
    """

    class Bits(Structure):
        _pack_ = 1
        _fields_ = [
            ('opcode', c_uint8),
            ('flags', c_uint8),
            ('rsvd', c_uint16),
            ('nsid', c_uint32),
            ('cdw2', c_uint32),
            ('cdw3', c_uint32),
            ('meta', c_uint64),
            ('data', c_uint64),
            ('meta_len', c_uint32),
            ('data_len', c_uint32),
            ('cdw10', c_uint32),
            ('cdw11', c_uint32),
            ('cdw12', c_uint32),
            ('cdw13', c_uint32),
            ('cdw14', c_uint32),
            ('cdw15', c_uint32),
            ('timeout', c_uint32),
            ('result', c_uint32),
        ]

    class Cdws(Structure):
        _pack_ = 1
        _fields_ = [
            ('cdw', c_uint32 * 18),
        ]

    _anonymous_ = ('cdws', 'bits')
    _fields_ = [
        ('cdws', Cdws),
        ('bits', Bits),
    ]


def _iowr(_tp, _nr, _sz):
    return (3 << 30) + (sizeof(_sz) << 16) + (ord(_tp) << 8) + _nr


def _iow(_tp, _nr, _sz):
    return (1 << 30) + (sizeof(_sz) << 16) + (ord(_tp) << 8) + _nr


def _io(_tp, _nr):
    return (ord(_tp) << 8) + _nr


class NVMe:
    NVME_IOCTL_ADMIN_CMD = _iowr('N', 0x41, NVMePassthruCmd)
    NVME_IOCTL_SUBMIT_IO = _iow('N', 0x42, NVMeUserIO)
    NVME_IOCTL_IO_CMD = _iowr('N', 0x43, NVMePassthruCmd)
    NVME_IOCTL_RESET = _io('N', 0x44)
    NVME_IOCTL_SUBSYS_RESET = _io('N', 0x45)

    def __init__(self, device='/dev/nvme', cntid=0, nsid=1):
        self._status = 0
        self._c_fd = -1
        self._b_fd = -1

        self._c_dev = "{}{}".format(device, cntid)
        self._b_dev = "{}{}n{}".format(device, cntid, nsid)

    def __del__(self):
        self._close_c_fd()
        self._close_b_fd()

    @staticmethod
    def _open(dev):
        assert os.path.exists(dev), 'Device({}) is not exists'.format(dev)
        return os.open(dev, os.O_RDWR)

    @property
    def char_fd(self):
        if self._c_fd == -1:
            self._c_fd = self._open(self._c_dev)
        return self._c_fd

    @property
    def block_fd(self):
        if self._b_fd == -1:
            self._b_fd = self._open(self._b_dev)
        return self._b_fd

    def _close_c_fd(self):
        if self._c_fd != -1:
            os.close(self._c_fd)
            self._c_fd = -1

    def _close_b_fd(self):
        if self._b_fd != -1:
            os.close(self._b_fd)
            self._b_fd = -1

    def close(self):
        self.__del__()

    @staticmethod
    def _ioctl(handle, request, cmd=None, status=0):
        _status = fcntl.ioctl(handle, request, cmd) if cmd else fcntl.ioctl(handle, request)

        try:
            assert (_status & 0x7ff) == status, "CQE Status Field Check Failed!"
        except AssertionError:
            print('Actual Status: {:#x}, {}'.format(_status, STATUS_FIELD.get(_status & 0x7ff, 'Unknown')))
            print("Expect Status: {:#x}, {}".format(status, STATUS_FIELD.get(status & 0x7ff, 'Unknown')))
            if cmd:
                cmd_set = Opcode.ADMIN if isinstance(cmd, NVMePassthruCmd) else Opcode.IO
                print('Command : {}'.format(cmd_set.get(cmd.opcode, 'Unknown')))
                sqe = [(f[0], '{:#x}'.format(getattr(cmd.bits, f[0]))) for f in getattr(cmd.bits, '_fields_')]
                print('SQE : {}'.format(dict(sqe)))
            raise

        return _status

    def nvme_io(self, cmd, **kwargs):
        return self._ioctl(self.block_fd, self.NVME_IOCTL_SUBMIT_IO, cmd, **kwargs)

    def io_passthru(self, cmd, **kwargs):
        return self._ioctl(self.char_fd, self.NVME_IOCTL_IO_CMD, cmd, **kwargs)

    def admin_passthru(self, cmd, **kwargs):
        return self._ioctl(self.char_fd, self.NVME_IOCTL_ADMIN_CMD, cmd, **kwargs)

    def reset(self, **kwargs):
        return self._ioctl(self.char_fd, self.NVME_IOCTL_RESET, **kwargs)

    def subsys_reset(self, **kwargs):
        return self._ioctl(self.char_fd, self.NVME_IOCTL_SUBSYS_RESET, **kwargs)

    def rdma_read_list(self, offset, ndw=1, nsid=1, **kwargs):
        length = math.ceil(ndw / 1024) * 1024
        data = (c_uint32 * length)()

        cmd = NVMePassthruCmd()
        cmd.opcode = Opcode.CNEX_READ_MEM
        cmd.nsid = nsid
        cmd.cdw[10] = offset & 0xffffffff
        cmd.cdw[11] = offset >> 32
        cmd.cdw[12] = ndw - 1
        cmd.data = addressof(data)
        cmd.data_len = length * 4

        return self.io_passthru(cmd, **kwargs), data[0:ndw]

    def rdma_write_list(self, offset, array, nsid=1, **kwargs):
        ndw = len(array)
        length = math.ceil(ndw / 1024) * 1024
        data = (c_uint32 * length)(*array)

        cmd = NVMePassthruCmd()
        cmd.opcode = Opcode.CNEX_WRITE_MEM
        cmd.nsid = nsid
        cmd.cdw[10] = offset & 0xffffffff
        cmd.cdw[11] = offset >> 32
        cmd.cdw[12] = ndw - 1
        cmd.data = addressof(data)
        cmd.data_len = length * 4

        return self.io_passthru(cmd, **kwargs)

    def rdma_read(self, offset, **kwargs):
        return self.rdma_read_list(offset, ndw=1, **kwargs)[1][0]

    def rdma_write(self, offset, value, **kwargs):
        self.rdma_write_list(offset, [value], **kwargs)

    def fw_inject_uecc_start(self, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.opcode = 0xC0
        cmd.cdw[10] = 0x1
        cmd.cdw[15] = 0x14
        return self.admin_passthru(cmd, **kwargs)

    def fw_inject_uecc_stop(self, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.opcode = 0xC0
        cmd.cdw[10] = 0x0
        cmd.cdw[15] = 0x14
        return self.admin_passthru(cmd, **kwargs)

    def read_register(self, addr, **kwargs):
        dptr = (c_uint32 * 1024)()
        cmd = NVMePassthruCmd()
        cmd.opcode = 0xC0
        cmd.cdw[10] = 0x2
        cmd.cdw[11] = addr
        cmd.cdw[15] = 0x14
        cmd.data = addressof(dptr)
        cmd.data_len = sizeof(dptr)
        self.admin_passthru(cmd, **kwargs)
        return dptr[0]

    def write_register(self, addr, value, **kwargs):
        cmd = NVMePassthruCmd()
        cmd.opcode = 0xC0
        cmd.cdw[10] = 0x3
        cmd.cdw[11] = addr
        cmd.cdw[12] = value
        cmd.cdw[15] = 0x14
        return self.admin_passthru(cmd, **kwargs)


class PCIe:
    def __init__(self, device='/dev/nvme0', bid='0'):
        self._bar_fd = None
        self._cfg_fd = None
        self._mmap = None
        self._bdf = None
        self._bid = bid
        self._device = device

    def __del__(self):
        if self._mmap:
            self._mmap.close()
            self._mmap = None

        if self._bar_fd:
            self._bar_fd.close()
            self._bar_fd = None

        if self._cfg_fd:
            self._cfg_fd.close()
            self._cfg_fd = None

    def close(self):
        self.__del__()

    @property
    def bdf(self):
        if not self._bdf:
            uevent = '/sys/class/nvme/{}/device/uevent'.format(re.findall(r'(nvme\d+)', self._device)[0])
            with open(uevent, encoding='utf-8') as file:
                self._bdf = re.findall(r'PCI_SLOT_NAME=(.*?)\n', file.read())[0]
        return self._bdf

    @property
    def mmap(self):
        if not self._mmap:
            filename = '/sys/bus/pci/devices/{}/resource{}'.format(self.bdf, self._bid)
            assert os.path.exists(filename), 'Cannot find file: {}'.format(filename)

            self._bar_fd = open(filename, 'wb+')    # pylint: disable=consider-using-with
            assert self._bar_fd, 'Cannot open file: {}'.format(filename)

            self._mmap = mmap.mmap(self._bar_fd.fileno(), 0x0)

        return self._mmap

    @property
    def config(self):
        if not self._cfg_fd:
            filename = '/sys/bus/pci/devices/{}/config'.format(self.bdf)
            self._cfg_fd = open(filename, 'wb+')    # pylint: disable=consider-using-with

        return self._cfg_fd

    def flush(self, offset):
        offset -= (offset % 4096)
        self.mmap.flush(offset, 4096)

    def read_config(self, offset, size=1):
        self.config.seek(offset)
        return int.from_bytes(self.config.read(size), byteorder='little', signed=False)

    def write_config(self, offset, value, size=1):
        self.config.seek(offset)
        return self.config.write(value.to_bytes(length=size, byteorder='little', signed=False))

    def read_bar(self, offset, size=1):
        self.mmap.seek(offset)
        return int.from_bytes(self.mmap.read(size), byteorder='little', signed=False)

    def write_bar(self, offset, value, size=1):
        self.mmap.seek(offset)
        return self.mmap.write(value.to_bytes(length=size, byteorder='little', signed=False))

    def read_bar_uint8(self, offset):
        return self.read_bar(offset, size=1)

    def read_bar_uint32(self, offset):
        return self.read_bar(offset, size=4)

    def write_bar_uint8(self, offset, value):
        self.write_bar(offset, value, size=1)

    def write_bar_uint32(self, offset, value):
        self.write_bar(offset, value, size=4)


class Register:
    def __init__(self, mode='rdma'):
        self._mode = mode

        assert self._mode in ('rdma', 'pcie', 'fw'), 'Mode "{}" not in ("rdma", "pcie", "fw")'.format(self._mode)
        if self._mode == 'pcie':
            self.pcie = PCIe()
            self._read = self.pcie.read_bar_uint32
            self._write = self.pcie.write_bar_uint32
        else:
            self.nvme = NVMe()
            if self._mode == 'fw':
                self._read = self.nvme.read_register
                self._write = self.nvme.write_register
            else:
                self._read = self.nvme.rdma_read
                self._write = self.nvme.rdma_write

    def read(self, offset):
        return self._read(offset)

    def write(self, offset, value):
        self._write(offset, value)


MAX_BLK_NUM = 0x40414
PPA_FORMAT = 0x40420
CURRENT_PPA = 0x47064
PROG_ERR_LOW = 0x4d400
PROG_ERR_HIGH = 0x4d404
UECC_BASE_ADDR = 0xc4008
PROG_ERR_CNT_WT = 0x47200
PROG_ERR_CNT_DT = 0x20002
PROG_ERR_CNT_RD = 0x47204
WFB_UPT_BADB_EN = 0x4f680

PPA_FIELDS = ['ch', 'ep', 'pl', 'ln', 'pg', 'bl']


class PPAf(Union):
    class Bits(Structure):
        _pack_ = 1
        _fields_ = [(field, c_uint32, 4) for field in PPA_FIELDS]

    _anonymous_ = ('bits',)
    _fields_ = [
        ('value', c_uint32),
        ('bits', Bits),
    ]


def generate_ppa(ppaf):
    bits = [getattr(ppaf, field) for field in PPA_FIELDS]
    assert 0 < sum(bits) <= 32, 'Invalid PPAf: {:#x}, {}'.format(ppaf.value, dict(zip(PPA_FIELDS, bits)))

    class PPA(Union):
        class Bits(Structure):
            _pack_ = 1
            _fields_ = [(field, c_uint32, getattr(ppaf, field)) for field in PPA_FIELDS]

        _anonymous_ = ('bits',)
        _fields_ = [
            ('value', c_uint32),
            ('bits', Bits),
        ]

    return PPA


class Error:
    def __init__(self, channel=8, mode='rdma'):
        self.quad = channel // 4

        self.reg = Register(mode)
        self.nvme = NVMe()

        self.ue_en = [UECC_BASE_ADDR + i * 0x1000 for i in range(self.quad)]
        self.ue_mask = [UECC_BASE_ADDR + i * 0x1000 + 4 for i in range(self.quad)]
        self.ue_ppa = [UECC_BASE_ADDR + i * 0x1000 + 8 for i in range(self.quad)]

        self._ppa = None
        self._max_bl = 0
        self.max_ch = channel - 1

    @property
    def ppa(self):
        if not self._ppa:
            ppaf = PPAf()
            ppaf.value = self.reg.read(PPA_FORMAT)
            self._ppa = generate_ppa(ppaf)
        return self._ppa()

    @property
    def max_bl(self):
        if not self._max_bl:
            self._max_bl = self.reg.read(MAX_BLK_NUM) - 1
        return self._max_bl

    def _get_ppa(self, value=0):
        ppa = self.ppa
        ppa.value = value
        return ppa

    def _get_current_ppa(self):
        return self._get_ppa(self.reg.read(CURRENT_PPA))

    def _get_current_ppa(self):
        ppa = self._get_ppa(random.randint(0, 0xffffffff))
        ppa.bl = random.randint(0, self.max_bl)
        ppa.ch = random.randint(0, self.max_ch)
        return ppa

    @staticmethod
    def _get_quad(channel):
        return channel // 4

    def disable_wfb_upt_badb(self):
        """
        Set register WFB_UPT_BADB_EN bit4 = 0
        """
        reg = self.reg.read(WFB_UPT_BADB_EN)
        self.reg.write(WFB_UPT_BADB_EN, reg & (~(1 << 4)))
        print("DISABLE WFB UPDATE BADB, {:#x}: {:#x}".format(WFB_UPT_BADB_EN, self.reg.read(WFB_UPT_BADB_EN)))

    def enable_wfb_upt_badb(self):
        """
        Set register WFB_UPT_BADB_EN bit4 = 1
        """
        reg = self.reg.read(WFB_UPT_BADB_EN)
        self.reg.write(WFB_UPT_BADB_EN, reg | (1 << 4))
        print("ENABLE WFB UPDATE BADB, {:#x}: {:#x}".format(WFB_UPT_BADB_EN, self.reg.read(WFB_UPT_BADB_EN)))

    def inject_uecc_status(self, ppa, mask=0x0, group=0):
        ppa = self._get_ppa(ppa)
        quad = self._get_quad(ppa.ch)
        print("Inject UECC, QUAD: {:#x}, GROUP: {:#x}, PPA: {:#8x}, MASK: {:#8x}".format(quad, group, ppa.value, mask))

        reg_ue_en = self.ue_en[quad] + 0xC * group
        reg_ue_mask = self.ue_mask[quad] + 0xC * group
        reg_ue_ppa = self.ue_ppa[quad] + 0xC * group

        dat_ue_en = self.reg.read(reg_ue_en) | 0x1
        self.reg.write(reg_ue_en, dat_ue_en)
        self.reg.write(reg_ue_mask, mask)
        self.reg.write(reg_ue_ppa, ppa.value)

    def inject_uecc_status_fields(self, group=0, **args):
        ppa = self._get_ppa()
        mask = self._get_ppa(0xffffffff)

        for key, val in args.items():
            setattr(ppa, key, val)
            setattr(mask, key, 0x0)

        self.inject_uecc_status(ppa.value, mask.value, group=group)

    def fw_inject_uecc(self):
        self.nvme.fw_inject_uecc_start()

    def fw_disable_uecc(self):
        self.nvme.fw_inject_uecc_stop()

    def inject_uecc_status_fields_random(self, group=0):
        ppa = self._get_current_ppa()

        args = dict()
        for key in ['pg'] + random.sample(['ln', 'pl', 'ep', 'ch'], 2):
            args[key] = getattr(ppa, key)

        self.inject_uecc_status_fields(group=group, **args)

    def display_uecc_status_reg(self):
        for quad in range(self.quad):
            for group in range(2):
                reg_ue_en = self.ue_en[quad] + 0xC * group
                reg_ue_mask = self.ue_mask[quad] + 0xC * group
                reg_ue_ppa = self.ue_ppa[quad] + 0xC * group

                print("Display UECC QUAD: {}, GRP: {}, EN: {:#x}, MASK: {:#x}, PPA: {:#x}".format(
                    quad,
                    group,
                    self.reg.read(reg_ue_en),
                    self.reg.read(reg_ue_mask),
                    self.reg.read(reg_ue_ppa)
                ))

    def disable_uecc_status(self):
        print('Disable UECC')
        for quad in range(self.quad):
            for group in range(2):
                reg_ue_en = self.ue_en[quad] + 0xC * group
                dat_ue_en = self.reg.read(reg_ue_en) & 0xfffffffe
                self.reg.write(reg_ue_en, dat_ue_en)

    def inject_prog_error(self, ch_en, **args):
        bits_dict = {'pl': 6, 'ln': 8, 'pg': 13, 'bl': 23}
        ppa = self._get_ppa()
        bit_cov = 38

        for key, val in args.items():
            setattr(ppa, key.upper(), val)
            bit_cov = min(bit_cov, bits_dict[key.upper()])

        bl_l = ppa.bl & 0x1ff
        bl_h = (ppa.bl & 0xfe00) >> 9

        low = ppa.ch + (ppa.ep << 4) + (ppa.pl << 6) + (ppa.ln << 8) + (ppa.pg << 13) + (bl_l << 23)
        high = 0x80000000 + (bit_cov << 24) + (bl_h << 16) + ch_en

        print("Inject Program Error, HIGH: {:#x}, LOW: {:#x}".format(high, low))
        self.reg.write(PROG_ERR_LOW, low)
        self.reg.write(PROG_ERR_HIGH, high)

    def inject_prog_error_to_page(self):
        ppa = self._get_current_ppa()
        self.inject_prog_error(0xffff, bl=ppa.bl, pg=ppa.pg)

    def display_prog_error_count(self):
        self.reg.write(PROG_ERR_CNT_WT, PROG_ERR_CNT_DT)
        value = self.reg.read(PROG_ERR_CNT_RD)
        print("Program error, fail count: {}, timeout count: {}".format(
            value & 0xffff, value >> 16
        ))

    def display_prog_error_register(self):
        low = self.reg.read(PROG_ERR_LOW)
        high = self.reg.read(PROG_ERR_HIGH)
        print("Display program Error, HIGH: {:#x}, LOW: {:#x}".format(high, low))

    def disable_prog_error(self):
        print('Disable Program Error')
        self.reg.write(PROG_ERR_LOW, 0x0)
        self.reg.write(PROG_ERR_HIGH, 0x0)


class UsbRelay:
    def __init__(self, usb=0):
        cmd = 'usbrelay 2>/dev/null'
        output = subprocess.check_output(cmd, shell=True).decode('utf-8', errors='ignore')
        port_list = re.findall(r'([A-Z0-9_]+)=\d', output)
        self.port = port_list[usb]

        self.press_down = "usbrelay {}=1".format(self.port)
        self.press_up = "usbrelay {}=0".format(self.port)

    def press(self, timeout=8.0):
        assert subprocess.call(self.press_down, shell=True) == 0, 'usbrelay({}) key down failed'.format(self.port)
        time.sleep(timeout)
        assert subprocess.call(self.press_up, shell=True) == 0, 'usbrelay({}) key up failed'.format(self.port)
