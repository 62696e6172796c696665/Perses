#!/usr/bin/env python
# pylint: disable=attribute-defined-outside-init
"""
Created on 2020/04/16

@author: yyang
"""
import logging
import random
from ctypes import Structure, Union, c_uint32, c_uint64

from lib.driver.nvme import CNEX, Tahoe

LOG = logging.getLogger()


class Error:
    REG_MAX_CH = 0x40400
    REG_MAX_EP = 0x40404
    REG_MAX_PL = 0x40408
    REG_MAX_LN = 0x4040c
    REG_MAX_PG = 0x40410
    REG_MAX_BL = 0x40414

    PPA_FORMAT = 0x40420
    CURRENT_PPA = 0x47064
    WFB_UPT_BADB_EN = 0x4f680

    STATUS_ERR_EN = 0xc4008
    STATUS_MASK = 0xc400c
    STATUS_PPA = 0xc4010

    PROG_ERR_LOW = 0x4d400
    PROG_ERR_HIGH = 0x4d404
    PROG_ERR_CNT_WT = 0x47200
    PROG_ERR_CNT_RD = 0x47204
    PROG_ERR_CNT_DT = 0x20002

    PPA_MASK = (1 << 32) - 1
    PPA_FIELDS = ('BL', 'PG', 'LN', 'PL', 'EP', 'CH')

    class PPAF(Union):
        class BITS(Structure):
            _pack_ = 1
            _fields_ = [
                ('CH', c_uint64, 4),
                ('EP', c_uint64, 4),
                ('PL', c_uint64, 4),
                ('LN', c_uint64, 4),
                ('PG', c_uint64, 4),
                ('BL', c_uint64, 4),
            ]

        _anonymous_ = ('BITS',)
        _fields_ = [
            ('VALUE', c_uint64),
            ('BITS', BITS),
        ]

    def __init__(self, channel=8, mode='fw'):
        self._quad = channel // 4
        self._mode = mode

        assert mode in ('rdma', 'pcie', 'fw'), 'Invalid mode: {}'.format(mode)

        self.nvme = CNEX()

        self._ppa = None
        self._ppaf = None
        self._max_ch = None
        self._max_ep = None
        self._max_pl = None
        self._max_ln = None
        self._max_pg = None
        self._max_bl = None

    @property
    def pcie(self):
        return self.nvme.pcie

    @property
    def ppaf(self):
        if not self._ppaf:
            self._ppaf = self.PPAF()
            self._ppaf.VALUE = self._read(self.PPA_FORMAT)
        return self._ppaf

    @property
    def ppa(self):
        if not self._ppa:
            self._ppa = self._generate_ppa(self.ppaf)
        return self._ppa()

    @property
    def max_ch(self):
        if not self._max_ch:
            self._max_ch = self._read(Error.REG_MAX_CH)
        return self._max_ch

    @property
    def max_ep(self):
        if not self._max_ep:
            self._max_ep = self._read(Error.REG_MAX_EP)
        return self._max_ep

    @property
    def max_pl(self):
        if not self._max_pl:
            self._max_pl = self._read(Error.REG_MAX_PL)
        return self._max_pl

    @property
    def max_ln(self):
        if not self._max_ln:
            self._max_ln = self._read(Error.REG_MAX_LN)
        return self._max_ln

    @property
    def max_pg(self):
        if not self._max_pg:
            self._max_pg = self._read(Error.REG_MAX_PG)
        return self._max_pg

    @property
    def max_bl(self):
        if not self._max_bl:
            self._max_bl = self._read(Error.REG_MAX_BL)
        return self._max_bl

    @staticmethod
    def _get_quad(channel):
        return channel // 4

    @staticmethod
    def _generate_ppa(ppaf):
        bits = [getattr(ppaf, field) for field in ['BL', 'PG', 'LN', 'PL', 'EP', 'CH']]
        assert 0 < sum(bits) <= 32, 'Invalid PPAF: {:#x}'.format(ppaf)

        class PPA(Union):
            class BITS(Structure):
                _pack_ = 1
                _fields_ = [
                    ('CH', c_uint64, ppaf.CH),
                    ('EP', c_uint64, ppaf.EP),
                    ('PL', c_uint64, ppaf.PL),
                    ('LN', c_uint64, ppaf.LN),
                    ('PG', c_uint64, ppaf.PG),
                    ('BL', c_uint64, ppaf.BL),
                ]

            class DWORD(Structure):
                _pack_ = 1
                _fields_ = [
                    ('VALUE', c_uint64, sum(bits)),
                ]

            _anonymous_ = ('BITS', 'DWORD')
            _fields_ = [
                ('DWORD', DWORD),
                ('BITS', BITS),
            ]

        return PPA

    def _calc_ppa(self, **kwargs):
        ppa = self._get_ppa()
        for key, val in kwargs.items():
            if key.upper() in self.PPA_FIELDS:
                setattr(ppa, key.upper(), val)
        return ppa

    def _calc_mask(self, args):
        mask = self._get_ppa()
        for key in args:
            if key.upper() in self.PPA_FIELDS:
                setattr(mask, key.upper(), ErrorTahoe.PPA_MASK)
        return mask

    def _read(self, offset, nsid=None):
        if self._mode == 'pcie':
            return self.pcie.read_bar_uint32(offset)
        if self._mode == 'fw':
            return self.nvme.read_register(offset)
        return self.nvme.rdma_read(offset, nsid=nsid)

    def _write(self, offset, value, nsid=None):
        LOG.info("Write Register {addr: 0x%x, value: 0x%x}", offset, value)
        if self._mode == 'pcie':
            return self.pcie.write_bar_uint32(offset, value)
        if self._mode == 'fw':
            return self.nvme.write_register(offset, value)
        return self.nvme.rdma_write(offset, value, nsid=nsid)

    def _get_ppa(self, value=0):
        ppa = self.ppa
        ppa.VALUE = value
        return ppa

    def _get_current_ppa(self):
        return self._get_ppa(self._read(self.CURRENT_PPA))

    def _get_random_ppa(self, min_pg=0):
        ppa = self._get_ppa()
        ppa.BL = random.randint(0, self.max_bl)
        ppa.LN = random.randint(0, self.max_ln)
        ppa.PL = random.randint(0, self.max_pl)
        ppa.EP = random.randint(0, self.max_ep)
        ppa.CH = random.randint(0, self.max_ch)
        while True:
            ppa.PG = random.randint(min_pg, self.max_pg)
            # remove  page 0x0, page 0x4, page 0x8, page 0xc...
            if ppa.PG % 4 != 0:
                break
        return ppa

    def disable_wfb_upt_badb(self):
        reg = self._read(self.WFB_UPT_BADB_EN)
        self._write(self.WFB_UPT_BADB_EN, reg & 0xffffffef)
        LOG.info("Disable WFB Update Bad Block, 0x%x: 0x%x", self.WFB_UPT_BADB_EN, self._read(self.WFB_UPT_BADB_EN))

    def enable_wfb_upt_badb(self):
        reg = self._read(self.WFB_UPT_BADB_EN)
        self._write(self.WFB_UPT_BADB_EN, reg | 0x10)
        LOG.info("Enable WFB Update Bad Block, 0x%x: 0x%x", self.WFB_UPT_BADB_EN, self._read(self.WFB_UPT_BADB_EN))

    def fw_inject_uecc(self):
        self.nvme.fw_inject_uecc_start()

    def fw_disable_uecc(self):
        self.nvme.fw_inject_uecc_stop()

    def inject_uecc_status(self, ppa, mask=0x0, group=0, cnt=2):
        ppa = self._get_ppa(ppa)
        mask = self._get_ppa(mask ^ Error.PPA_MASK)
        quad = self._get_quad(ppa.CH)
        LOG.info("Inject UECC Status Error, QUAD: 0x%x, GROUP: 0x%x, PPA: 0x%x, MASK: 0x%x", quad, group, ppa.VALUE,
                 mask.VALUE)

        reg_en = self.STATUS_ERR_EN + 0x1000 * quad
        reg_mask = self.STATUS_MASK + 0x1000 * quad + 0xC * group
        reg_ppa = self.STATUS_PPA + 0x1000 * quad + 0xC * group
        self._write(reg_en, self._read(reg_en) | (1 << group) | ((cnt & 0xF) << (8 + 4 * group)))
        self._write(reg_mask, mask.VALUE)
        self._write(reg_ppa, ppa.VALUE)

    def inject_uecc_status_fields(self, group=0, cnt=2, **kwargs):
        ppa = self._calc_ppa(**kwargs)
        mask = self._calc_mask(kwargs.keys())
        self.inject_uecc_status(ppa.VALUE, mask.VALUE, group=group, cnt=cnt)

    def inject_uecc_status_fields_random(self, group=0, cnt=2, mask=('ch', 'pl', 'ln', 'pg')):
        ppa = self._get_random_ppa()
        mask = self._calc_mask(mask)
        self.inject_uecc_status(ppa.VALUE, mask.VALUE, group=group, cnt=cnt)

    def disable_uecc_status(self):
        LOG.info('Disable UECC Status')
        for quad in range(self._quad):
            self._write(self.STATUS_ERR_EN + 0x1000 * quad, 0)

    def inject_prog_error(self, ch_en, **kwargs):
        bits_dict = {'PL': 6, 'LN': 8, 'PG': 13, 'BL': 23}
        ppa = self._calc_ppa(**kwargs)
        bit_cov = 38

        for key in kwargs:
            bit_cov = min(bit_cov, bits_dict[key.upper()])

        bl_l = ppa.BL & 0x1ff
        bl_h = (ppa.BL & 0xfe00) >> 9
        low = ppa.CH + (ppa.EP << 4) + (ppa.PL << 6) + (ppa.LN << 8) + (ppa.PG << 13) + (bl_l << 23)
        high = 0x80000000 + (bit_cov << 24) + (bl_h << 16) + ch_en

        LOG.info("Inject Program Error, HIGH: 0x%x, LOW: 0x%x", high, low)
        self._write(self.PROG_ERR_LOW, low)
        self._write(self.PROG_ERR_HIGH, high)

    def inject_prog_error_to_page(self):
        ppa = self._get_current_ppa()
        self.inject_prog_error(0xffff, bl=ppa.BL, pg=ppa.PG)

    def display_prog_error_count(self):
        self._write(self.PROG_ERR_CNT_WT, self.PROG_ERR_CNT_DT)
        value = self._read(self.PROG_ERR_CNT_RD)
        LOG.info("Program Error Info, FAILED: %d, TIMEOUT: %d", value & 0xffff, value >> 16)
        return value

    def disable_prog_error(self):
        LOG.info('Disable Program Error')
        self._write(self.PROG_ERR_LOW, 0x0)
        self._write(self.PROG_ERR_HIGH, 0x0)


class ErrorTahoe(Error):
    STATUS_ERR_EN = 0xc4008
    STATUS_MASK_L = 0xc400c
    STATUS_MASK_H = 0xc4010
    STATUS_PPA_L = 0xc4014
    STATUS_PPA_H = 0xc4018

    DATA_ERR_MASK_L = 0xc4050
    DATA_ERR_MASK_H = 0xc4054
    DATA_ERR_PPA_L = 0xc4058
    DATA_ERR_PPA_H = 0xc405c
    DATA_ERR_CNT = 0xc4060
    DATA_ERR_CNT_LIMIT = 0xc4064

    PROG_ERR_MASK_L = 0x4d3f4
    PROG_ERR_MASK_H = 0x4d3f8
    PROG_ERR_PPA_L = 0x4d3fc
    PROG_ERR_PPA_H = 0x4d400
    PROG_ERR_CNT_LIMIT = 0x4d404

    RRE_ERR_CODE = 0x43008
    RRE_ERR_MASK_L = 0x43010
    RRE_ERR_MASK_H = 0x43014
    RRE_ERR_PPA_L = 0x43018
    RRE_ERR_PPA_H = 0x4301c
    RRE_ERR_CNT = 0x43050

    ERS_FAIL_MASK_L = 0x4d3e0
    ERS_FAIL_MASK_H = 0x4d3e4
    ERS_FAIL_SPPA_L = 0x4d3e8
    ERS_FAIL_SPPA_H = 0x4d3ec
    ERS_FAIL_CNT_LIMIT = 0x4d3f0



    PPA_BITS = 38
    PPA_MASK = (1 << PPA_BITS) - 1

    class PPAF(Union):
        class BITS(Structure):
            _pack_ = 1
            _fields_ = [
                ('CH', c_uint32, 4),
                ('EP', c_uint32, 4),
                ('PL', c_uint32, 4),
                ('LN', c_uint32, 4),
                ('PG', c_uint32, 4),
                ('BL', c_uint32, 5),
            ]

        _anonymous_ = ('BITS',)
        _fields_ = [
            ('VALUE', c_uint32),
            ('BITS', BITS),
        ]

    def __init__(self, channel=16, mode='fw', nvme=None):
        super().__init__(channel, mode)

        self.nvme = nvme if nvme else Tahoe()

    @staticmethod
    def _get_quad(channel):
        return channel % 4

    @staticmethod
    def _generate_ppa(ppaf):
        bits = [getattr(ppaf, field) for field in ['BL', 'PG', 'LN', 'PL', 'EP', 'CH']]
        assert 0 < sum(bits) <= ErrorTahoe.PPA_BITS, 'Invalid PPAF: {:#x}'.format(ppaf)

        class PPA(Union):
            class BITS(Structure):
                _pack_ = 1
                _fields_ = [
                    ('CH', c_uint64, ppaf.CH),
                    ('EP', c_uint64, ppaf.EP),
                    ('PL', c_uint64, ppaf.PL),
                    ('LN', c_uint64, ppaf.LN),
                    ('PG', c_uint64, ppaf.PG),
                    ('BL', c_uint64, ppaf.BL),
                ]

            class QWORD(Structure):
                _pack_ = 1
                _fields_ = [
                    ('VALUE', c_uint64, sum(bits)),
                ]

            class DWORD(Structure):
                _pack_ = 1
                _fields_ = [
                    ('LOW', c_uint32),
                    ('HIGH', c_uint32),
                ]

            _anonymous_ = ('BITS', 'QWORD', 'DWORD')
            _fields_ = [
                ('BITS', BITS),
                ('QWORD', QWORD),
                ('DWORD', DWORD),
            ]

        return PPA

    def disable_wfb_upt_badb(self):
        pass

    def enable_wfb_upt_badb(self):
        pass

    def inject_uecc_status(self, ppa, mask=0xffffffffffffffff, group=0, cnt=15):
        assert group in (0, 1), 'Invalid group: {}'.format(group)

        ppa = self._get_ppa(ppa)
        mask = self._get_ppa(mask ^ ErrorTahoe.PPA_MASK)
        quad = self._get_quad(ppa.CH)
        LOG.info("Inject UECC Status, QUAD: 0x%x, GROUP: 0x%x, PPA: 0x%x, MASK: 0x%x, COUNT: 0x%x", quad, group,
                 ppa.VALUE, mask.VALUE, cnt)

        reg_en = self.STATUS_ERR_EN + 0x1000 * quad
        reg_mask_l = self.STATUS_MASK_L + 0x1000 * quad + 0x10 * group
        reg_mask_h = self.STATUS_MASK_H + 0x1000 * quad + 0x10 * group
        reg_ppa_l = self.STATUS_PPA_L + 0x1000 * quad + 0x10 * group
        reg_ppa_h = self.STATUS_PPA_H + 0x1000 * quad + 0x10 * group

        self._write(reg_mask_l, mask.LOW)
        self._write(reg_mask_h, mask.HIGH)
        self._write(reg_ppa_l, ppa.LOW)
        self._write(reg_ppa_h, ppa.HIGH)
        self._write(reg_en, self._read(reg_en) | (1 << group) | ((cnt & 0xF) << (8 + 4 * group)))

    def inject_uecc_status_fields(self, group=0, cnt=15, **kwargs):
        ppa = self._calc_ppa(**kwargs)
        mask = self._calc_mask(kwargs.keys())
        self.inject_uecc_status(ppa.VALUE, mask.VALUE, group=group, cnt=cnt)

    def inject_uecc_status_fields_random(self, group=0, cnt=15, mask=('ch', 'pl', 'ln', 'pg')):
        ppa = self._get_random_ppa()
        mask = self._calc_mask(mask)
        self.inject_uecc_status(ppa.VALUE, mask.VALUE, group=group, cnt=random.randint(1, cnt))

    def disable_uecc_status(self):
        LOG.info('Disable UECC Status Error')
        for quad in range(self._quad):
            self._write(self.STATUS_ERR_EN + 0x1000 * quad, 0)

    def inject_uecc_data(self, ppa, mask=0xffffffffffffffff, start=0, end=1024, loc=0x1, cnt=0xffffffff):
        ppa = self._get_ppa(ppa)
        mask = self._get_ppa(mask)
        quad = self._get_quad(ppa.CH)
        LOG.info("Inject UECC Data Error, QUAD: 0x%x, PPA: 0x%x, MASK: 0x%x, COUNT: 0x%x, START: 0x%x, END: 0x%x, "
                 "LOCATION: 0x%x", quad, ppa.VALUE, mask.VALUE, cnt, start, end, loc)

        self._write(self.DATA_ERR_MASK_L + 0x1000 * quad, mask.LOW)
        self._write(self.DATA_ERR_MASK_H + 0x1000 * quad, mask.HIGH)
        self._write(self.DATA_ERR_PPA_L + 0x1000 * quad, ppa.LOW)
        self._write(self.DATA_ERR_PPA_H + 0x1000 * quad, ppa.HIGH)
        self._write(self.DATA_ERR_CNT + 0x1000 * quad, (start & 0xFFF) + ((end & 0xFFF) << 12) + ((loc & 0x1F) << 24))
        self._write(self.DATA_ERR_CNT_LIMIT + 0x1000 * quad, cnt)

    def inject_uecc_data_fields(self, start=0, end=1024, loc=0x0, cnt=0xffffffff, **kwargs):
        ppa = self._calc_ppa(**kwargs)
        mask = self._calc_mask(kwargs.keys())
        self.inject_uecc_data(ppa.VALUE, mask.VALUE, start=start, end=end, loc=loc, cnt=cnt)

    def inject_uecc_data_fields_random(self, cnt_min=0, cnt_max=200, mask=('ch', 'pl', 'ln', 'pg')):
        ppa = self._get_random_ppa()
        mask = self._calc_mask(mask)
        self.inject_uecc_data(ppa.VALUE, mask.VALUE, cnt=random.randint(cnt_min, cnt_max))

    def disable_uecc_data(self):
        LOG.info('Disable UECC Data Error')
        for quad in range(self._quad):
            self._write(self.DATA_ERR_CNT_LIMIT + 0x1000 * quad, 0)

    def inject_prog_error(self, ppa, mask, cnt=0xffffffff): # pylint: disable=arguments-differ
        mask = self._get_ppa(mask)
        ppa = self._get_ppa(ppa)
        LOG.info("Inject Program Error, PPA: 0x%x, MASK: 0x%x, COUNT: 0x%x", ppa.VALUE, mask.VALUE, cnt)

        self._write(self.PROG_ERR_PPA_L, ppa.LOW)
        self._write(self.PROG_ERR_PPA_H, ppa.HIGH)
        self._write(self.PROG_ERR_MASK_L, mask.LOW)
        self._write(self.PROG_ERR_MASK_H, mask.HIGH)
        self._write(self.PROG_ERR_CNT_LIMIT, cnt)

    def inject_prog_error_fields(self, cnt=0xffffffff, **kwargs):
        ppa = self._calc_ppa(**kwargs)
        mask = self._calc_mask(kwargs.keys())
        self.inject_prog_error(ppa.VALUE, mask.VALUE, cnt=cnt)

    def inject_prog_error_fields_random(self, cnt=0xffffffff, mask=('ch', 'pl', 'ln', 'pg')):
        ppa = self._get_random_ppa(min_pg=self.max_pg - 12)
        mask = self._calc_mask(mask)
        self.inject_prog_error(ppa.VALUE, mask.VALUE, cnt=cnt)

    def disable_prog_error(self):
        LOG.info('Disable Program Error')
        self._write(self.PROG_ERR_CNT_LIMIT, 0)

    def inject_ers_fail(self, ppa, mask, cnt=0xffffffff):
        mask = self._get_ppa(mask)
        ppa = self._get_ppa(ppa)
        LOG.info("Inject  Ers fail Error, PPA: 0x%x, MASK: 0x%x, COUNT: 0x%x", ppa.VALUE, mask.VALUE, cnt)

        self._write(self.ERS_FAIL_SPPA_L, ppa.LOW)
        self._write(self.ERS_FAIL_SPPA_H, ppa.HIGH)
        self._write(self.ERS_FAIL_MASK_L, mask.LOW)
        self._write(self.ERS_FAIL_MASK_H, mask.HIGH)
        self._write(self.ERS_FAIL_CNT_LIMIT, cnt)

    def inject_ers_fail_fields(self, cnt=0xffffffff, **kwargs):
        ppa = self._calc_ppa(**kwargs)
        mask = self._calc_mask(kwargs.keys())
        self.inject_ers_fail(ppa.VALUE, mask.VALUE, cnt=cnt)

    def inject_ers_fail_fields_random(self, cnt=0xffffffff, mask=('ch', 'pl', 'ln', 'pg')):
        ppa = self._get_random_ppa(min_pg=self.max_pg - 12)
        mask = self._calc_mask(mask)
        self.inject_ers_fail(ppa.VALUE, mask.VALUE, cnt=cnt)

    def disable_ers_fail(self):
        LOG.info('Disable Ers fail Error')
        self._write(self.ERS_FAIL_CNT_LIMIT, 0)

    def inject_crc_error(self, ppa, mask, cnt=0xffffffff, err_code=0xd6):
        ppa = self._get_ppa(ppa)
        mask = self._get_ppa(mask)
        LOG.info("Inject CRC Error, PPA: 0x%x, MASK: 0x%x, COUNT: 0x%x, CODE: 0x%x", ppa.VALUE, mask.VALUE, cnt,
                 err_code)
        self._write(self.RRE_ERR_CODE, err_code)
        self._write(self.RRE_ERR_PPA_L, ppa.LOW)
        self._write(self.RRE_ERR_PPA_H, ppa.HIGH)
        self._write(self.RRE_ERR_MASK_L, mask.LOW)
        self._write(self.RRE_ERR_MASK_H, mask.HIGH)
        self._write(self.RRE_ERR_CNT, cnt)

    def inject_crc_error_fields(self, cnt=0xffffffff, err_code=0xd6, **kwargs):
        ppa = self._calc_ppa(**kwargs)
        mask = self._calc_mask(kwargs.keys())
        self.inject_crc_error(ppa.VALUE, mask.VALUE, cnt=cnt, err_code=err_code)

    def inject_crc_error_fields_random(self, cnt_min=1, cnt_max=13, mask=('ch', 'pl', 'ln', 'pg')):
        ppa = self._get_random_ppa()
        mask = self._calc_mask(mask)
        self.inject_crc_error(ppa.VALUE, mask.VALUE, cnt=random.randint(cnt_min, cnt_max))

    def disable_crc_error(self):
        LOG.info('Disable CRC Error')
        self._write(self.RRE_ERR_CNT, 0)

    def get_two_ppa_in_raidline(self, lba):
        ppa_1, _ = self.nvme.vu_cmd.get_ppa_from_lba(lba=lba)
        _, ppa_list = self.nvme.vu_cmd.get_valid_ppa_in_raidline(ppa_1)
        for ppa_2 in ppa_list:
            if ppa_2 % 4 != ppa_1 % 4:
                return ppa_1, ppa_2
        raise AssertionError('Cannot find two PPA in raidline!')
