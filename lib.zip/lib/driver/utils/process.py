# coding=utf-8
# pylint: disable=dangerous-default-value
import logging
import platform
import re
import subprocess
import time
import traceback
from multiprocessing import Process, Pipe

LOG = logging.getLogger()


class TestProcess(Process):
    def __init__(self, *args, **kwargs):
        Process.__init__(self, *args, **kwargs)
        self._pconn, self._cconn = Pipe()
        self._exception = None

    def run(self):
        try:
            Process.run(self)
            self._cconn.send((0, 'Process run pass'))
        except Exception as exp:
            tb = traceback.format_exc()
            self._cconn.send((1, exp, tb))

    @property
    def exception(self):
        if self._pconn.poll():  # .poll(): return whether there is any data avaliable to read
            self._exception = self._pconn.recv()
            # print(self._exception)
            return self._exception
        return None


class ProcessPool:
    def __init__(self):
        self.pool = []
        self.ret = None

    def add(self, func, args=[]):
        self.pool.append(TestProcess(target=func, args=args))

    def start(self):
        for proc in self.pool:
            proc.start()

    def terminate(self):
        for proc in self.pool:
            proc.terminate()
            proc.join()

    def wait(self):
        while (self.pool):
            for idx, proc in enumerate(self.pool):
                ret = proc.exception
                time.sleep(1)
                if ret:
                    if ret[0]:
                        self.ret = ret
                        return
                    proc.terminate()
                    proc.join()
                    self.pool.pop(idx)
        self.ret = ret

    def run(self):
        self.start()
        self.wait()
        self.terminate()

    @property
    def result(self):
        return self.ret


class MyProcess(Process):

    def stop(self):
        LOG.info("MyProcess . stop")
        if "windows" in platform.system().lower():
            LOG.info("system is windows")
            ret = self._kill_process_windows()
        else:
            LOG.info("system is linux")
            self._kill_process_linux()
            ret = 0
        return ret

    def get_subproecess(self, parent_pid, pid_information):
        sub_pids = re.findall("\s+([0-9]+)\s+{}".format(parent_pid), pid_information.decode('utf-8'))
        if sub_pids:
            for pid_ in sub_pids:
                pids_ = self.get_subproecess(pid_, pid_information)
                for item in pids_:
                    if item not in sub_pids:
                        sub_pids.append(item)
        return sub_pids

    def _kill_process_linux(self):
        cmd = "ps -ef"
        with subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE) as child2:
            out = child2.communicate()
        sub_process_ids = self.get_subproecess(self.pid, out[0])
        sub_process_ids.append(self.pid)
        LOG.info(sub_process_ids)
        for id_ in sub_process_ids:
            subprocess.call("pkill -9 -P {}".format(id_), shell=True)
            time.sleep(1)

    def _kill_process_windows(self):
        cmd = "taskkill  /F /T /PID {}".format(self.pid)
        ret = subprocess.call(cmd, shell=True)
        return ret
