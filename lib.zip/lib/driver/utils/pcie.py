#!/usr/bin/env python
"""
Created on 2019/12/20

@author: yyang
"""
import mmap
import os
import re


class PCIe:
    def __init__(self, device='/dev/nvme0', bid=0):
        self._bar_fd = None
        self._cfg_fd = None
        self._mmap = None
        self._bdf = None
        self._bid = bid
        self._device = device

    def __del__(self):
        if self._mmap:
            self._mmap.close()
            self._mmap = None

        if self._bar_fd:
            self._bar_fd.close()
            self._bar_fd = None

        if self._cfg_fd:
            self._cfg_fd.close()
            self._cfg_fd = None

    def close(self):
        self.__del__()

    @property
    def bdf(self):
        if not self._bdf:
            device = re.findall(r'(nvme\d+)', self._device)[0]
            uevent = f'/sys/class/nvme/{device}/device/uevent'
            with open(uevent, encoding='utf-8') as fd:
                self._bdf = re.findall(r'PCI_SLOT_NAME=(.*?)\n', fd.read())[0]
        return self._bdf

    @property
    def mmap(self):
        if not self._mmap:
            filename = f'/sys/bus/pci/devices/{self.bdf}/resource{self._bid}'
            assert os.path.exists(filename), f'Cannot find filename: {filename}'

            self._bar_fd = open(filename, 'wb+')    # pylint: disable=consider-using-with
            assert self._bar_fd, f'Cannot open filename: {filename}'

            self._mmap = mmap.mmap(self._bar_fd.fileno(), 0x0)

        return self._mmap

    @property
    def config(self):
        if not self._cfg_fd:
            filename = f'/sys/bus/pci/devices/{self.bdf}/config'
            self._cfg_fd = open(filename, 'wb+')    # pylint: disable=consider-using-with

        return self._cfg_fd

    def flush(self, offset):
        offset = (offset // 4096) * 4096
        self.mmap.flush(offset, 4096)

    def read_config(self, offset, size=1):
        self.config.seek(offset)
        return int.from_bytes(self.config.read(size), byteorder='little', signed=False)

    def write_config(self, offset, value, size=1):
        self.config.seek(offset)
        return self.config.write(value.to_bytes(length=size, byteorder='little', signed=False))

    def read_bar(self, offset, size=1):
        self.mmap.seek(offset)
        return int.from_bytes(self.mmap.read(size), byteorder='little', signed=False)

    def write_bar(self, offset, value, size=1):
        self.mmap.seek(offset)
        return self.mmap.write(value.to_bytes(length=size, byteorder='little', signed=False))

    def uint8(self, offset):
        return self.read_bar(offset, size=1)

    def uint32(self, offset):
        return self.read_bar(offset, size=4)

    def read_bar_uint8(self, offset):
        return self.read_bar(offset, size=1)

    def read_bar_uint32(self, offset):
        return self.read_bar(offset, size=4)

    def write_bar_uint8(self, offset, value):
        self.write_bar(offset, value, size=1)

    def write_bar_uint32(self, offset, value):
        self.write_bar(offset, value, size=4)
