#!/usr/bin/env python
"""
This is SSH commands

@author: Yingjun Yang
"""
import binascii
import logging
import os
import socket
import time

import paramiko

LOG = logging.getLogger()
DUMP = logging.getLogger('dump')
logging.getLogger("paramiko").setLevel(logging.WARN)


class SSH:
    def __init__(self, hostname, port=22, username='root', password='nvme', mode='rdma'):
        self._hostname = hostname
        self._port = port
        self._mac = None
        self._username = username
        self._password = password
        self._mode = mode

        self._ssh = paramiko.SSHClient()
        self._ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        self._platform = None
        self._uptime = None
        self._lib_path = '/tmp'
        self._lib_name = 'lib.py'
        self._device = '/dev/nvme'

    @property
    def _local_time(self):
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))

    @property
    def platform(self):
        return self._platform

    @property
    def uptime(self):
        return self._uptime

    @property
    def mac(self):
        return self._mac

    def _get_mac(self):
        cmd = 'python -c "' \
              'import re, uuid; ' \
              'print(\'-\'.join(re.findall(r\'.{2}\', uuid.uuid1().hex[-12:].upper())))"'
        status, output = self.command(cmd, cmdline=False, console=False, timeout=3)
        if status:
            DUMP.info(output)
            raise RuntimeError('Get MAC address failed!!')

        return output.strip()

    def open(self, timeout=30, interval=3, cmdline=True):
        """
        Open ssh connection
        :param timeout:  timeout (in seconds) for open
        :param interval: timeout (in seconds) for ssh connect
        :return:
        """
        LOG.info("Connecting %s:%d", self._hostname, self._port)

        tm_bgn = time.time()
        while True:
            try:
                self._ssh.connect(self._hostname,
                                  port=self._port,
                                  username=self._username,
                                  password=self._password,
                                  timeout=interval)
                break
            except KeyboardInterrupt:
                LOG.warning('Key Board Interrupt')
                raise
            except Exception:
                pass

            if time.time() - tm_bgn >= timeout:
                raise RuntimeError("Connect {}:{} timeout({}s)".format(self._hostname, self._port, timeout))

        if cmdline:
            self._platform = self._get_platform()
            self._uptime = self._get_uptime()
            self._mac = self._get_mac()

    def close(self):
        self._ssh.close()

    def __del__(self):
        self.close()

    def _get_platform(self):
        """
        Get platform of remote PC
        :return:
        """
        status, output = self.command(
            'python -c "import platform; print(platform.platform())"', cmdline=False, console=False, timeout=3)
        if status:
            DUMP.info(output)
            raise RuntimeError("Get platform of remote system failed!")

        platform = output.strip()
        LOG.info(platform)
        return platform

    def _get_uptime(self):
        """
        Get boot time of remote PC
        :return:
        """
        status, output = self.command(
            'python -c "import psutil; print(psutil.boot_time())"', cmdline=False, console=False, timeout=3)
        if status:
            DUMP.info(output)
            raise RuntimeError('Get uptime of remote system failed!')

        # LOG.info(datetime.datetime.fromtimestamp(uptime).strftime("%Y-%m-%d %H:%M:%S"))
        LOG.info('Up time: %.1fs', time.time() - float(output))
        return float(output)

    def is_active(self):
        """
        Check the connection of SSH is active or not
        :return:
        """
        try:
            self._ssh.exec_command('pwd', timeout=3)
        except BaseException:
            return False
        return True

    def wait_disconnect(self, time_out=600):
        start_time = time.time()
        duration = 0
        while duration < time_out:
            LOG.info("Waiting for target computer to be disconnected: time %s", duration)
            try:
                self.open(timeout=3, cmdline=False)
            except Exception as err:
                LOG.info(f"target computer has been disconnected: {err}")
                return True
            time.sleep(5)
            duration = time.time() - start_time
        return False

    def sftp_put(self, filename, filepath):
        """
        SFTP put file to remote path
        :param filename:
        :param filepath:
        :return:
        """
        sftp = self._ssh.open_sftp()
        sftp.put(filename, filepath)
        sftp.close()

    def is_exist(self, path):
        sftp = self._ssh.open_sftp()
        try:
            sftp.stat(path)
            sftp.close()
            return True
        except IOError:
            sftp.close()
            return False

    def make_dir(self, path):
        sftp = self._ssh.open_sftp()
        sftp.mkdir(path)
        sftp.close()

    def remove_dir(self, path):
        sftp = self._ssh.open_sftp()
        sftp.rmdir(path)
        sftp.close()

    def __get_all_files_in_local_dir(self, local_dir):
        all_files = list()
        files = os.listdir(local_dir)
        for file_name in files:
            file_ = os.path.join(local_dir, file_name)
            if os.path.isdir(file_):
                if file_ not in [os.path.join(local_dir, ".git"), os.path.join(local_dir, ".idea")]:
                    all_files.append((file_, "folder"))
                    all_files.extend(self.__get_all_files_in_local_dir(file_))
            else:
                all_files.append((file_, "file"))
        return all_files

    def sftp_put_dir(self, local_dir, remote_dir):
        sftp = self._ssh.open_sftp()
        all_files = self.__get_all_files_in_local_dir(local_dir)
        for item in all_files:
            rel_path = os.path.relpath(item[0], local_dir)
            remote_path = os.path.join(remote_dir, rel_path)
            remote_path = remote_path.replace("\\", "/")
            if item[1] == "file":
                sftp.put(item[0], remote_path)
            else:
                sftp.mkdir(remote_path)
        sftp.close()

    def execute(self, cmd, cmdline=True, timeout=None):
        """
        Execute command without waiting result
        :param cmd:     the command
        :param cmdline: print the command
        :param timeout: an optional timeout (in seconds) for the command
        :return:
        """
        if cmdline:
            LOG.info(cmd)

        if not self.is_active():
            self.open()
            LOG.info("try to open ssh, status now: %s", self.is_active())

        self._ssh.exec_command(cmd, timeout=timeout)

    def command(self, cmd, cmdline=True, timeout=None, console=True):
        """
        Run command through ssh
        :param cmd:     the command
        :param cmdline: print the command
        :param timeout: an optional timeout (in seconds) for the command
        :param console: output to console
        :return:
        """
        if cmdline:
            LOG.info(cmd)
        if not self.is_active():
            self.open()
            LOG.info("try to open ssh, status now: %s", self.is_active())
        _, stdout, stderr = self._ssh.exec_command(cmd, timeout=timeout)
        output = str()
        for std in [stdout, stderr]:
            while True:
                line = std.readline()
                if not line:
                    break
                output += line
                if console:
                    DUMP.info(line.strip('\n'))
        status = stdout.channel.recv_exit_status()
        output += stderr.read().decode('utf-8')
        return status, output

    def command_without_result(self, cmd, cmdline=True, timeout=None):
        if cmdline:
            LOG.info(cmd)
        if not self.is_active():
            self.open()
            LOG.info("try to open ssh, status now: %s", self.is_active())
        self._ssh.exec_command(cmd, timeout=timeout)

    def list_disk(self):
        """
        List disk of remote PC
        :return:
        """
        status, output = self.command(
            'python -c "import psutil; print(psutil.disk_io_counters(perdisk=True))"',
            cmdline=False, console=False)
        if status:
            DUMP.info(output)
            raise RuntimeError('List disk failed, status: {:#x}'.format(status))
        return output

    def reboot(self, overtime=30, option=''):
        """
        Reboot controlled computer
        :param overtime: overtime (in seconds) for reboot
        :param option:   option for reboot
        :return:
        """
        cmd = "reboot" if 'Linux' in self.platform else 'shutdown -r -t 1'
        if option:
            cmd = '{} {}'.format(cmd, option)

        self.execute(cmd, cmdline=True)
        self.close()
        time.sleep(overtime)

    def shutdown(self, overtime=30, option='', rmmod=True):
        """
        Shutdown controlled computer
        :param overtime: overtime (in seconds) for shutdown
        :param option:   option for shutdown
        :param rmmod:   rmmod nvme before power off
        :return:
        """
        if 'Linux' in self.platform:
            if rmmod:
                cmd = 'rmmod nvme'
                status, output = self.command(cmd, cmdline=True)
                assert status == 0, '{} failed!\nStatus: {:#x}\n{}'.format(cmd, status, output)

            cmd = "poweroff"
        else:
            cmd = 'shutdown -s -t 1'

        if option:
            cmd = '{} {}'.format(cmd, option)

        self.execute(cmd, cmdline=True)
        self.close()
        time.sleep(overtime)

    def send_wol(self, count=3):
        """
        Send WOL package to wake up remote PC
        :param count: Retry counts
        :return:
        """
        LOG.info('Send WOL to: %s', self.mac)
        mac = self.mac.replace(self.mac[2], '')
        data = b'FF' * 6 + (mac * 16).encode()

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        for _ in range(count):
            sock.sendto(binascii.unhexlify(data), ('255.255.255.255', 9))
            time.sleep(1)

    def send_lib(self):
        assert 'Linux' in self._platform, 'Not support system: {}'.format(self._platform)

        filename = os.path.join('lib', 'driver', 'utils', self._lib_name)
        assert os.path.exists(filename), 'Cannot find the lib file: {}'.format(filename)

        self.sftp_put(filename, '{}/{}'.format(self._lib_path, self._lib_name))

    def pfail(self, overtime=15):
        """
        Do pfail with write register
        :param overtime: overtime (in seconds) waiting pfail
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        reg_pfail = 0x4213c
        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import NVMe; ' \
              'NVME = NVMe(); ' \
              'NVME.rdma_write({:#x}, 0)"'.format(self._lib_path, reg_pfail)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Trigger pfail failed!')
        time.sleep(overtime)

    def usb_relay_press(self, interval=8.0):
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import UsbRelay; ' \
              'usb = UsbRelay(); ' \
              'usb.press({})"'.format(self._lib_path, interval)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise AssertionError('Usb Relay Press Failed!')

    def inject_uecc_status(self, ppa, mask):
        """
        Inject UECC to remote PC
        :param ppa:
        :param mask:
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.inject_uecc_status({:#x}, {:#x})"'.format(self._lib_path, self._mode, ppa, mask)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Inject UECC error!')

    def inject_uecc_fw_enable(self):
        """
        Inject UECC by fw enabled to remote PC
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.fw_inject_uecc()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Inject UECC fields random failed!')

    def inject_uecc_fw_disable(self):
        """
        Inject UECC by fw disabled to remote PC
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.fw_disable_uecc()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Inject UECC fields random failed!')

    def inject_uecc_status_fields_random(self):
        """
        Inject UECC fields random to remote PC
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.inject_uecc_status_fields_random()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Inject UECC fields random failed!')

    def disable_uecc_status(self):
        """
        Disable UECC register of remote PC
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.disable_uecc_status()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Disable UECC failed!')

    def inject_prog_error_to_page(self):
        """
        Inject program error to remote PC
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.inject_prog_error_to_page()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Inject Program Error failed!')

    def disable_prog_error(self):
        """
        Disable Program Error register of remote PC
        :return:
        """
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.disable_prog_error()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Disable Program Error failed!')

    def enable_wfb_upt_badb(self):
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.enable_wfb_upt_badb()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Enable WFB update badb failed!')

    def disable_wfb_upt_badb(self):
        if "Linux" not in self.platform:
            raise RuntimeError('Target OS({}) is not support'.format(self.platform))

        cmd = 'python -c "' \
              'import sys; ' \
              'sys.path.append(\'{}\'); ' \
              'from lib import Error; ' \
              'err = Error(mode=\'{}\'); ' \
              'err.disable_wfb_upt_badb()"'.format(self._lib_path, self._mode)

        status, output = self.command(cmd, cmdline=True)
        if status:
            DUMP.info(output)
            raise RuntimeError('Disable WFB update bad failed!')
