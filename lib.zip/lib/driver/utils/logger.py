#!/usr/bin/env python
# pylint: disable=invalid-name
"""
Created on 2021/01/12

@author: Yingjun Yang
"""
import logging.handlers
import os
import re
import sys
import datetime
import socket
import platform
from multiprocessing import Process

import psutil

class Logging:

    def __init__(self, filename=None, log_path='', console_level='INFO', logfile_level='DEBUG'):
        self.__log_name = None
        self.__log_path = None
        self.__log_file = None
        self.__dmesg_file = None
        self.__dmesg = None
        self.__date = self.current_date

        root_formatter = logging.Formatter(
            '[%(asctime)s.%(msecs)03d] [%(filename)s][%(funcName)s][Line:%(lineno)s]: %(message)s',
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        dump_formatter = logging.Formatter('%(message)s')
        dmesg_formatter = logging.Formatter('%(message)s')

        self.__log_path = os.path.join(os.getcwd(), 'log', log_path, self.get_ip_address())
        os.makedirs(self.__log_path, exist_ok=True)

        if filename is not None:
            name = re.sub(r'\.py:|[:\.]', '_', filename)
            self.__log_name = f'{self.__date}_{name}'
            self.__log_file = os.path.join(self.__log_path, f'{self.__log_name}.log')
            self.__dmesg_file = os.path.join(self.__log_path, f'{self.__date}_dmesg.log')

        for name in (None, 'dump', 'dmesg'):
            logger = logging.getLogger(name)
            while logger.handlers:
                logger.handlers.pop()

        dmesg = logging.getLogger('dmesg')
        dmesg.setLevel(logging.DEBUG)
        dmesg.propagate = False
        if platform.system() == "Linux" and self.__dmesg_file:
            self.logfile_setup(dmesg, self.__dmesg_file, logfile_level, dmesg_formatter)
            self.__dmesg = Process(target=self.dmesg_collect)
            self.__dmesg.daemon = True
            self.__dmesg.start()

        root = logging.getLogger()
        root.setLevel(logging.DEBUG)
        root.propagate = False
        self.console_setup(root, console_level, root_formatter)
        self.logfile_setup(root, self.__log_file, logfile_level, root_formatter)

        dump = logging.getLogger('dump')
        dump.setLevel(logging.DEBUG)
        dump.propagate = False
        self.console_setup(dump, console_level, dump_formatter)
        self.logfile_setup(dump, self.__log_file, logfile_level, dump_formatter)

    def close(self):
        if self.__dmesg and self.__dmesg.is_alive():
            parent = psutil.Process(self.__dmesg.pid)
            for proc in parent.children(recursive=True) + [parent]:
                try:
                    proc.terminate()
                except BaseException:
                    pass

        for name in (None, 'dump'):
            logger = logging.getLogger(name)
            while logger.handlers:
                logger.handlers.pop()

    @property
    def log_path(self):
        return self.__log_path

    @property
    def log_file(self):
        return self.__log_file

    @property
    def current_date(self):
        return datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")[:-3]

    @staticmethod
    def console_setup(logger, level, formatter):
        console = logging.StreamHandler(sys.stdout)
        console.setFormatter(formatter)
        console.setLevel(level)
        logger.addHandler(console)
        console.close()

    @staticmethod
    def logfile_setup(logger, filename, level, formatter, max_bytes=100 * 1024 * 1024):
        if filename is not None:
            logfile = logging.handlers.RotatingFileHandler(filename=filename, maxBytes=max_bytes)
            logfile.setFormatter(formatter)
            logfile.setLevel(level)
            logger.addHandler(logfile)
            logfile.close()

    @staticmethod
    def get_ip_address():
        name = ''
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect(('8.8.8.8', 80))
            name = sock.getsockname()[0]
        finally:
            sock.close()
        return name

    def dmesg_collect(self):
        try:
            dmesg = logging.getLogger('dmesg')
            for line in os.popen('dmesg -wT'):
                dmesg.info(line.strip())
        except BaseException:
            pass
