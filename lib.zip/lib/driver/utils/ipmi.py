#!/usr/bin/env python

# !/usr/bin/env python
"""
This is IPMI commands

@author: Yingjun Yang
"""
import os
import re
import time
import logging

from nose.tools import assert_equal
from lib.driver.utils.system import execute
from lib.driver.nvme import NVMe
from lib.driver.utils import system

LOG = logging.getLogger()


class IPMI:
    def __init__(self, hostname, username='ADMIN', password='ADMIN'):
        self._hostname = hostname
        self._username = username
        self._password = password
        self.nvme = NVMe()

        # self._cmd = 'ipmitool -H {} -U {} -P {} -I lanplus -L ADMINISTRATOR'.format(hostname, username, password)
        self._cmd = 'ipmitool'

    @property
    def _local_time(self):
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))

    def execute(self, cmd):
        _, output = execute('{} {}'.format(self._cmd, cmd))
        return output

    def power_status(self):
        output = self.execute('power status')
        if 'off' in output:
            return False
        return True

    @staticmethod
    def check_device_status(dev_count=1):
        _, output = system.execute('nvme list')
        ret = re.compile("nvme\d+[c\d]*n\d+").findall(output)
        assert_equal(len(ret), dev_count, 'Have Device Lost!!')
        return ret

    @staticmethod
    def is_before_reboot():
        LOG.info('Enter in  IPMIPowerCycle, is_before_reboot: %s', time.strftime("%Y-%m-%d %H:%M:%S"))
        if "before_reboot" in os.environ:
            value = os.environ["before_reboot"]
            before_reboot = bool(value == "true")
        else:
            before_reboot = False
        return before_reboot

    def remove_all_drive(self, delay=0):
        LOG.info(f'RemoveAllDrive:  {time.strftime("%Y-%m-%d %H:%M:%S")}')
        for device in self.nvme.devices:
            cmd = f'echo 1 > /sys/bus/pci/devices/{device["slot"]}/remove'
            LOG.info("%s", cmd)
            time.sleep(delay)

    def power_cycle_chassis(self):
        cmd = 'chassis power cycle'
        output = self.execute(cmd)
        return output

    def power_off_with_reset(self, slot=0xff):
        LOG.info(f'IPMI POWER_OFF: {time.strftime("%Y-%m-%d %H:%M:%S")}')
        cmd = f'raw 0x30 0xe0 {slot} 0x06 0x00 0x04 0x00'
        output = self.execute(cmd)
        return output

    def power_on_with_reset(self, slot=0xff):
        LOG.info(f'IPMI POWER_ON: {time.strftime("%Y-%m-%d %H:%M:%S")}')
        cmd = f'raw 0x30 0xe0 {slot} 0x06 0x00 0x02 0x00'
        output = self.execute(cmd)
        return output

    def power_off_without_reset(self, slot=0xff):
        LOG.info(f'IPMI POWER_OFF_WITHOUT_RESET: {time.strftime("%Y-%m-%d %H:%M:%S")}')
        cmd = f'raw 0x30 0xe0 {slot} 0x02 0x00 0x00 0x00'
        output = self.execute(cmd)
        return output

    def power_on_without_reset(self, slot=0xff):
        LOG.info(f'IPMI POWER_ON_WITHOUT_RESET: {time.strftime("%Y-%m-%d %H:%M:%S")}')
        cmd = f'raw 0x30 0xe0 {slot} 0x02 0x00 0x02 0x00'
        output = self.execute(cmd)
        return output

    def perst_reset(self, slot=0xff):
        LOG.info(f'IPMI PERST: {time.strftime("%Y-%m-%d %H:%M:%S")}')
        cmd = f'raw 0x30 0xe0 {slot} 0x04 0x00 0x04 0x00'
        output = self.execute(cmd)
        return output

    def power_cycle(self, crash_flg=False, delay=0):
        time.sleep(delay)
        if not crash_flg:
            self.remove_all_drive()

        self.power_off_with_reset()
        time.sleep(5)

        self.power_on_with_reset()
        time.sleep(30)

    def perst(self):
        self.perst_reset()
        time.sleep(5)
        self.power_on_with_reset()
        time.sleep(30)

    def power_cycle_without_reset(self, crash_flg=False, delay=0):
        time.sleep(delay)
        if not crash_flg:
            self.remove_all_drive()

        self.power_off_without_reset()
        time.sleep(5)

        self.power_on_without_reset()
        time.sleep(30)

    def execute_crash(self):
        self.power_off_with_reset()
        time.sleep(5)

        self.power_on_with_reset()
        time.sleep(30)
