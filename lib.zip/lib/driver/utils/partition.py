#!/usr/bin/env python
"""
This is python parted commands

Requirement:
pip install pexpect or yum install pexpect

@author: Yingjun Yang
"""
import logging
import os
import sys
import time

import pexpect

from lib.driver.utils.system import execute, get_disk_size

LOG = logging.getLogger()


class FileSystem:
    """
    Operation of file system
    """

    def __init__(self, disk, ptid=1, mnt="/mnt", logfile=False):
        if "win" in sys.platform:
            raise RuntimeError("FileSystem is not support windows!")

        self.mnt = mnt
        self.disk = disk
        self.ptid = ptid
        self.ptname = "{}p1".format(self.disk)
        self.logfile = logfile

    def __create(self):
        cmd = "parted {}".format(self.disk)
        LOG.info("# %s (__create)", cmd)
        module = pexpect.spawn(cmd)
        if self.logfile:
            module.logfile = sys.stdout
        module.expect("(parted)")
        module.sendline("mklabel gpt")
        if module.expect(["Yes/No", "(parted)"]) == 0:
            module.sendline("yes")
            module.expect("(parted)")
        module.sendline("mkpart primary 0% 100%")
        if module.expect(["Yes/No", "(parted)"]) == 0:
            module.sendline("yes")
            module.expect("(parted)")
        module.sendline("q")
        module.expect(pexpect.EOF)
        time.sleep(3)

    def __delete(self):
        cmd = "parted {}".format(self.disk)
        LOG.info("# %s (__delete)", cmd)
        module = pexpect.spawn(cmd)
        if self.logfile:
            module.logfile = sys.stdout
        module.expect("(parted)")
        module.sendline("rm 1")
        if module.expect(["Yes/No", "(parted)"]) == 0:
            module.sendline("yes")
            module.expect("(parted)")
        module.sendline("q")
        module.expect(pexpect.EOF)
        time.sleep(3)

    def create(self):
        """
        create partition
        """
        self.delete()
        self.__create()
        if not os.path.exists(self.ptname):
            raise RuntimeError("create {} failed!".format(self.ptname))

    def delete(self):
        """
        delete partition
        """
        cmd = "df | grep {}".format(self.ptname)
        status, _ = execute(cmd, cmdline=False, console=False, interrupt=False)
        if status == 0:
            execute("umount {}".format(self.ptname))

        if os.path.exists(self.ptname):
            self.__delete()
            if os.path.exists(self.ptname):
                raise RuntimeError("delete {} failed!".format(self.ptname))

    @staticmethod
    def is_fs_valid(file_s):
        """
        check the mkfs.xx is valid or not
        """
        return os.path.exists("/sbin/mkfs.{}".format(file_s))

    def get_disk_size(self, unit="G"):
        """
        get size of disk with "G" or "M" or "K" or "B"
        """
        return get_disk_size(self.disk, unit)

    def mkfs(self, file_s):
        """
        mkfs for partition
        """
        if not os.path.exists(self.ptname):
            raise RuntimeError("{} is not exists!".format(self.ptname))

        if file_s == "ntfs":
            cmd = "mkfs.{} --fast {}".format(file_s, self.ptname)
        else:
            cmd = "mkfs.{} {}".format(file_s, self.ptname)
        execute(cmd)

    def mount(self):
        """
        mount partition to mount point
        """
        if not os.path.exists(self.ptname):
            raise RuntimeError("{} is not exists!".format(self.ptname))

        if not os.path.exists(self.mnt):
            execute("mkdir -p {}".format(self.mnt))

        execute("mount {} {}".format(self.ptname, self.mnt))
