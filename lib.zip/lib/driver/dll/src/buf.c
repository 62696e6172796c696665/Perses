#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
// #include <hugetlbfs.h>
#include "buf.h"

void* nvme_alloc(unsigned int size){
    void *ptr;

    if (posix_memalign(&ptr, 4096, size)) {
        return 0;
    }
    memset(ptr, 0x0, size);

    return ptr;
}

// void* nvme_get_hugepage_region(unsigned int size){
//     void *ptr;

//     ptr = get_hugepage_region(size, GHR_DEFAULT);
//     if (ptr) {
//         memset(ptr, 0x0, size);
//     }

//     return ptr;
// }

// void nvme_free_hugepage_region(void *ptr){
//     free_hugepage_region(ptr);
// }

void nvme_copy(void *dst, void *src, unsigned int size){
    memcpy(dst, src, size);
}

void nvme_free(void *ptr) {
    free(ptr);
}

void fill_uint8_fix(unsigned char *buffer, unsigned int offset, unsigned int size, unsigned int value) {
    unsigned int i;
    for(i = 0; i < size; i++) {
        buffer[offset + i] = value;
    }
}

void fill_uint32_seq(unsigned int *buffer, unsigned int offset, unsigned int size, unsigned int value, unsigned int step) {
    unsigned int i;
    for(i = 0; i < size; i++) {
        buffer[offset + i] = value + i * step;
    }
}

void fill_uint32_fix(unsigned int *buffer, unsigned int offset, unsigned int size, unsigned int value) {
    unsigned int i;
    for(i = 0; i < size; i++) {
        buffer[offset + i] = value;
    }
}

void fill_uint32_rnd(unsigned int *buffer, unsigned int offset, unsigned int size, int seed) {
	unsigned int i;
	srand(seed);
	for(i = 0; i < size; i++) {
		buffer[offset + i] = rand();
	}
}

unsigned int compare_uint32_seq(unsigned int *buffer, unsigned int offset, unsigned int size, unsigned int value, unsigned int step) {
    unsigned int i;
    unsigned int count = 0;

    for(i = 0; i < size; i++) {
        if (buffer[offset + i] != value + i * step) {
            count += 1;
        }
    }
    return count;
}

unsigned int compare_uint32_fix(unsigned int *buffer, unsigned int offset, unsigned int size, unsigned int value) {
    unsigned int i;
    unsigned int count = 0;

    for(i = 0; i < size; i++) {
        if (buffer[offset + i] != value) {
            count += 1;
        }
    }
    return count;
}

unsigned int compare_uint32_rnd(unsigned int *buffer, unsigned int offset, unsigned int size, int seed) {
	unsigned int i;
	unsigned int count = 0;

	srand(seed);
	for(i = 0; i < size; i++) {
		if (buffer[offset + i] != rand()) {
		    count += 1;
		}
	}
    return count;
}

int look_idx_uint32(unsigned int *buffer, unsigned int size, unsigned int value) {
    unsigned int i;
    for(i = 0; i < size; i++) {
        if(buffer[i] == value) {
            return i;
        }
    }
    return -1;
}

int compare(u8 *src_addr, u8 *dst_addr, u64 src_start, u64 dst_start, u64 len){
    return memcmp(src_addr + src_start, dst_addr + dst_start, len);
}

//int compare(u8 *array1, u8 *array2, u64 src_start, u64 dst_start, u64 len){
//	if (NULL == array1 || NULL == array2)
//		return 0;
//	if (len == 0)
//		return 0;
//	u64 i;
//	u64 count = 0;
//	u8 table[256] =
//	    {
//	        0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4,
//	        1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
//	        1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
//	        2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
//	        1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
//	        2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
//	        2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
//	        3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
//	        1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
//	        2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
//	        2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
//	        3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
//	        2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6,
//	        3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
//	        3, 4, 4, 5, 4, 5, 5, 6, 4, 5, 5, 6, 5, 6, 6, 7,
//	        4, 5, 5, 6, 5, 6, 6, 7, 5, 6, 6, 7, 6, 7, 7, 8,
//	    };
//    for(i = 0; i < len; i++) {
//        count += table[array1[src_start + i] ^ array2[dst_start + i]];
//        }
//
//    return count;
//}
