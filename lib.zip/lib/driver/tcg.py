#!/usr/bin/env python
# pylint: disable=attribute-defined-outside-init,too-many-return-statements,dangerous-default-value,invalid-name
"""
Created on 2023/8/7

@author: Yingjun Yang
"""
import math
from ctypes import *
from lib.driver.testcase import TestCase
from lib.driver.utils.ctype import Ctype, Ascii

REQUEST_CODE_VERIFY_COMID_VALID = 0x1
REQUEST_CODE_STACK_RESET = 0x2

SMUID = b'\x00\x00\x00\x00\x00\x00\x00\xff'
ADMIN_SP_SPINFO_ADMIN_SPID = b'\x00\x00\x02\x05\x00\x00\x00\x01'
ADMIN_SP_C_PIN_SID = b'\x00\x00\x00\x0b\x00\x00\x00\x01'
ADMIN_SP_C_PIN_MSID = b'\x00\x00\x00\x0b\x00\x00\x84\x02'
ADMIN_SP_C_PIN_ADMIN1 = b'\x00\x00\x00\x0b\x00\x00\x02\x01'
ADMIN_SP_AUTHORITY_ANYBODY = b'\x00\x00\x00\x09\x00\x00\x00\x01'
ADMIN_SP_AUTHORITY_SID = b'\x00\x00\x00\x09\x00\x00\x00\x06'
ADMIN_SP_AUTHORITY_ADMIN1 = b'\x00\x00\x00\x09\x00\x00\x02\x01'
ADMIN_SP_ADMIN_UID = b'\x00\x00\x02\x05\x00\x00\x00\x01'
ADMIN_SP_LOCKING_UID = b'\x00\x00\x02\x05\x00\x00\x00\x02'

LOCKING_SP_SPINFO_ADMIN_SPID = b'\x00\x00\x02\x05\x00\x00\x00\x02'
LOCKING_SP_C_PIN_ADMIN1 = b'\x00\x00\x00\x0b\x00\x01\x00\x01'
LOCKING_SP_AUTHORITY_ADMIN1 = b'\x00\x00\x00\x09\x00\x01\x00\x01'

LOCKING_RANGE = b'\x00\x00\x08\x02\x00\x03\x00'
LOCKING_GLOBALRANGE = b'\x00\x00\x08\x02\x00\x00\x00\x01'

THIS_SP = b'\x00\x00\x00\x00\x00\x00\x00\x01'
REVERT_SP = b'\x00\x00\x00\x06\x00\x00\x00\x11'
REVERT = b'\x00\x00\x00\x06\x00\x00\x02\x02'

# Methods
GET = b'\x00\x00\x00\x06\x00\x00\x00\x16'
SET = b'\x00\x00\x00\x06\x00\x00\x00\x17'
ACTIVATE = b'\x00\x00\x00\x06\x00\x00\x02\x03'

# Session Manager Method UIDs
PROPERTIES = b'\x00\x00\x00\x00\x00\x00\xff\x01'
START_SESSION = b'\x00\x00\x00\x00\x00\x00\xff\x02'
SYNC_SESSION = b'\x00\x00\x00\x00\x00\x00\xff\x03'

# Life Cycle
LIFE_CYCLE_STATE = {
    'MANUFACTURED_INACTIVE': 8,
    'MANUFACTURED': 9,
}

BYTES_EMPTY = b''
BYTES_ZERO = b'\x00'
BYTES_ONE = b'\x01'
TOKEN_CALL = b'\xf8'    # Call
TOKEN_SL = b'\xf0'      # Start List
TOKEN_EL = b'\xf1'      # End List
TOKEN_SN = b'\xf2'      # Start Name
TOKEN_EN = b'\xf3'      # End Name
TOKEN_EOD = b'\xf9'     # End of Data
TOKEN_EOS = b'\xfa'     # End of Session

TINY_ATOM = 0x0
SHORT_ATOM = 0x2
MEDIUM_ATOM = 0x6
LONG_ATOM = 0xE

Properties = {
    'HostProperties': 0,
}

CellBlock = {
    'Table': 0,
    'startRow': 1,
    'endRow': 2,
    'startColumn': 3,
    'endColumn': 4,
}

Locking = {
    'RangeStart': 3,
    'RangeLength': 4,
    'ReadLockEnabled': 5,
    'WriteLockEnabled': 6,
    'ReadLocked': 7,
    'WriteLocked': 8,
    'LockOnReset': 9,
    'ActiveKey': 10,
    'NextKey': 11
}

StartSession = {
    'HostChallenge': 0,
    'HostExchangeAuthority': 1,
    'HostExchangeCert': 2,
    'HostSigningAuthority': 3,
    'HostSigningCert': 4,
    'SessionTimeout': 5,
    'TransTimeout': 6,
    'InitialCredit': 7,
    'SignedHash': 8,
}


class Atoms(Union):
    class TinyAtom(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('Tiny', c_uint8, 1),
            ('TinySign', c_uint8, 1),
            ('TinyData', c_uint8, 6),
        ]

    class ShortAtom(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('Short', c_uint8, 2),
            ('ShortByte', c_uint8, 1),
            ('ShortSign', c_uint8, 1),
            ('ShortLength', c_uint8, 4),
        ]

    class MediumAtom(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('Medium', c_uint16, 3),
            ('MediumByte', c_uint16, 1),
            ('MediumSign', c_uint16, 1),
            ('MediumLength', c_uint16, 11),
        ]

    class LongAtom(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('Long', c_uint32, 4),
            ('Reserved0', c_uint32, 2),
            ('LongByte', c_uint32, 1),
            ('LongSign', c_uint32, 1),
            ('LongLength', c_uint32, 24),
        ]

    class Bytes(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('Value', c_int8 * 4)
        ]

    _anonymous_ = ("Bytes", "TinyAtom", "ShortAtom", "MediumAtom", "LongAtom")
    _fields_ = [("TinyAtom", TinyAtom),
                ("ShortAtom", ShortAtom),
                ("MediumAtom", MediumAtom),
                ("LongAtom", LongAtom),
                ("Bytes", Bytes)
        ]


class ComPacket(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('Reserved0', c_uint32),
        ('ComID', c_uint16),
        ('ExtendedComID', c_uint16),
        ('OutstandingData', c_uint32),
        ('MinTransfer', c_uint32),
        ('Length', c_uint32),
    ]


class Packet(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('TperSession', c_uint32),
        ('HostSession', c_uint32),
        ('SeqNumber', c_uint32),
        ('Reserved0', c_uint16),
        ('AckType', c_uint16),
        ('Acknowledgement', c_uint32),
        ('Length', c_uint32),
    ]


class SubPacket(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('Kind', c_uint64, 16),
        ('Reserved0', c_uint64, 48),
        ('Length', c_uint32),
    ]


class AllocateComID(Union):
    class Bits(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('ComID', c_int16),
            ('ExtendedComID', c_int16),
        ]
        desc = {}

    class Bytes(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('Value', c_int32)
        ]

    _anonymous_ = ("Bytes", "Bits")
    _fields_ = [("Bits", Bits),
                ("Bytes", Bytes)
        ]


class Date(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('Year', c_int16),
        ('Month', c_int8),
        ('Day', c_int8),
        ('Hour', c_int8),
        ('Minute', c_int8),
        ('Second', c_int8),
        ('Fraction', c_int16),
        ('Reserved0', c_int8),
    ]


class VerifyComIDValid(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('ExtendedComID', c_int32),
        ('RequestCode', c_int32),
        ('Reserved0', c_int16),
        ('Length', c_int16),
        ('CurrentState', c_int32),
        ('TimeAllocationRelative', Date),
        ('TimeExpiryRelative', Date),
        ('Time', Date),
    ]


class StackReset(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('ExtendedComID',c_uint32),
        ('RequestCode', c_uint32),
        ('Reserved0', c_uint16),
        ('Length', c_uint16),
        ('SuccessFailure', c_uint32),
    ]


class FeatureDescriptorTPer(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('FeatureCode',c_uint16),
        ('Version', c_uint8, 4),
        ('Reserved0', c_uint8, 4),
        ('Length', c_uint8),
        ('Reserved1', c_uint8, 1),
        ('ComIDMgmtSupported', c_uint8, 1),
        ('Reserved2', c_uint8, 1),
        ('StreamingSupported', c_uint8, 1),
        ('BufferMgmtSupported', c_uint8, 1),
        ('AckNakSupported', c_uint8, 1),
        ('AsyncSupported', c_uint8, 1),
        ('SyncSupported', c_uint8, 1),
        ('Reserved3', c_uint8 * 11),
    ]


class FeatureDescriptorLocking(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('FeatureCode',c_uint16),
        ('Version', c_uint8, 4),
        ('Reserved0', c_uint8, 4),
        ('Length', c_uint8),
        ('Reserved1', c_uint8, 2),
        ('MBRDone', c_uint8, 1),
        ('MBREnabled', c_uint8, 1),
        ('MediaEncryption', c_uint8, 1),
        ('Locked', c_uint8, 1),
        ('LockingEnabled', c_uint8, 1),
        ('LockingSupported', c_uint8, 1),
        ('Reserved2', c_uint8 * 11),
    ]


class FeatureDescriptorGeometryReporting(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('FeatureCode',c_uint16),
        ('Version', c_uint8, 4),
        ('Reserved0', c_uint8, 4),
        ('Length', c_uint8),
        ('Reserved1', c_uint8, 7),
        ('Align', c_uint8, 1),
        ('Reserved2', c_uint8 * 7),
        ('LogicalBlockSize', c_uint32),
        ('AlignmentGranularity', c_uint64),
        ('LowestAlignedLBA', c_uint64),
    ]


class FeatureDescriptorOpalSSCV2(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('FeatureCode',c_uint16),
        ('Version', c_uint8, 4),
        ('Reserved0', c_uint8, 4),
        ('Length', c_uint8),
        ('BaseComID', c_uint16),
        ('NumberOfComIDs', c_uint16),
        ('Reserved1', c_uint8, 7),
        ('RangeCrossingBehavior', c_uint8, 1),
        ('NumberOfLockingSPAdmin', c_uint16),
        ('NumberOfLockingSPUser', c_uint16),
        ('InitialPINIndicator', c_uint8),
        ('BehaviorPINTPerRevert', c_uint8),
        ('Reserved2', c_uint8 * 5),
    ]


class Level0DiscoveryHeader(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('Length', c_uint32),
        ('MajorVersion', c_uint16),
        ('MinorVersion', c_uint16),
        ('Reserved', c_uint64),
        ('VendorUnique', Ascii * 32),
    ]


class FeatureDescriptorTemplate(BigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('FeatureCode',c_uint16),
        ('Version', c_uint8, 4),
        ('Reserved0', c_uint8, 4),
        ('Length', c_uint8),
        ('Reserved1', c_uint8 * 12),
    ]


def Streams(data):
    stream = data if isinstance(data, (str, bytes, bytearray)) else b'\x00' * data
    length = len(stream)
    if length % 4 != 0:
        stream += b'\x00' * (4 - (length % 4))  # Pad

    class Stream(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('ComPacket', ComPacket),
            ('Packet', Packet),
            ('SubPacket', SubPacket),
            ('PayLoad', c_uint8 * len(stream)),
        ]

    output = Stream()
    output.SubPacket.Length = length
    output.Packet.Length = output.SubPacket.Length + sizeof(output.SubPacket)
    output.ComPacket.Length = output.Packet.Length + sizeof(output.Packet)
    for i, char in enumerate(stream):
        output.PayLoad[i] = char
    return output


def FeatureDescriptor(template):
    if template.FeatureCode == 1:
        return FeatureDescriptorTPer
    if template.FeatureCode == 2:
        return FeatureDescriptorLocking
    if template.FeatureCode == 3:
        return FeatureDescriptorGeometryReporting
    if template.FeatureCode == 0x203:
        return FeatureDescriptorOpalSSCV2

    class Feature(BigEndianStructure):
        _pack_ = 1
        _fields_ = [
            ('FeatureCode',c_uint16),
            ('Version', c_uint8, 4),
            ('Reserved', c_uint8, 4),
            ('Length', c_uint8),
            ('FeatureDependentData', Ascii * template.Length),
        ]
        desc = {}
    return Feature


class TestTcg(TestCase):
    def __init__(self):
        super().__init__()
        self._comid = None
        self._spsp0 = None
        self._spsp1 = None
        self._HostSessionID = None
        self._SPSessionID = None

    def teardown(self):
        if self._HostSessionID is not None or self._SPSessionID is not None:
            self.close_session()

    @property
    def comid(self):
        if self._comid is None:
            self.get_comid()
        return self._comid

    @property
    def spsp0(self):
        if self._spsp0 is None:
            self.get_comid()
        return self._spsp0

    @property
    def spsp1(self):
        if self._spsp1 is None:
            self.get_comid()
        return self._spsp1

    @property
    def HostSessionID(self):
        if self._HostSessionID is None:
            self.start_session()
        return self._HostSessionID

    @property
    def SPSessionID(self):
        if self._SPSessionID is None:
            self.start_session()
        return self._SPSessionID

    @property
    def ComID(self):
        return self.comid.ComID

    @property
    def ExtendedComID(self):
        return self.comid.ExtendedComID

    @staticmethod
    def pop_char(stream, count=1):
        if len(stream) < count:
            return b''
        return bytes([stream.pop(0) for _ in range(count)])

    def encode_atom(self, data):
        if isinstance(data, (int,)):
            if 0 <= data <= 63:     # Tiny Atom
                return data.to_bytes(1, 'big')

            length = math.ceil(data.bit_length() / 8)
            return (0x80 | length).to_bytes(1, 'big') + data.to_bytes(length, 'big')    # Short Atom
        if isinstance(data, (str, bytes, bytearray)):
            if isinstance(data, (str,)):
                data = bytes(data, encoding='utf-8')

            length = len(data)
            if length <= 15:    # Short Atom
                return (0xa0 | length).to_bytes(1, 'big') + data
            if length <= 2047:    # Medium Atom
                return (0xd000 | length).to_bytes(2, 'big') + data
            if length <= 16777215:    # Long Atom
                return ((0xe000 << 24) | length).to_bytes(4, 'big') + data
            raise RuntimeError(f'Invalid data size: {length}')

        raise RuntimeError(f'Invalid data type: {type(data)}')

    def decode_atom(self, char, stream):
        atom = Atoms()
        atom.Value[0] = ord(char)
        if atom.Tiny == TINY_ATOM:
            return atom.TinyData
        if atom.Short == SHORT_ATOM:
            short = self.pop_char(stream, atom.ShortLength)
            if atom.ShortByte:
                return short
            return int.from_bytes(short, byteorder='big')
        if atom.Medium == MEDIUM_ATOM:
            atom.Value[1] = ord(self.pop_char(stream))
            medium = self.pop_char(stream, atom.MediumLength)
            if atom.MediumByte:
                return medium
            return int.from_bytes(medium, byteorder='big')
        if atom.Long == LONG_ATOM:
            atom.Value[1] = ord(self.pop_char(stream))
            atom.Value[2] = ord(self.pop_char(stream))
            atom.Value[3] = ord(self.pop_char(stream))
            long = self.pop_char(stream, atom.LongLength)
            if atom.LongByte:
                return long
            return int.from_bytes(long, byteorder='big')
        raise RuntimeError(f'Invalid atom: {char}')

    def encode_stream(self, invoking, method, required=[], optional={}):
        stream = TOKEN_CALL
        stream += self.encode_atom(invoking)
        stream += self.encode_atom(method)
        stream += TOKEN_SL
        # Required Parameters
        for val in required:
            if isinstance(val, dict):
                stream += TOKEN_SL
                for _key, _val in val.items():
                    stream += TOKEN_SN + self.encode_atom(_key) + self.encode_atom(_val) + TOKEN_EN
                stream += TOKEN_EL
            else:
                stream += self.encode_atom(val)

        # Optional Parameters
        for key, val in optional.items():
            if isinstance(val, dict):
                stream += TOKEN_SN + self.encode_atom(key) + TOKEN_SL
                for _key, _val in val.items():
                    stream += TOKEN_SN + self.encode_atom(_key) + self.encode_atom(_val) + TOKEN_EN
                stream += TOKEN_EL + TOKEN_EN
            else:
                stream += TOKEN_SN + self.encode_atom(key) + self.encode_atom(val) + TOKEN_EN
        stream += TOKEN_EL + TOKEN_EOD
        stream += TOKEN_SL + BYTES_ZERO * 3 + TOKEN_EL  # Status
        return stream

    def decode_stream(self, stream):
        output = []
        while True:
            char = self.pop_char(stream)
            if char in (BYTES_EMPTY, TOKEN_EL):
                return output

            if char == TOKEN_SL:
                output.append(self.decode_stream(stream))
            elif char in (TOKEN_CALL, TOKEN_EOS, TOKEN_EOD):
                output.append(char)
            elif char  == TOKEN_SN:
                name = self.decode_atom(self.pop_char(stream), stream)
                char = self.pop_char(stream)
                if char == TOKEN_SL:
                    output.append({name: self.decode_stream(stream)})
                else:
                    output.append({name: self.decode_atom(char, stream)})
                char = self.pop_char(stream)
                assert char == TOKEN_EN, f'Invalid end name token: {char}'
            else:
                output.append(self.decode_atom(char, stream))

    def show_stream(self, dptr):
        content = bytes(dptr).hex()
        self.log.debug(' '.join([content[i:i+8] for i in range(0, len(content), 8)]))
        # Ctype(dptr).dump()

        data = Ctype(dptr).dictionary(no_rsv=True)
        if 'PayLoad' in data:
            stream = bytearray(data['PayLoad'])[:data['SubPacket']['Length']]
            data['PayLoad'] = self.decode_stream(stream)

            self.log.debug(data['ComPacket'])
            self.log.debug(data['Packet'])
            self.log.debug(data['SubPacket'])
            self.log.info(data['PayLoad'])
        else:
            self.log.info(data)
        return data

    def security_send(self, dptr, *args, **kwarg):
        self.show_stream(dptr)
        self.nvme.security_send(dptr, *args, **kwarg)

    def security_receive(self, dptr, *args, **kwarg):
        self.nvme.security_receive(dptr, *args, **kwarg)
        data = self.show_stream(dptr)

        # Check Status
        if 'PayLoad' in data and TOKEN_EOS not in data['PayLoad']:
            assert len(data['PayLoad']), 'Invalid PayLoad!'
            status = data['PayLoad'][-1]
            assert status == [0, 0, 0], f'Security Recieve Status Error: {status}'
        return data

    def level0_discovery(self):
        dptr = (c_uint8 * 2048)()
        self.nvme.security_receive(dptr=dptr, spsp0=0x1, spsp1=0x0, secp=0x1)

        header = Level0DiscoveryHeader.from_buffer(dptr)
        assert header.MajorVersion == 0, f'Data structure major version {header.MajorVersion} invalid'
        assert header.MinorVersion == 1, f'Data structure minor version {header.MinorVersion} invalid'
        length = header.Length
        self.log.info('Length of parameter data: %d', length)

        data = {'Header': Ctype(header).dictionary(no_rsv=True), 'Features': []}
        offset = sizeof(Level0DiscoveryHeader)
        while offset < length + 4:
            template = FeatureDescriptorTemplate.from_buffer(bytearray(dptr)[offset:])
            feature = FeatureDescriptor(template).from_buffer(bytearray(dptr)[offset:])
            value = Ctype(feature).dictionary(no_rsv=True)
            data['Features'].append(value)
            offset += sizeof(feature)
        return data

    def get_comid(self):
        dptr = AllocateComID()
        self.log.info('Get ComID...')
        self.security_receive(dptr=dptr, spsp0=0x0, spsp1=0x0, secp=0x2)
        assert dptr.Value != 0x0, f'Invalid ComID: {hex(dptr.Value)}!'

        spsp1 = dptr.ComID >> 8
        spsp0 = dptr.ComID & 0xff
        self._comid, self._spsp1, self._spsp0 = dptr, spsp1, spsp0
        return self._comid, self._spsp1, self._spsp0

    def verify_comid_valid(self):
        request = VerifyComIDValid()
        request.ExtendedComID = self.comid.Value
        request.RequestCode = REQUEST_CODE_VERIFY_COMID_VALID
        self.log.info('Verify ComID Valid Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x2)

        response = VerifyComIDValid()
        self.log.info('Verify ComID Valid Receive...')
        return self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x2)

    def stack_reset(self):
        request = StackReset()
        request.ExtendedComID = self.comid.Value
        request.RequestCode = REQUEST_CODE_STACK_RESET
        self.log.info('Stack Reset Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x2)

        response = StackReset()
        self.log.info('Stack Reset Recieve...')
        self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x2)

    def properties(self, **HostProperties):
        # HostProperties = {'MaxComPacketSize': 0x2000, 'MaxResponseComPacketSize': 0x4000, 'MaxPacketSize': 0x4000,
        #                   'MaxIndTokenSize': 0x3fc8, 'MaxPackets': 0x1, 'MaxSubpackets': 0x1, 'MaxMethods': 0x1}
        stream = self.encode_stream(SMUID, PROPERTIES, optional={Properties['HostProperties']: HostProperties})
        request = Streams(stream)
        request.ComPacket.ComID = self.ComID
        request.ComPacket.ExtendedComID = self.ExtendedComID
        self.log.info('SMUID.Property Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        response = Streams(0x200)
        self.log.info('SMUID.Property Receive...')
        return self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

    def get_table(self, uid, **kwargs):
        # Table: 0,
        # startRow: 1,
        # endRow: 2,
        # startColumn: 3,
        # endColumn: 4,
        cell_block = {CellBlock[key]: val for key, val in kwargs.items()}
        stream = self.encode_stream(uid, GET, required=[cell_block])
        request = Streams(stream)
        request.ComPacket.ComID = self.ComID
        request.ComPacket.ExtendedComID = self.ExtendedComID
        request.Packet.TperSession = self.SPSessionID
        request.Packet.HostSession = self.HostSessionID
        self.log.info('Get Table Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        response = Streams(0x100)
        self.log.info('Get Table Receive...')
        data = self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)
        result = {}
        try:
            for value in data['PayLoad'][0][0]:
                result.update(value)
        except BaseException:
            pass
        return result

    def set_table(self, uid, table, **kwargs):
        # Table: 0,
        # startRow: 1,
        # endRow: 2,
        # startColumn: 3,
        # endColumn: 4,
        cell_block = {table[key]: val for key, val in kwargs.items()}
        stream = self.encode_stream(uid, SET, optional={1: cell_block})
        request = Streams(stream)
        request.ComPacket.ComID = self.ComID
        request.ComPacket.ExtendedComID = self.ExtendedComID
        request.Packet.TperSession = self.SPSessionID
        request.Packet.HostSession = self.HostSessionID
        self.log.info('Set Table Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        response = Streams(0x100)
        self.log.info('Set Table Receive...')
        data = self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)
        result = {}
        try:
            for value in data['PayLoad'][0][0]:
                result.update(value)
        except BaseException:
            pass
        return result

    def start_session(self, spid=ADMIN_SP_SPINFO_ADMIN_SPID, **kwargs):
        self.close_session()

        optional = {StartSession[key]: val for key, val in kwargs.items()}
        stream = self.encode_stream(SMUID, START_SESSION, required=[0x69, spid, 0x1], optional=optional)
        request = Streams(stream)
        request.ComPacket.ComID = self.ComID
        request.ComPacket.ExtendedComID = self.ExtendedComID
        self.log.info('Start Session Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        response = Streams(0x20)
        self.log.info('Start Session Receive...')
        data = self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)
        self._HostSessionID, self._SPSessionID = data['PayLoad'][3]
        return self._HostSessionID, self._SPSessionID

    def close_session(self):
        if self._HostSessionID is not None or self._SPSessionID is not None:
            request = Streams(TOKEN_EOS)
            request.ComPacket.ComID = self.ComID
            request.ComPacket.ExtendedComID = self.ExtendedComID
            request.Packet.TperSession = self.SPSessionID
            request.Packet.HostSession = self.HostSessionID
            self.log.info('Close Session Send...')
            self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

            response = Streams(0x4)
            self.log.info('Close Session Receive...')
            self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)
            self._HostSessionID = None
            self._SPSessionID = None

            # ComID - Associated to Inactive when session is closed
            self._comid = None
            self._spsp0 = None
            self._spsp1 = None

    def authentication(self, spid, **kwargs):
        if spid == LOCKING_SP_SPINFO_ADMIN_SPID:
            if self.get_locking_sp_life_cycle_state() == LIFE_CYCLE_STATE['MANUFACTURED_INACTIVE']:
                self.activate_locking_sp()

        return self.start_session(spid, **kwargs)

    def get_pin_of_msid(self):
        pin = self.get_table(ADMIN_SP_C_PIN_MSID, startColumn=3, endColumn=3)[3]
        assert len(pin) == 0x20, f'Invalid PIN: {pin}'
        return pin

    def get_locking_sp_life_cycle_state(self):
        return self.get_table(LOCKING_SP_SPINFO_ADMIN_SPID, startColumn=0, endColumn=7)[6]

    def activate_locking_sp(self):
        pin = self.get_pin_of_msid()
        self.authentication(spid=ADMIN_SP_SPINFO_ADMIN_SPID, HostChallenge=pin, HostSigningAuthority=ADMIN_SP_AUTHORITY_SID)

        stream = self.encode_stream(ADMIN_SP_LOCKING_UID, ACTIVATE)
        request = Streams(stream)
        request.ComPacket.ComID = self.ComID
        request.ComPacket.ExtendedComID = self.ExtendedComID
        request.Packet.TperSession = self.SPSessionID
        request.Packet.HostSession = self.HostSessionID
        self.log.info('LOCKING_SP.Activate Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        response = Streams(0x10)
        self.log.info('LOCKING_SP.Activate Receive...')
        result = self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        # Show locking sp status
        self.get_table(LOCKING_SP_SPINFO_ADMIN_SPID, startColumn=0, endColumn=7)
        return result

    def set_locking_range(self, locking_range=1, **kwargs):
        self.set_table(uid=LOCKING_RANGE + bytes([locking_range]), table=Locking, **kwargs)

    def get_locking_range(self, locking_range=1, **kwargs):
        uid = LOCKING_RANGE + bytes([locking_range]) if locking_range > 0 else LOCKING_GLOBALRANGE
        return self.get_table(uid, **kwargs)

    def revert_sp(self):
        stream = self.encode_stream(THIS_SP, REVERT_SP)
        request = Streams(stream)
        request.ComPacket.ComID = self.ComID
        request.ComPacket.ExtendedComID = self.ExtendedComID
        request.Packet.TperSession = self.SPSessionID
        request.Packet.HostSession = self.HostSessionID
        self.log.info('ThisSP.LockingSP Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        response = Streams(0x10)
        self.log.info('ThisSP.LockingSP Receive...')
        self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        # Session is invalid after revert
        self._HostSessionID = None
        self._SPSessionID = None
        self._comid = None
        self._spsp0 = None
        self._spsp1 = None

    def revert(self):
        stream = self.encode_stream(LOCKING_SP_SPINFO_ADMIN_SPID, REVERT)
        request = Streams(stream)
        request.ComPacket.ComID = self.ComID
        request.ComPacket.ExtendedComID = self.ExtendedComID
        request.Packet.TperSession = self.SPSessionID
        request.Packet.HostSession = self.HostSessionID
        self.log.info('Revert Send...')
        self.security_send(dptr=request, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)

        response = Streams(0x10)
        self.log.info('Revert Receive...')
        self.security_receive(dptr=response, spsp0=self.spsp0, spsp1=self.spsp1, secp=0x1)
