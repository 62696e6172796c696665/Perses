import argparse
import os
import sys
import yaml
import logging
from lib.driver.nvme import Tahoe
from lib.driver.utils.system import get_vendor_name
from lib.driver.utils.logger import Logging
Logging()
log = logging.getLogger('lib')


class Dut(object):

    def __init__(self):
        self.live_slots = list()
        self.file_path = os.path.join(os.path.dirname(__file__), "..", "log", "dut.yaml")

    def refresh(self, block=None):
        driver = Tahoe(block=block)
        dut_info = driver.get_info()
        log.info(dut_info)
        dut_info = self._format_results(dut_info)
        return dut_info

    def _format_results(self, results):
        format_result = {
            "vendor": get_vendor_name(results["ssd_config_dic"]["vid"]),
            "fw_version": results["test_fw_config_dic"]["fw_public_revision"],
            "commit": results["test_fw_config_dic"]["fw_private_revision"][0:6],
            "ise/sed": results["ssd_config_dic"]["security_type"],
            "security_status": results["ssd_config_dic"]["security_status"],
            "sn": results["ssd_config_dic"]["drive_sn"],
            "cap": "{}T".format(self.convert_t(results["ssd_config_dic"]["drive_tnvmcap"])),
            "bb": results["drive_life_info_dic"]["count_grown_defects"],
            "max_ec": results["drive_life_info_dic"]["nand_max_erase_count"],
            "min_ec": results["drive_life_info_dic"]["nand_min_erase_count"],
            "pn": results["ssd_config_dic"]["drive_pn"],
        }
        return format_result

    @staticmethod
    def convert_t(cap):
        return float('%.2f' % (cap/1000/1000/1000/1000))

    def clear_yaml(self):
        if os.path.exists(self.file_path):
            log.info("Delete dut yaml")
            os.remove(self.file_path)

    def dump_yaml(self, dut_info):
        with open(self.file_path, "w") as f:
            yaml.dump(dut_info, f)

    def main(self, slot=None, block=None):
        if type(slot) is str:
            os.environ["slot"] = slot
        try:
            self.clear_yaml()
            dut_info = self.refresh(block)
            self.dump_yaml(dut_info)
            return 0
        except Exception as err:
            log.info(err)
            return 1


if __name__ == '__main__':
    print("in dut")
    PARSER = argparse.ArgumentParser(description='NVMe Commands')
    PARSER.add_argument('-s', '--slot', default=None, help='NVMe slot')
    PARSER.add_argument('-b', '--block', default=None, help='NVMe block name')

    ARGS = PARSER.parse_args()
    print(ARGS.slot, ARGS.block)
    dut = Dut()
    sys.exit(dut.main(ARGS.slot, ARGS.block))
