#!/usr/bin/env python
"""
Usage:
    debug_vdbench.py [internal parameters] device [extra parameters]

Example:
    debug_vdbench.py /dev/nvme0n1
    debug_vdbench.py --size 100g /dev/nvme0n1 -v
"""
import argparse
import sys

from lib.tool.vdbench import Vdbench
from lib.driver.utils.logger import Logging

Logging()


def main(args):
    obj = Vdbench(args.dev)

    for key, val in vars(args).items():
        if key not in ["parm", "dev"]:
            if key == 'size' and '(' in val:
                key = 'range'
            obj.set_parm(key, val)

    status, _ = obj.start(args.parm)
    return status


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description='VDBENCH')
    # General parameters
    PARSER.add_argument("-e", "--data_errors",
                        default="1", help="Terminate after 'nn' read/write/data validation errors")

    # Host Definition
    PARSER.add_argument("-m", "--jvms", default="1", help="How many slaves to use")

    # Storage Definition
    PARSER.add_argument("-s", "--size",
                        default="5g", help="Size of the raw disk or file to use for workload")
    PARSER.add_argument("-j", "--threads",
                        default="1", help="Maximum number of concurrent outstanding I/O")

    # Workload Definition
    PARSER.add_argument("-x", "--xfersize",
                        default="4k", help="Data transfer size")
    PARSER.add_argument("-r", "--rdpct",
                        default="0", help="Read percentage")
    PARSER.add_argument("-k", "--seekpct",
                        default="100", help="Percentage of Random Seeks")

    # Run Definition
    PARSER.add_argument("-t", "--elapsed",
                        default="30", help="Elapsed time for this run in seconds")
    PARSER.add_argument("-i", "--interval",
                        default="1", help="Reporting interval in seconds")
    PARSER.add_argument("-f", "--forxfersize",
                        default=None, help="Multiple runs for each data transfer size")

    PARSER.add_argument('dev', help='Name of raw disk or file system file')
    PARSER.add_argument('parm', nargs=argparse.REMAINDER, help='Execution Parameters')

    ARGS = PARSER.parse_args()
    sys.exit(main(ARGS))
