#!/usr/bin/env python
import time
import argparse

from lib.tool.cp210x import CP210X
from lib.driver.utils.logger import Logging

Logging()


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description='CP210X Debug')

    PARSER.add_argument('-p', '--power', default=None, help='Power Off(0), Power On(1), Power Cycle(2)')
    ARGS = PARSER.parse_args()

    USB = CP210X()
    if int(ARGS.power) == 0:
        USB.power_off()
    elif int(ARGS.power) == 1:
        USB.power_on()
    else:
        USB.power_off()
        time.sleep(1)
        USB.power_on()
