#!/usr/bin/env python
import argparse
import sys
import logging

from lib.driver.utils.lib import PCIe
from lib.driver.utils.logger import Logging

Logging()
log = logging.getLogger('lib')


def main(args):
    pcie = PCIe(device=args.device, bid=args.bar)

    if isinstance(args.offset, str):
        args.offset = int(args.offset, 16)

    if isinstance(args.length, str):
        args.length = int(args.length, 16)

    for i in range(args.length):
        value = pcie.read_bar_uint32(args.offset + i * 4)
        log.info('Offset: 0x%x, Value: 0x%x', args.offset + i * 4, value)

    return 0


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description='FIO')

    PARSER.add_argument("-d", "--device", default='/dev/nvme0', help="Device. (/dev/nvme0)")
    PARSER.add_argument("-b", "--bar", default=0, help="Bar NO. (0)")
    PARSER.add_argument("-o", "--offset", default=0x0, help="Offset (0x0)")
    PARSER.add_argument("-l", "--length", default=0x1, help="Length (0x1)")

    ARGS = PARSER.parse_args()

    sys.exit(main(ARGS))
