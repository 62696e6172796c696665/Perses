#!/usr/bin/env python
# pylint: disable=superfluous-parens,missing-docstring,too-many-public-methods,unused-wildcard-import
import argparse
import sys

from lib.driver.nvme import NVMe, Tahoe
from lib.driver.utils.ctype import Ctype
from lib.driver.utils.logger import Logging

Logging()


def main(args):
    

    if args.identify:
        nvme = NVMe(block=args.device)
        dptr = nvme.identify_ctrl()
        Ctype(dptr).dump()

        dptr = nvme.identify_ns()
        Ctype(dptr).dump()
    elif args.smart:
        nvme = NVMe(block=args.device)
        dptr = nvme.get_log_error_info()
        Ctype(dptr).dump()

        dptr = nvme.get_log_smart_health_info()
        Ctype(dptr).dump()

        dptr = nvme.get_log_fw_slot_info()
        Ctype(dptr).dump()
    elif args.vu:
        nvme = Tahoe(block=args.device)
        nvme.vu_cmd.set_queue_number(256, 256)

    return 0


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description='NVMe Commands')

    PARSER.add_argument('-d', '--device', default="/dev/nvme0n1", help='NVMe device')

    GROUP = PARSER.add_mutually_exclusive_group(required=True)
    GROUP.add_argument('-i', '--identify', action='store_true', help='Echo identify')
    GROUP.add_argument('-s', '--smart', action='store_true', help='Echo smart log')
    GROUP.add_argument('-se', '--security', action='store_true', help='send security send command')
    GROUP.add_argument('-v', '--vu', action='store_true', help='issue vu')

    ARGS = PARSER.parse_args()
    sys.exit(main(ARGS))
