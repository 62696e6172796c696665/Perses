#!/usr/bin/env python
import argparse
import sys

from lib.tool.fio.fio_linux import Fio
from lib.driver.utils.logger import Logging

Logging()


def main(args):
    obj = Fio()

    obj.import_list(*args.parm)

    for key, val in vars(args).items():
        if key not in ["parm", "dev"]:
            obj.set_parm(key, val)

    status, _ = obj.start(filename=args.dev)

    return status


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description='FIO')

    PARSER.add_argument("-j", "--name", default="debug",
                        help="Job name")
    PARSER.add_argument("-s", "--size", default="100%",
                        help="Total size of device or files(100%%)")
    PARSER.add_argument("-b", "--bs", default="4k",
                        help="Block size unit(4k)")
    PARSER.add_argument("-r", "--rw", default="randrw",
                        help="IO operation(randrw)")
    PARSER.add_argument("-x", "--rwmixread", default="50",
                        help="Percentage of mixed workload that is reads(50)")
    PARSER.add_argument("-t", "--runtime", default=None,
                        help="Stop workload when this amount of time has passed(None)")
    PARSER.add_argument("-i", "--iodepth", default="1",
                        help="Number of IO buffers to keep in flight(64)")
    PARSER.add_argument("-n", "--numjobs", default="1",
                        help="Duplicate this job this many times(1)")
    PARSER.add_argument("-p", "--percentile_list", default=False,
                        help="Specify a custom list of percentiles to report for completion "
                             "latency and block errors(False)")
    PARSER.add_argument("-e", "--continue_on_error", default="none",
                        help="Continue on non-fatal errors during IO(none) {none, all,,,}")
    PARSER.add_argument("-v", "--verify", default=None,
                        help="Verify data written(None) {None, crc32c, sha512,,,}")
    PARSER.add_argument("-T", "--thread", action="store_true", default=False,
                        help="Use thread instead of process(False)")
    PARSER.add_argument("-D", "--direct", default="1",
                        help="Use O_DIRECT IO (negates buffered)(1)")
    PARSER.add_argument("-I", "--ioengine", default="libaio",
                        help="IO engine to use(libaio) {libaio, psync, sync,,,}")
    PARSER.add_argument("-R", "--randrepeat", default="0",
                        help="Use repeatable random IO pattern(0)")
    PARSER.add_argument("-L", "--rate_iops", default=None,
                        help="Limit IO used to this number of IO operations/sec(None)")
    PARSER.add_argument("-W", "--ramp_time", default=None,
                        help="Ramp up time before measuring performance(None)")

    PARSER.add_argument('dev', help='Name of raw disk')
    PARSER.add_argument('parm', nargs=argparse.REMAINDER, help='Execution Parameters')

    ARGS = PARSER.parse_args()

    sys.exit(main(ARGS))
