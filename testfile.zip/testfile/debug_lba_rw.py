#!/usr/bin/env python
import argparse
import sys
import logging

from lib.driver.nvme import NVMe
from lib.driver.nvme.traffic import LBAOperate
from lib.driver.utils.logger import Logging

Logging()
log = logging.getLogger('lib')

func_fill = {0: 'fill_uint32_fix',
             1: 'fill_uint32_seq',
             2: 'fill_uint32_rnd'}
func_comp = {0: 'compare_uint32_fix',
             1: 'compare_uint32_seq',
             2: 'compare_uint32_rnd'}
func_diff = {0: 'diff_uint32_fix',
            1: 'diff_uint32_seq',
            2: 'diff_uint32_rnd'}


def func(buff, _func, mode, *args, **kwargs):
    return getattr(buff, _func[mode])(*args, **kwargs)


def main(args):
    nvme = NVMe(block=args.device)
    ioe = LBAOperate(dev=nvme)

    # write data to flash
    lba = int(args.lba, 16) if "0x" in args.lba else int(args.lba)
    nlb = int(args.nlb, 16) if "0x" in args.nlb else int(args.nlb)
    mode = int(args.mode, 16) if "0x" in args.mode else int(args.mode)
    pattern = int(args.pattern, 16) if "0x" in args.pattern else int(args.pattern)
    rw_mode = args.rw

    log.info('LBA: 0x%x, nlb: 0x%x, mode: 0x%x, pattern: 0x%x, rw: %s', lba, nlb, mode, pattern, rw_mode)

    if 'w' in rw_mode:
        ioe.write_sync(lba, nlb, mode=mode, pattern=pattern)

    if 'r' in rw_mode:
        ioe.read_sync(lba, nlb, compare=bool('c' in rw_mode))


if __name__ == "__main__":
    PARM = argparse.ArgumentParser(description='LBA operate')
    PARM.add_argument("-d", "--device", default='/dev/nvme0n1', help="Device(/dev/nvme0n1)")
    PARM.add_argument("-l", "--lba", type=str, default="0", help="Start LBA(0x0)")
    PARM.add_argument("-n", "--nlb", type=str, default="1", help="Number of LBAs(0x1)")
    PARM.add_argument("-p", "--pattern", type=str, default="0", help="Pattern(0x0)")
    PARM.add_argument("-m", "--mode", type=str, default="0", help="Data mode 0:fix 1:seq 2:rnd")
    PARM.add_argument("-r", "--rw", type=str, default="r", help="write/read mode(r: read w: write c: compare d: dump)")
    ARGS = PARM.parse_args()
    sys.exit(main(ARGS))
